<template>
  <div>
    <!-- Top Bar and Menu combined -->
    <div style="height: 60px; display: flex; align-items: center;background-color: #050f46;">
      <!-- Logo and Title -->
      <div style="flex: 1; display: flex; align-items: center; padding-left: 20px;">
        <img src="@/assets/header.png" alt="" style="width: 40px">
        <div style="font-weight: bold; font-size: 30px; margin-left: 5px; color: rgba(255,255,255,0.87);">广告投放与管理系统</div>
      </div>

      <div style="flex: 1;display: flex;align-items: center;padding-left: 20px">
        <el-menu
            router
            style="border: none; display: flex; flex-grow: 1; justify-content: center;"
            :default-active="$route.path"
            mode="horizontal"
        >
          <el-menu-item index="/AdvertisementList" v-if="data.user.role === 'USER'">
            <el-icon><ZoomIn /></el-icon>
            <span>广告投放</span>
          </el-menu-item>
          <el-menu-item index="/UserData" v-if="data.user.role === 'USER'">
            <el-icon><DataAnalysis /></el-icon>
            <span>整体数据</span>
          </el-menu-item>
          <el-menu-item index="/person">
            <el-icon><User /></el-icon>
            <span>个人资料</span>
          </el-menu-item>
          <el-menu-item index="login" @click="logout">
            <el-icon><SwitchButton /></el-icon>
            <span>退出系统</span>
          </el-menu-item>
        </el-menu>
      </div>

      <!-- User Info -->
      <div style="width: fit-content; padding-right: 10px; display: flex; align-items: center;">
        <span>
            <img :src="'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'" alt="" style="width: 40px; height: 40px; border-radius: 50%">
        </span>
        <span style="color: rgba(255,255,255,0.87); margin-left: 5px">{{ data.user.name }}</span>
      </div>

    </div>

    <!-- Main Content -->
    <div class="main-content">
      <router-view @updateUser="updateUser" />
    </div>
  </div>
</template>

<script setup>
import { reactive } from "vue";
import { useRoute } from 'vue-router'
import { DataAnalysis, ZoomIn, User, SwitchButton } from "@element-plus/icons-vue";
import router from "@/router/index.js";

const $route = useRoute()

const data = reactive({
  user: JSON.parse(localStorage.getItem('user') || '{}')
})

const logout = () => {
  localStorage.removeItem('user')
  router.push('/')
}

const updateUser = () => {
  data.user = JSON.parse(localStorage.getItem("user"))
}
</script>

<style scoped>
.main-content {
  flex-grow: 1; /* 占满剩余空间 */
  overflow-y: auto;
  box-sizing: border-box;
}

.el-menu-item.is-active {
  background-color: #e0e4ff !important;
}

.el-menu-item:hover {
  background-color: #e9eeff !important;
  color: #1450aa;
}

:deep(.el-menu) {
  background-color: transparent !important;
}

:deep(.el-menu-item),
:deep(.el-sub-menu__title) {
  color: #ffffff !important;
}

:deep(.el-menu-item:hover),
:deep(.el-sub-menu__title:hover) {
  background-color: #263445 !important;
  color: #fff !important;
}

:deep(.el-menu-item.is-active) {
  background-color: #263445 !important;
  color: #fff !important;
}
</style>
