package com.example.service;

import com.example.entity.News;
import com.example.mapper.NewsMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class NewsService {

    @Resource
    NewsMapper newsMapper;

    public void add(News news) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        news.setCreateTime(sdf.format(new Date()));
        news.setStatus("已提交平台");
        news.setUrl("http://localhost:8100/LinkNews/"+news.getAdvertisementId());
        newsMapper.insert(news);
    }

    public boolean selectByAdvertisementId(Integer advertisementId) {
        System.out.println("新闻："+newsMapper.selectByAdvertisementId(advertisementId));
        if(newsMapper.selectByAdvertisementId(advertisementId)){
            return true;
        }else {
            return false;
        }
    }

    public List<News> selectUrlByAdvertisementId() {
        return newsMapper.selectUrlByAdvertisementId();
    }

    public void updateClickByAdvertisementId(Integer advertisementId) {
        newsMapper.updateClickByAdvertisementId(advertisementId);
    }

    public News selectMoneyByAdvertisementId(Integer advertisementId) {
        return newsMapper.selectMoneyByAdvertisementId(advertisementId);
    }

    public boolean selectByUserId(Integer userId) {
        if(newsMapper.selectByUserId(userId)){
            return true;
        }else {
            return false;
        }
    }

    public News selectMoneyByUserId(Integer userId) {
        return newsMapper.selectMoneyByUserId(userId);
    }

//    public PageInfo<Advertisement> selectPageById(Advertisement advertisement, Integer userId, Integer pageNum, Integer pageSize) {
//        PageHelper.startPage(pageNum,pageSize);
//        List<Advertisement> list=advertisementListMapper.selectById(advertisement, userId);
//        return PageInfo.of(list);
//    }
//
//    public void deleteBatch(List<String> titles) {
//        for (String title :titles){
//            this.deleteByTitle(title);
//        }
//    }
//
//    public void deleteByTitle(String title) {
//        advertisementListMapper.deleteByTitle(title);
//    }
//
//    public void update(Advertisement advertisement) {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        advertisement.setCreateTime(sdf.format(new Date()));
//        advertisementListMapper.update(advertisement);
//    }
}
