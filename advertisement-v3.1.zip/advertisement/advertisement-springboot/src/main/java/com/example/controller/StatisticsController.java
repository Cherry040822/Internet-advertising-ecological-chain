package com.example.controller;

import com.example.common.Result;
import com.example.service.StatisticsService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/statistics")
public class StatisticsController {

    @Resource
    private StatisticsService statisticsService;

    @GetMapping("/daily/selectAll")
    public Result dailySelectAll() {
        return Result.success(statisticsService.dailySelectAll());
    }

    @GetMapping("/daily/selectByAdvertisementId/{advertisementId}")
    public Result dailySelectByAdvertisementId(@PathVariable("advertisementId") Integer advertisementId) {
        return Result.success(statisticsService.dailySelectByAdvertisementId(advertisementId));
    }

    @GetMapping("/daily/selectByUserId/{userId}")
    public Result dailySelectByUserId(@PathVariable("userId") Integer userId) {
        return Result.success(statisticsService.dailySelectByUserId(userId));
    }

    @GetMapping("/monthly/selectAll")
    public Result monthlySelectAll() {
        return Result.success(statisticsService.monthlySelectAll());
    }

    @GetMapping("/monthly/selectByAdvertisementId/{advertisementId}")
    public Result monthlySelectByAdvertisementId(@PathVariable("advertisementId") Integer advertisementId) {
        return Result.success(statisticsService.monthlySelectByAdvertisementId(advertisementId));
    }

    @GetMapping("/monthly/selectByUserId/{userId}")
    public Result monthlySelectByUserId(@PathVariable("userId") Integer userId) {
        return Result.success(statisticsService.monthlySelectByUserId(userId));
    }

    @GetMapping("/annual/selectAll")
    public Result annualSelectAll() {
        return Result.success(statisticsService.annualSelectAll());
    }

    @GetMapping("/annual/selectByAdvertisementId/{advertisementId}")
    public Result annualSelectByAdvertisementId(@PathVariable("advertisementId") Integer advertisementId) {
        return Result.success(statisticsService.annualSelectByAdvertisementId(advertisementId));
    }

    @GetMapping("/annual/selectByUserId/{userId}")
    public Result annualSelectByUserId(@PathVariable("userId") Integer userId) {
        return Result.success(statisticsService.annualSelectByUserId(userId));
    }

    @PutMapping("/sumClick")
    public Result sumClick() {
        statisticsService.sumClick();
        return Result.success();
    }

    @PostMapping("/addRecords")
    public Result addRecords() {
        statisticsService.addRecords();
        return Result.success();
    }
}
