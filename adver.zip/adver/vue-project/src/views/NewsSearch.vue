<template>
  <div class="news-search-container">
    <!-- Logo 和标题 -->
    <div style="position: relative;height: auto; background-color:#516996; padding: 20px;">
      <div style="display: flex; align-items: center; margin-bottom: 10px;">
        <img src="@/assets/新闻.png" alt="News Website Logo" style="width: 40px;">
        <span style="font-size: 20px; font-weight: bold;color: #d1e3f6; font-style: italic;margin-left: 10px;">新闻搜索</span>
      </div>
    </div>
    <!-- 搜索框 -->
    <div style="margin-left: 550px;margin-top: 1px">
      <el-input v-model="searchQuery" style="width: 200px" placeholder="搜索新闻" clearable @keyup.enter="fetchSearchedNews">
        <template #prefix>
          <el-icon class="el-input__icon"><search /></el-icon>
        </template>
      </el-input>
      <el-button type="primary" :icon="Search" circle @click="fetchSearchedNews"/>
    </div>
    <div v-if="newsList.length" class="news-list">
      <p>共找到 {{ totalResults }} 条相关新闻。</p>

      <!-- 新闻列表区域 -->
      <div class="news-section">
        <div v-for="news in newsList" :key="news.id" class="news-item">
          <a style="text-decoration: none;" :href="`/news/${news.id}`" target="_blank" @click.prevent="openNewsDetail(news)">
            <div class="news-content">
              <img src="@/assets/title1-1.jpg" alt="News Icon" class="news-icon">
              <div class="news-info">
                <h3 class="news-title">{{ news.title }}</h3>
                <div class="news-meta">
                  <span>{{ news.author }}</span>
                  <span>{{ formatDate(news.publicationTime) }}</span>
                </div>
              </div>
            </div>
          </a>
        </div>
      </div>


    </div>
    <div v-else class="no-news-message">
      暂无相关新闻。
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';
import { Search } from "@element-plus/icons-vue";

const route = useRoute();
const router = useRouter();
const newsList = ref([]);
const totalResults = ref(0);
const searchQuery = ref('');

// 初始化时从URL获取查询参数并执行搜索
onMounted(() => {
  const query = route.query.query || '';
  if (query) {
    searchQuery.value = query;
    fetchSearchedNews();
  }
});

async function fetchSearchedNews() {
  try {
    // 更新URL中的查询参数但不触发重新加载
    const currentQuery = { ...route.query };
    if (searchQuery.value) {
      currentQuery.query = searchQuery.value;
    } else {
      delete currentQuery.query;
    }
    router.replace({ query: currentQuery });

    const response = await axios.get(`/news/search?query=${searchQuery.value}`);
    newsList.value = response.data.data;
    totalResults.value = newsList.value.length;
  } catch (error) {
    console.error('Error fetching searched news:', error);
  }
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}
async function openNewsDetail(news) {
  const detailWindow = window.open('', encodeURIComponent(news.title));
  if (detailWindow) {
    detailWindow.location.href = `/news/${news.id}`;
  }
}
</script>



<style scoped>
.news-search-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9fb;
}



.search-section input {
  width: 80%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.search-section button {
  padding: 10px 20px;
  margin-left: 10px;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;
}

.search-section button:hover {
  background-color: #0056b3;
}

.news-list {
  display: flex;
  flex-direction: column;
  gap: 5px;
  text-decoration: none;
}


.no-news-message {
  text-align: center;
  font-size: 18px;
  color: #666;
}

.news-section {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* 添加新的样式规则 */
.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.news-content {
  display: flex;
  align-items: flex-start;
  text-decoration: none;
}

.news-icon {
  width: 50px; /* 根据需要调整大小 */
  height: 50px;
  object-fit: contain;
  margin-right: 10px; /* 图片与文本之间的间距 */
}

.news-info {
  display: flex;
  flex-direction: column;
}


.news-title {
  margin: 0 0 5px 0;
  font-size: 18px;
  color: #333;
  transition: color 0.3s ease;
}

/*当鼠标悬停在新闻标题上时改变字体颜色 */
.news-title:hover {
  color: #1e6bb7;
}


.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
  text-decoration: none;
}


</style>