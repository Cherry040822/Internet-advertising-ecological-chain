<template>
  <div style="display: flex">
    <div>
      <div v-for="item in data.advertisementleft" :key="item.id">
        <iframe :src="item.url" width="150px" height="150px" scrolling="no" style="border: none"></iframe>
      </div>
    </div>
    <div class="news-container">
      <!-- 主体部分 -->
      <div class="header-container">
        <div class="header-content" style="display: flex; align-items: center; margin-bottom: 10px;">
          <img src="@/assets/新闻.png" alt="News Website Logo" style="width: 40px;">
          <span style="font-size: 20px; font-weight: bold; color: #d1e3f6; font-style: italic; margin-left: 10px;">新闻详情</span>
        </div>
      </div>

      <div v-if="news" class="news-detail-container">
        <div class="news-detail">
          <h1>{{ news.title }}</h1>
          <p><strong>作者:</strong> {{ news.author }}</p>
          <p><strong>发布时间:</strong> {{ formatDate(news.publicationTime) }}</p>
          <div class="image-container">
            <img v-if="news.imageUrl" :src="news.imageUrl" alt="News Image" />
          </div>
          <div class="news-content" v-html="news.content"></div>
        </div>
      </div>
    </div>


    <div>
      <div v-for="item in data.advertisement" :key="item.id">
        <iframe :src="item.url" width="150px" height="150px" scrolling="no" style="border: none"></iframe>
      </div>
      <!--      <iframe src="https://xp.hebiu.cn/HandleCookies" width="150px" height="150px" style="border:none"></iframe>-->
    </div>
  </div>



</template>

<script setup>
import { ref, onMounted, reactive } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';
import Cookies from "js-cookie";
import request from "@/utils/request.js";

const data = reactive({
  advertisement:[],
  advertisementleft:[]
})
const route = useRoute();
const news = ref(null);

onMounted(() => {
  fetchNewsDetail();
});

async function fetchNewsDetail() {
  try {
    const response = await axios.get(`/news/${route.params.id}`);
    news.value = response.data.data;
  } catch (error) {
    console.error('Error fetching news detail:', error);
  }
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}

const loadAdvertisement = () =>{
  const user = Cookies.get('web_user')
  console.log(user)
  request.get(`/news/select/${user}`).then(res=>(
      data.advertisement=res.data
  ))
}
loadAdvertisement()

const loadAdvertisementleft = () =>{
  const user = Cookies.get('web_user')
  console.log(user)
  request.get(`/news/selectplus/${user}`).then(res=>(
      data.advertisementleft=res.data
  ))
}
loadAdvertisementleft()
</script>

<style scoped>
/* 确保主体部分和详情部分有一样的最大宽度，并且居中 */
.header-container,
.news-detail-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  background-color: #f9f9fb;
}

.header-content,
.news-detail {
  max-width: 800px;
  width: 100%;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  text-align: center;
  padding: 40px;
}

.header-content {
  background-color:  #516996;
  margin-bottom: 20px;
}

/* 增大详情页 content 部分的字体 */
.news-content {
  font-size: 18px; /* 根据需要调整字体大小 */
  line-height: 1.6; /* 改善行间距，使阅读更舒适 */
}

@media (min-width: 768px) {
  .news-detail {
    margin-top: 0px;
  }
}/* 图片样式 */
.image-container img {
  max-width: 100%; /* 确保图片不会超出其容器 */
  height: auto; /* 保持图片的原始比例 */
  display: block; /* 移除图片下方的默认空白空间 */
  margin: 20px auto; /* 上下有间隔，左右居中 */
}
.news-container {
  margin-left: 100px;
  margin-right: 100px;
  padding: 20px;
  background-color: #f9f9fb;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
</style>