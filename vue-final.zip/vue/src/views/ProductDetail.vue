<template>
  <div class="product-detail" style="margin-bottom: 100px">
    <el-button class="return-btn" @click="returnTopage" type="warning">返回首页</el-button>
    <!-- 商品图片 -->
    <div class="image-section">
      <img :src="data.product.imageUrl" alt="商品图片" class="product-image" />
    </div>

    <!-- 商品信息 -->
    <div class="info-section">
      <h1 class="product-name">{{ data.product.name }}</h1>
      <div class="divider"></div>
      <div class="info-item">
        <span class="label">描述：</span>
        <span class="value">{{ data.product.description }}</span>
      </div>
      <div class="info-item">
        <span class="label">发货地：</span>
        <span class="value">{{ data.product.shipAddress }}</span>
      </div>
      <div class="info-item">
        <span class="label">快递：</span>
        <span class="value">{{ data.product.delivery }}</span>
      </div>
      <div class="info-item">
        <span class="label">销量：</span>
        <span class="value highlight">{{ data.product.sales }}</span>
      </div>
      <div class="price-section">
        <span class="currency">￥</span>
        <span class="product-price">{{ data.product.price }}</span>
      </div>
      <!-- 加入购物车按钮 -->
      <el-button
          type="warning"
          size="large"
          @click="addToCart(data.product)">
        加入购物车
      </el-button>
    </div>

  </div>
  <div style="width: 1300px;display: flex;margin-left: 400px">
    <div style="margin-right: 10px" v-for="item in data.advertisement.slice(0, 6)" :key="item.id">
      <iframe :src="item.url" width="150px" height="150px" scrolling="no" style="border: none"></iframe>
    </div>
  </div>
</template>

<script setup>
import { reactive } from "vue";
import request from "@/utils/request.js";
import { ElMessage } from "element-plus";
import {useRoute} from "vue-router";
import router from "@/router/index.js";
import Cookies from "js-cookie";
import res from "@/utils/res.js";
const data =reactive({
  product:{}

})
const route = useRoute();
const productId = route.query.id; // 从路由参数中获取商品 ID
const loadProductDetails = () => {
  if (!productId) {
    console.error("商品 ID 未传递");
    return;
  }
  request.get(`/product/selectById/${productId}`).then((res) => {
    if (res.code === "200") {

      console.log("返回的商品数据：", res.data); // 打印后端返回数据
      data.product = res.data; // 直接赋值
      console.log(data.product.category)
      Cookies.set('categoryClick',data.product.category,{
        path:'/',
        domain:'.hebiu.cn',
        sameSite:'None',
        secure: true,
      })
      Cookies.set('categoryClickTimestamp',Date.now(),{
        path:'/',
        domain:'.hebiu.cn',
        sameSite:'None',
        secure: true,
      })
      loadAdvertisement()
    } else {
      console.error("加载商品详情失败:", res.msg);
    }
  }).catch((error) => {
    console.error("请求失败:", error);
  });
};

loadProductDetails()
// 加入购物车方法
const addToCart = (product) => {
  Cookies.set('categoryClick',product.category,{
    path:'/',
    domain:'.hebiu.cn',
    sameSite:'None',
    secure: true,
  })
  Cookies.set('categoryClickTimestamp',Date.now(),{
    path:'/',
    domain:'.hebiu.cn',
    sameSite:'None',
    secure: true,
  })
  loadAdvertisement()
  request.post("/cart/insert", product)
      .then((res) => {
        console.log("后端返回：", res); // 调试用，查看后端返回内容
        if (res.code === "200") {
          // 成功加入购物车的提示
          ElMessage.success(res.data || "成功加入购物车！");
          loadcart(); // 更新购物车
        } else {
          // 判断错误信息是否为 "该商品已经加入购物车！"
          if (res.msg === "该商品已经加入购物车！") {
            ElMessage.info("该商品已经加入购物车！");
          } else {
            ElMessage.error(res.msg || "加入购物车失败！");
          }
        }
      })
      .catch((error) => {
        // 捕获后端返回的 HTTP 错误，例如 400/500 状态码
        const errorMsg = error.response?.data?.msg || "加入购物车失败";
        if (error.response?.data?.msg === "该商品已经加入购物车！") {
          ElMessage.info("该商品已经加入购物车！");
        }
      });
};
const returnTopage =()=>{
  router.push({ path: "/" });
}

const loadAdvertisement = () =>{
  const user=Cookies.get('web_user')
  console.log("aaaaaaaaaaaaaaaaaa"+user)
  res.get(`/shopping/select/${user}`).then(res=>(
      data.advertisement=res.data
  ))
}
loadAdvertisement()
</script>

<style scoped>
.return-btn {
  position: absolute;
  top: 20px;
  left: 20px;
  border: none;
}

.product-detail {
  display: flex;
  gap: 20px;
  margin: 20px;
}

.image-section {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}

.product-image {
  max-width: 100%;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width:600px;
  height: 500px;
}

.info-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 30px;
  background-color: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
}
.info-item {
  margin: 12px 0;
  display: flex;
  align-items: center;
}
.product-name {
  font-size: 28px;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 15px;
  letter-spacing: 0.5px;
}

.divider {
  height: 1px;
  background: linear-gradient(to right, #eee, #e0e0e0, #eee);
  margin: 15px 0;
}
.label {
  font-size: 15px;
  color: #666;
  width: 80px;
  flex-shrink: 0;
}
.value {
  font-size: 15px;
  color: #2c3e50;
  flex: 1;
  line-height: 1.6;
}
.highlight {
  color: #ff6b6b;
  font-weight: 500;
}
.price-section {
  margin: 25px 0;
  display: flex;
  align-items: baseline;
}
.currency {
  font-size: 20px;
  color: #ff6b6b;
  margin-right: 4px;
}

.el-button[type="warning"] {
  background: linear-gradient(135deg, #ff9a9e 0%, #ff6b6b 100%);
  border: none;
  padding: 12px 30px;
  font-size: 16px;
  font-weight: 500;
  transition: transform 0.2s;
}

.product-price {
  font-size: 20px;
  color: #ff5722;
  font-weight: bold;
}



</style>

