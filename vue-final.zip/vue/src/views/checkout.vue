<template>
  <div class="checkout-page">
    <!-- 返回购物车按钮 -->
    <div class="back-to-cart">
      <el-button @click="goBackToCart" icon="el-icon-arrow-left" class="back-button">返回购物车</el-button>
    </div>

    <div class="header">
      <h1>确认订单信息：</h1>
    </div>

    <!-- 商品列表部分的更新 -->
    <div class="product-list">
      <el-card class="unified-product-card">
        <div v-for="(item, index) in data.product"
             :key="item.productId"
             class="product-row"
             :class="{ 'with-border': index !== data.product.length - 1 }">
          <div class="product-content">
            <div class="name-image-section">
              <h3 class="product-name">{{ item.name }}</h3>
              <div class="product-image">
                <img :src="item.imageUrl" alt="商品图片" />
              </div>
            </div>
            <div class="price">¥{{ item.price }}</div>
            <div class="quantity-control">
              <el-button @click="decrease(item)" size="small" :disabled="item.quantity <= 1">
                <el-icon><Minus /></el-icon>
              </el-button>
              <span class="quantity">{{ item.quantity }}</span>
              <el-button @click="increase(item)" size="small">
                <el-icon><Plus /></el-icon>
              </el-button>
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 底部区域的更新 -->
    <div class="bottom-section">
      <div class="bottom-container">
        <div class="order-summary">
          <div class="summary-content">
            <div class="summary-item">
              <span>商品总数：</span>
              <span>{{ totalItems }}件</span>
            </div>
            <div class="summary-item total">
              <span>总计：</span>
              <span class="total-amount">¥{{ totalPrice }}</span>
            </div>
          </div>
        </div>

        <div class="payment-methods">
          <el-button class="payment-button" type="primary" @click="handlePayment('支付宝')">
            <el-icon><Money /></el-icon>
            支付宝
          </el-button>
          <el-button class="payment-button" type="primary" @click="handlePayment('微信支付')">
            <el-icon><ChatDotRound /></el-icon>
            微信支付
          </el-button>
          <el-button class="payment-button" type="primary" @click="handlePayment('银行卡支付')">
            <el-icon><CreditCard /></el-icon>
            银行卡支付
          </el-button>
        </div>
      </div>
    </div>

    <!-- 购买成功弹窗 -->
    <el-dialog
        title="支付成功"
        v-model="showPaymentSuccess"
        width="30%"
    >
      <span>购买成功！您的订单已完成支付。</span>
      <template #footer>
        <el-button @click="goBackToHome">关闭</el-button>
      </template>
    </el-dialog>

  </div>
</template>

<script setup>
import { ref, computed, reactive } from 'vue';
import { useRouter } from 'vue-router';
import { ElButton, ElDialog, ElMessage } from 'element-plus';
import request from "@/utils/request.js";


// 商品数据
const data = reactive({
  product: []
});

// 加载购物车数据
const loadcart = () => {
  request.get("/cart/selectAll").then(res => {
    if (res.code === "200") {
      data.product = res.data;
    } else {
      ElMessage.error(res.msg);
    }
  });
};

loadcart();

const showPaymentSuccess = ref(false); // 控制购物车弹窗的显示
// 增加商品数量
const increase = (item) => {
  item.quantity += 1;
  request.post("/cart/increasequantity", item).then((res) => {
    loadcart();
  });
  console.log('Increasing quantity:', item); // 调试日志
};

// 减少商品数量
const decrease = (item) => {
  if (item.quantity > 0) {
    item.quantity -= 1;
    request.post("/cart/decreasequantity", item).then((res) => {
      loadcart();
    });
  }
};



// 计算总价
const totalPrice = computed(() => {
  return data.product.reduce((sum, product) => sum + product.price * product.quantity, 0).toFixed(2);
});

// 导航到购物车页面
const router = useRouter();
const goBackToCart = () => {
  router.push({ path: '/' });
};
// 添加计算总商品数量
const totalItems = computed(() => {
  return data.product.reduce((sum, product) => sum + product.quantity, 0);
});
// 支付处理函数
const handlePayment = (method) => {
  console.log(`${method} 支付中...`);
  showPaymentSuccess.value = true;
  // 触发清除购物车操作
  request.delete("/cart/deleteAll").then((res) => {
    if (res.code === "200") {
      console.log("购物车已清空");
      // 显示支付成功弹窗
    }
  }).catch(err => {
    ElMessage.error('支付失败，请稍后再试');
  });
};

// 关闭弹窗并跳转到首页
const goBackToHome = () => {
  showPaymentSuccess.value = false;
  router.push('/'); // 跳转到首页
};
</script>

<style scoped>
.checkout-page {
  padding: 20px;
  color: #333;
  background-color: #fff7e6;
  font-family: Arial, sans-serif;
  height: 100vh; /* 确保背景色填充整个屏幕 */
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.back-to-cart {
  margin-bottom: 20px;
}

.back-button {
  background-color: #ff9f00;
  color: white;
  border: none;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px 20px;
}

.header {
  text-align: center;
  margin-bottom: 20px;
}

.header h1 {
  color: #e87e00;
}

.product-list {
  margin-bottom: 140px;
  overflow-y: auto;
  flex-grow: 1;
  max-height: calc(100vh - 200px); /* 限制最大高度，避免超出 */
}



.payment-methods {
  display: flex;
  gap: 12px;
}
.payment-button {
  min-width: 120px;
  height: 40px;
  border-radius: 4px;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background-color: #ff9f00;
  border-color: #ff9f00;
  transition: all 0.3s ease;
}

.payment-button:hover {
  background-color: #e87e00;
  border-color: #e87e00;
  transform: translateY(-1px);
}


.payment-button .el-icon {
  margin-right: 4px;
}
.el-dialog .el-button {
  background-color: #ff9f00;
  border-color: #ff9f00;
}


.product-content {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  padding: 20px;
  align-items: center;
  gap: 20px;
}

.product-image {
  width: 80px;
  height: 80px;
  overflow: hidden;
  border-radius: 6px;
  flex-shrink: 0;
}

.product-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}



.name-image-section {
  display: flex;
  align-items: center;
  gap: 20px;
}

.product-name {
  font-size: 16px;
  color: #333;
  margin: 0;
  max-width: 200px;
  white-space: nowrap; /* 防止文字换行 */
  line-height: 1.4;
  overflow: hidden;
  text-overflow: ellipsis;
}

.price {
  font-size: 18px;
  color: #ff6b00;
  font-weight: bold;
  flex: 1;
  text-align: center;
  justify-self: center;
}

.quantity-control {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-self: end ;
}

.quantity {
  min-width: 35px;
  text-align: center;
  font-size: 15px;
}


.order-summary {
  flex: 1;
}

.summary-content {
  max-width: 300px;
  margin-left: auto;
  margin-left: 40px;
}

.summary-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
  font-size: 16px;
  color: #333;
  font-family: 'PingFang SC','Microsoft YaHei',s;
}

.summary-item.total {
  border-top: 1px solid #ebeef5;
  padding-top: 15px;
  margin-top: 15px;
  font-size: 18px;
  font-weight: 500;
}

.total-amount {
  font-size: 28px;
  color: #ff6b00;
  font-weight: bold;
  font-family: 'DIN Alternate','Arital',sans-seri;
}

.bottom-section {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  width: 95%;
  margin: 0 auto;
  background-color: #fff;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
  padding: 15px 0;
  z-index: 1000;
  border-radius: 12px 12px 0 0;
  max-height: 120px; /* 设置最大高度，避免溢出 */
  overflow: hidden; /* 确保底部区域不引起滚动 */
}

.bottom-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.product-row {
  padding: 15px 20px;
}

.product-row.with-border {
  border-bottom: 1px solid #eee;
}
.unified-product-card {
  margin-bottom: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}
</style>
