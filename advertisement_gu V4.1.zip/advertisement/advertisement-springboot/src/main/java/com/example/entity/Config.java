package com.example.entity;

public class Config {
    private Integer id;
    private Integer userMoney;
    private Integer webMoney;
    private Integer admMoney;
    private String time;
    private Integer day;
    private Integer money;
    private String moneyTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserMoney() {
        return userMoney;
    }

    public void setUserMoney(Integer userMoney) {
        this.userMoney = userMoney;
    }

    public Integer getWebMoney() {
        return webMoney;
    }

    public void setWebMoney(Integer webMoney) {
        this.webMoney = webMoney;
    }

    public Integer getAdmMoney() {
        return admMoney;
    }

    public void setAdmMoney(Integer admMoney) {
        this.admMoney = admMoney;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    public String getMoneyTime() {
        return moneyTime;
    }

    public void setMoneyTime(String moneyTime) {
        this.moneyTime = moneyTime;
    }
}
