package com.example.service;

import com.example.entity.WebUser;
import com.example.exception.CustomException;
import com.example.mapper.WebUserMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

@Service
public class WebUserService {
    @Resource
    private WebUserMapper webUserMapper;

    public WebUser selectByUser(String user) {
        WebUser webUser = webUserMapper.selectByUser(user);
        if(webUser == null){//没查询到任何用户
            throw new CustomException("500", "没有该用户");
        }
        return webUser;
    }

    public void insert(String user) {
        webUserMapper.insert(user);
    }
}
