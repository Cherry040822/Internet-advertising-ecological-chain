package com.example.controller;

import com.example.common.Result;
import com.example.entity.Advertisement;
import com.example.entity.News;
import com.example.service.NewsService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/news")
public class NewsController {

    @Resource
    private NewsService newsService;

    @PostMapping("/add")
    public Result save(@RequestBody News news) {
        try {
            newsService.add(news);
            return Result.success();
        } catch (Exception e) {
            return Result.error("500","保存失败: " + e.getMessage());
        }
    }
    @GetMapping("/selectPage")
    public Result selectPage(News news,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "3") Integer pageSize) {
        PageInfo<News> pageinfo=newsService.selectPage(news,pageNum,pageSize);
        return Result.success(pageinfo);
    }

    @PutMapping("/updateClick/{advertisementId}")
    public Result updateClickByAdvertisementId(@PathVariable Integer advertisementId) {
        newsService.updateClickByAdvertisementId(advertisementId);
        return Result.success();
    }

    @GetMapping("/selectByAdvertisementId/{advertisementId}")
    public Result selectByAdvertisementId(@PathVariable Integer advertisementId) {
        return Result.success(newsService.selectMoneyByAdvertisementId(advertisementId));
    }

    @PutMapping("/updateStatus")
    public Result updateStatus() {
        newsService.updateStatus();
        return Result.success();
    }

    @GetMapping("/selectByUserId/{userId}")
    public Result selectByUserId(@PathVariable Integer userId) {
        return Result.success(newsService.selectMoneyByUserId(userId));
    }
    @GetMapping("/selectAllClick")
    public Result selectAllClick() {
        Integer sumClick= newsService.selectAllClick();
        return Result.success(sumClick);
    }
    @GetMapping("/selectAll")
    public Result selectAll() {
        return Result.success(newsService.selectUrl());
    }
}