package com.example.mapper;

import com.example.entity.Config;

import java.util.List;

public interface ConfigMapper {

    List<Config> selectAll();
}
