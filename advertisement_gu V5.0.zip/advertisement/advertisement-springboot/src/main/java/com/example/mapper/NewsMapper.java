package com.example.mapper;

import com.example.entity.Advertisement;
import com.example.entity.News;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;
import java.util.List;
import java.util.Map;

public interface NewsMapper {
    void insert(News news);

    boolean selectByAdvertisementId(Integer advertisementId);

    List<News> selectAll(News news);

    void updateClickByAdvertisementId(Integer advertisementId);

    News selectMoneyByAdvertisementId(Integer advertisementId);

    @Delete("delete from  `advertisement_news` where advertisement_id = #{id}")
    void deleteByAdvertisementId(Integer id);

    void update(Advertisement advertisement);

    void updateStatus();

    boolean selectByUserId(Integer userId);

    News selectMoneyByUserId(Integer userId);

    void sumClick();

    List<Map<String, Object>> selectAdvertisementData();

    List<Map<String, Object>> groupByAdvertisementClicks();

    Integer selectAllClick();

    List<News> selectUrl();

    @Select("select * from `advertisement_news` where status='已投放第三方平台'")
    List<News> findAllAds();

    @Select("select * from `advertisement_news` where category=#{category} and status='已投放第三方平台'")
    List<News> findByCategory(String category);

    @Select("select * from `advertisement_news` where category != #{firstCategory}")
    List<News> findAdsExcludingCategory(String firstCategory);

    @Select("select * from `advertisement_news` where category != #{firstCategory} and category != #{secondCategory}")
    List<News> findAndSecondAdsExcludingCategory(String firstCategory, String secondCategory);
}
