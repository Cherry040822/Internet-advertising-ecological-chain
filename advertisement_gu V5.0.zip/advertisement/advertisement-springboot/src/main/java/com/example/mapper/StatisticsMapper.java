package com.example.mapper;

import com.example.entity.Statistics;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface StatisticsMapper {

    @Insert("INSERT INTO daily (user_id, advertisement_id, date) VALUES (#{userId}, #{advertisementId}, #{date})")
    void insertDailyData(Integer userId, Integer advertisementId, String date);

    void updateDailyClicks(Integer advertisementId, Integer shoppingClick, Integer newsClick, String date);

    List<Map<String, Object>> groupByAdvertisementForMonth(String currentMonth);

    void insertMonthlyData(String currentMonth, Integer userId, Integer advertisementId, Integer shoppingClickSum, Integer newsClickSum);

    List<Map<String, Object>> groupByAdvertisementForYear(String currentYear);

    void insertAnnualData(String currentYear, Integer userId, Integer advertisementId, Integer shoppingClickSum, Integer newsClickSum);

    @Select("SELECT COUNT(*) FROM monthly WHERE advertisement_id = #{advertisementId} AND `date` = #{currentMonth}")
    Integer countMonthlyRecord(Integer advertisementId, String currentMonth);

    void updateMonthlyData(String currentMonth, Integer userId, Integer advertisementId, Integer shoppingClickSum, Integer newsClickSum);

    void updateAnnualData(String currentYear, Integer userId, Integer advertisementId, Integer shoppingClickSum, Integer newsClickSum);

    @Select("SELECT COUNT(*) FROM annual WHERE advertisement_id = #{advertisementId} AND `date` = #{currentYear}")
    Integer countAnnualRecord(Integer advertisementId, String currentYear);

    List<Statistics> dailySelectByAdvertisementId(Integer advertisementId);

    List<Statistics> monthlySelectByAdvertisementId(Integer advertisementId);

    List<Statistics> annualSelectByAdvertisementId(Integer advertisementId);

    List<Statistics> dailySelectByUserId(Integer userId);

    List<Statistics> dailySelectAll();

    List<Statistics> monthlySelectByUserId(Integer userId);

    List<Statistics> monthlySelectAll();

    List<Statistics> annualSelectByUserId(Integer userId);

    List<Statistics> annualSelectAll();

    boolean selectAdvertisementId(Integer advertisementId,String date);
}
