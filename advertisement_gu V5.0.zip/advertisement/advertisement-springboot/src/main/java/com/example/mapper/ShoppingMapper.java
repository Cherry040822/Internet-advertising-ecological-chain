package com.example.mapper;

import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface ShoppingMapper {
    void insert(Shopping shopping);

    boolean selectByAdvertisementId(Integer advertisementId);

    List <Shopping> selectAll(Shopping shopping);

    void updateClickByAdvertisementId(Integer advertisementId);

    Shopping selectMoneyByAdvertisementId(Integer advertisementId);

    @Delete("delete from  `advertisement_shopping` where advertisement_id = #{id}")
    void deleteByAdvertisementId(Integer id);

    void update(Advertisement advertisement);

    void updateStatus();

    boolean selectByUserId(Integer userId);

    Shopping selectMoneyByUserId(Integer userId);

    void sumClick();

    List<Map<String, Object>> selectAdvertisementData();

    List<Map<String, Object>> groupByAdvertisementClicks();

    Integer selectAllClick();

    List<Shopping> selectUrl();

    @Select("select * from `advertisement_shopping` where category=#{category} and status='已投放第三方平台'")
    List<Shopping> findByCategory(String category);

    @Select("select * from `advertisement_shopping` where status='已投放第三方平台'")
    List<Shopping> findAllAds();

    @Select("select * from `advertisement_shopping` where category != #{firstCategory}")
    List<Shopping> findAdsExcludingCategory(String firstCategory);

    @Select("select * from `advertisement_shopping` where category != #{firstCategory} and category != #{secondCategory}")
    List<Shopping> findAndSecondAdsExcludingCategory(String firstCategory, String secondCategory);

}
