package com.example.mapper;
import com.example.entity.WebUser;
import org.apache.ibatis.annotations.*;
public interface WebUserMapper {
    @Select("select * from `web_user` where user = #{user}")
    WebUser selectByUser(String user);

    void insert(String user);
}
