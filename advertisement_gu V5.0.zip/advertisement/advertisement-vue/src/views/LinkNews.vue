<template>
  <div style="display: flex;align-content: center;justify-content: center;width: 150px;height: 150px">
    <img :src="data.image" alt="" @click="goToLinkDetails"/>
  </div>
</template>

<script setup>
import {onMounted, reactive} from "vue";
import request from '@/utils/request.js'
import {useRoute} from "vue-router";
import Cookies from "js-cookie";

const data = (reactive({
  image:'',
  category:'',
}))
const route = useRoute();
const adId = route.params.id;

const load = () => {
  request.get(`/advertisementList/selectUrlById/${adId}`).then(res =>{
    data.image = res.data.image;
    data.category=res.data.category;
  })
}

const goToLinkDetails = () => {
  Cookies.set('categoryClick', data.category, {
    path: '/',
    domain: '.hebiu.cn',
    sameSite: 'None',
    secure: true
  });
  Cookies.set('categoryClickTimestamp', Date.now(), {
    path: '/',
    domain: '.hebiu.cn',
    sameSite: 'None',
    secure: true
  });
  window.open(`/LinkDetails/${adId}`, '_blank')
  request.put(`/news/updateClick/${adId}`).then(res => {

  })
}

onMounted( () => {
  load()
})
</script>

<style scoped>

</style>