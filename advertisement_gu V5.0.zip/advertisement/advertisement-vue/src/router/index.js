import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/Index',
      name: 'Index',
      component: () => import('@/views/Index.vue'),
      meta: { title: '广告投放与管理' },
      children: [
        { path: '/AdvertisementManage',meta: { title: '广告信息' }, component: () => import('@/views/AdvertisementManage.vue')},
        { path: '/UserManage',meta: { title: '用户信息' }, component: () => import('@/views/UserManage.vue')},
        { path: '/AdvertisingManage', meta: { title: '投放管理' }, component: () => import('@/views/ConfigManage.vue')},
        { path: '/AdvertisementList',meta: { title: '广告投放' }, component: () => import('@/views/AdvertisementList.vue')},
        { path: '/AdvertisementLook',meta: { title: '广告投放' }, component: () => import('@/views/AdvertisementLook.vue')},
        { path: '/Person', meta: { title: '个人资料' }, component: () => import('@/views/Person.vue')},
        { path: '/UserData',meta: { title: '整体数据' }, component: () => import('@/views/UserData.vue')},
        { path: '/admData',meta: { title: '整体数据' }, component: () => import('@/views/admData.vue')},
        { path: '/webData',meta: { title: '整体数据' }, component: () => import('@/views/webData.vue')},
        ]
    },
    { path: '/', name: 'Login', meta:{ title:'登录' }, component: () => import('@/views/Login.vue')},
    { path: '/Register', name: 'Register', meta:{ title:'注册' }, component: () => import('@/views/Register.vue')},
    { path: '/DataDetails/:id', name: 'DataDetails', meta: { title: '数据详情' }, component: () => import('@/views/DataDetails.vue'),props:true},
    { path: '/LinkShopping/:id', name: 'LinkShopping', meta: { title: '购物广告内嵌' }, component: () => import('@/views/LinkShopping.vue')},
    { path: '/LinkNews/:id', name: 'LinkNews', meta: { title: '新闻广告内嵌' }, component: () => import('@/views/LinkNews.vue')},
    { path: '/LinkDetails/:id', name: 'LinkDetails', meta: { title: '广告详情' }, component: () => import('@/views/LinkDetails.vue'),props:true},
    { path: '/HandleCookies', name: 'HandleCookies', meta: { title: '广告详情' }, component: () => import('@/views/HandleCookie.vue')},
  ],
})

router.beforeEach((to,from,next) => {
  document.title = to.meta.title
  next()
})
export default router
