package com.example.service;

import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import com.example.mapper.AdvertisementMapper;
import com.example.mapper.ShoppingMapper;
import com.example.mapper.UserRateMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ShoppingService {

    @Resource
    ShoppingMapper shoppingMapper;

    @Resource
    UserRateMapper userRateMapper;

    @Resource
    UserRateService userRateService;

    public void add(Shopping shopping) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        shopping.setCreateTime(sdf.format(new Date()));
        shopping.setStatus("已提交平台");
        shopping.setUrl("https://xp.hebiu.cn/LinkShopping/"+shopping.getAdvertisementId());
        shoppingMapper.insert(shopping);
    }

    public boolean selectByAdvertisementId(Integer advertisementId) {
        System.out.println(shoppingMapper.selectByAdvertisementId(advertisementId));
        if(shoppingMapper.selectByAdvertisementId(advertisementId)){
            return true;
        }else {
            return false;
        }
    }

    public PageInfo<Shopping> selectPage( Shopping shopping,
                                          Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<Shopping> list=shoppingMapper.selectAll(shopping);
        return PageInfo.of(list);
    }

    public void updateClickByAdvertisementId(Integer advertisementId) {
        shoppingMapper.updateClickByAdvertisementId(advertisementId);
    }

    public Shopping selectMoneyByAdvertisementId(Integer advertisementId) {
        return shoppingMapper.selectMoneyByAdvertisementId(advertisementId);
    }

    public void updateStatus() {
        shoppingMapper.updateStatus();
    }

    public boolean selectByuserId(Integer userId) {
        if(shoppingMapper.selectByUserId(userId)){
            return true;
        }else {
            return false;
        }
    }

    public Shopping selectMoneyByUserId(Integer userId) {
        return shoppingMapper.selectMoneyByUserId(userId);
    }

    public Integer selectAllClick() {
        return shoppingMapper.selectAllClick();
    }

    public List<Shopping> selectUrl() {
        return shoppingMapper.selectUrl();
    }

    public Map<String, Integer> getCategoryGradeMap(String user) {

        List<Map<String, Object>> userRateList = userRateMapper.findCategoriesByUser(user);
        Map<String, Integer> categoryGradeMap = new HashMap<>();

        // 将用户的 category 和 grade 填充到 Map 中
        if (userRateList != null) {
            for (Map<String, Object> record : userRateList) {
                // 确保 record 不是 null 且包含有效的 category 和 grade
                if (record != null && record.get("category") != null && record.get("grade") != null) {
                    String category = (String) record.get("category");
                    Integer grade = (Integer) record.get("grade");
                    categoryGradeMap.put(category, grade);
                }
            }
        }

        // 将 Map 转换成 List<Map.Entry<String, Integer>>，然后按 grade 排序
        List<Map.Entry<String, Integer>> sortedList = categoryGradeMap.entrySet()
                .stream()
                .sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue())) // 从大到小排序
                .collect(Collectors.toList());

        // 取前三个元素
        List<Map.Entry<String, Integer>> topThreeList = sortedList.stream()
                .limit(3) // 只取前 3 个
                .collect(Collectors.toList());

        // 使用 LinkedHashMap 保持排序顺序
        Map<String, Integer> topThreeCategoryGradeMap = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : topThreeList) {
            topThreeCategoryGradeMap.put(entry.getKey(), entry.getValue());
        }

        return topThreeCategoryGradeMap;
    }

    public List<Shopping> getAdvertisements(String user) {
        // 获取前三个 category 和 grade
        Map<String, Integer> topThreeCategoryGradeMap = getCategoryGradeMap(user);
        System.out.println(topThreeCategoryGradeMap);
        // 存放查询结果的三个 List
        List<Shopping> category1List = new ArrayList<>();
        List<Shopping> category2List = new ArrayList<>();
        List<Shopping> category3List = new ArrayList<>();


        // 如果 topThreeCategoryGradeMap 为空，获取所有广告
        if (topThreeCategoryGradeMap.isEmpty()) {
            // 查询所有广告，并打乱
            List<Shopping> allAds = shoppingMapper.findAllAds();
            Collections.shuffle(allAds); // 打乱列表

            // 随机抽取六个元素
            return allAds.size() >= 6 ? allAds.subList(0, 6) : allAds;
        }

        // 根据 topThreeCategoryGradeMap 中的 category 查询 advertisement_shopping 表中的记录
        for (String category : topThreeCategoryGradeMap.keySet()) {
            // 查询数据库中与 category 对应的记录
            List<Shopping> ads = shoppingMapper.findByCategory(category);

            // 将结果分别存入不同的 List 中
            if (category.equals(topThreeCategoryGradeMap.keySet().toArray()[0])) {
                category1List = ads;
            } else if (category.equals(topThreeCategoryGradeMap.keySet().toArray()[1])) {
                category2List = ads;
            } else if (category.equals(topThreeCategoryGradeMap.keySet().toArray()[2])) {
                category3List = ads;
            }
        }

        // 结果列表
        List<Shopping> resultList = new ArrayList<>();

        // 随机从 category1List 中选取 3 个元素
        if (category1List.size()>3) {
            Collections.shuffle(category1List);
            resultList.addAll(category1List.subList(0, 3)); // 从打乱后的列表中取前三个
        }

        // 随机从 category2List 中选取 2 个元素
        if(category2List.size() == 0){
            String firstCategory = topThreeCategoryGradeMap.keySet().toArray()[0].toString();
            List<Shopping> ads = shoppingMapper.findAdsExcludingCategory(firstCategory); // 这里使用新的查询方法排除第一个 category
            Collections.shuffle(ads); // 打乱列表
            resultList.addAll(ads.subList(0, Math.min(ads.size(), 3))); // 从打乱后的列表中取前三个
            Collections.shuffle(resultList);
            return resultList;
        }else{
            if (category2List.size()>2){
                Collections.shuffle(category2List);
                resultList.addAll(category2List.subList(0, 2)); // 从打乱后的列表中取前两个
            }
        }

        if(category3List.size() == 0){
            String firstCategory = topThreeCategoryGradeMap.keySet().toArray()[0].toString();
            String secondCategory = topThreeCategoryGradeMap.keySet().toArray()[1].toString();
            List<Shopping> ads = shoppingMapper.findAndSecondAdsExcludingCategory(firstCategory,secondCategory); // 这里使用新的查询方法排除第一个 category
            Collections.shuffle(ads); // 打乱列表
            resultList.addAll(ads.subList(0,1)); //
            Collections.shuffle(resultList);
            return resultList;
        }else{
            if (category3List.size()>1){
                Collections.shuffle(category3List);
                resultList.addAll(category3List.subList(0, 1)); // 从打乱后的列表中取一个
            }
        }
        Collections.shuffle(resultList);
        return resultList; // 返回合并后的列表
    }

    public List<Shopping> getAdvertisementsPlus(String user) {
        List<Map<String, Object>> userRateList = userRateService.getrecommend(user);
        Map<String, Double> categoryGradeMap = new HashMap<>();
        // 将用户的 category 和 grade 填充到 Map 中
        if (userRateList != null) {
            for (Map<String, Object> record : userRateList) {
                // 确保 record 不是 null 且包含有效的 category 和 grade
                if (record != null && record.get("category") != null && record.get("grade") != null) {
                    String category = (String) record.get("category");
                    Double grade = (Double) record.get("grade");
                    categoryGradeMap.put(category, grade);
                }
            }
        }
        // 将 Map 转换成 List<Map.Entry<String, Integer>>，然后按 grade 排序
        List<Map.Entry<String, Double>> sortedList = categoryGradeMap.entrySet()
                .stream()
                .sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue())) // 从大到小排序
                .collect(Collectors.toList());

        List<Map.Entry<String, Double>> topThreeList = sortedList.stream()
                .limit(3) // 只取前 3 个
                .collect(Collectors.toList());

        // 使用 LinkedHashMap 保持排序顺序
        Map<String, Double> topThreeCategoryGradeMap = new LinkedHashMap<>();
        for (Map.Entry<String, Double> entry : topThreeList) {
            topThreeCategoryGradeMap.put(entry.getKey(), entry.getValue());
        }

        // 存放查询结果的三个 List
        List<Shopping> category1List = new ArrayList<>();
        List<Shopping> category2List = new ArrayList<>();
        List<Shopping> category3List = new ArrayList<>();


        // 如果 topThreeCategoryGradeMap 为空，获取所有广告
        if (topThreeCategoryGradeMap.isEmpty()) {
            // 查询所有广告，并打乱
            List<Shopping> allAds = shoppingMapper.findAllAds();
            Collections.shuffle(allAds); // 打乱列表

            // 随机抽取六个元素
            return allAds.size() >= 6 ? allAds.subList(0, 6) : allAds;
        }
        // 根据 topThreeCategoryGradeMap 中的 category 查询 advertisement_shopping 表中的记录
        for (String category : topThreeCategoryGradeMap.keySet()) {
            // 查询数据库中与 category 对应的记录
            List<Shopping> ads = shoppingMapper.findByCategory(category);

            // 将结果分别存入不同的 List 中
            if (category.equals(topThreeCategoryGradeMap.keySet().toArray()[0])) {
                category1List = ads;
            } else if (category.equals(topThreeCategoryGradeMap.keySet().toArray()[1])) {
                category2List = ads;
            } else if (category.equals(topThreeCategoryGradeMap.keySet().toArray()[2])) {
                category3List = ads;
            }
        }

        // 结果列表
        List<Shopping> resultList = new ArrayList<>();

        // 随机从 category1List 中选取 3 个元素
        if (category1List.size()>3) {
            Collections.shuffle(category1List);
            resultList.addAll(category1List.subList(0, 3)); // 从打乱后的列表中取前三个
        }

        // 随机从 category2List 中选取 2 个元素
        if(category2List.size() == 0){
            String firstCategory = topThreeCategoryGradeMap.keySet().toArray()[0].toString();
            List<Shopping> ads = shoppingMapper.findAdsExcludingCategory(firstCategory); // 这里使用新的查询方法排除第一个 category
            Collections.shuffle(ads); // 打乱列表
            resultList.addAll(ads.subList(0, Math.min(ads.size(), 3))); // 从打乱后的列表中取前三个
            Collections.shuffle(resultList);
            return resultList;
        }else{
            if (category2List.size()>2){
                Collections.shuffle(category2List);
                resultList.addAll(category2List.subList(0, 2)); // 从打乱后的列表中取前两个
            }
        }

        if(category3List.size() == 0){
            String firstCategory = topThreeCategoryGradeMap.keySet().toArray()[0].toString();
            String secondCategory = topThreeCategoryGradeMap.keySet().toArray()[1].toString();
            List<Shopping> ads = shoppingMapper.findAndSecondAdsExcludingCategory(firstCategory,secondCategory); // 这里使用新的查询方法排除第一个 category
            Collections.shuffle(ads); // 打乱列表
            resultList.addAll(ads.subList(0,1)); //
            Collections.shuffle(resultList);
            return resultList;
        }else{
            if (category3List.size()>1){
                Collections.shuffle(category3List);
                resultList.addAll(category3List.subList(0, 1)); // 从打乱后的列表中取一个
            }
        }
        Collections.shuffle(resultList);
        System.out.println("list        "+resultList);
        return resultList;
    }
}
