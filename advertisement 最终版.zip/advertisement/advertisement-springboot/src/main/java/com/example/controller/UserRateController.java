package com.example.controller;
import com.example.entity.UserRate;
import com.example.common.Result;
import com.example.service.UserRateService;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/userRate")
public class UserRateController {
    @Resource
    UserRateService userRateService;

    @PostMapping("/add")
    public Result add(@RequestBody UserRate userRate) {
        userRateService.add(userRate);
        return Result.success();
    }


    @GetMapping("/recommend")
    public Result recommend(@RequestParam String user) {
        try{
            List<Map<String, Object>> recommend = userRateService.getrecommend(user);

            return Result.success(recommend);
        }catch (Exception e){
            return Result.error("500","推荐失败: " + e.getMessage());
        }
    }

}
