package com.example.controller;
import com.example.entity.WebUser;
import com.example.common.Result;
import com.example.service.WebUserService;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
@RestController
@RequestMapping("/webUser")
public class WebUserController {
    @Resource WebUserService webUserService;

    @GetMapping("/selectByUser/{user}")
    public Result selectByUser(@PathVariable String user) {
        WebUser webUser = webUserService.selectByUser(user);
        return Result.success(webUser);
    }

    @GetMapping("add/{user}")
    public Result insert(@PathVariable String user){
        webUserService.insert(user);
        return Result.success();
    }
}
