<template>
  <div style="margin:100px">
    <el-row>
      <img :src="data.image" alt="" style="height: 500px;"/>
    </el-row>
    <el-row>
      <el-card>
        {{data.title}}
      </el-card>
    </el-row>
  </div>


</template>

<script setup>
import {onMounted, reactive} from "vue";
import request from '@/utils/request.js'
import {useRoute} from "vue-router";

const data = (reactive({
  image:'',
  content:'',
}))
const route = useRoute();
const adId = route.params.id;

const load = () => {
  request.get(`/advertisementList/selectUrlById/${adId}`).then(res =>{
    data.image = res.data.image;
    data.content = res.data.content;
  })
}
onMounted(() =>{
  load()
})
</script>

<style scoped>

</style>