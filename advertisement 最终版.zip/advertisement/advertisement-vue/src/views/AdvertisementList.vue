<template>
  <div>
    <!-- 搜索区域 -->
    <el-card style="margin-bottom: 5px">
      <el-input prefix-icon="Search" v-model="data.searchForm.title" placeholder="请输入广告标题" style="max-width: 300px">
        <template #prepend>
          <el-select v-model="data.searchForm.category" placeholder="类别" clearable @change="load" style="width: 80px">
            <el-option v-for="item in data.categories"
                       :key="item.id"
                       :value-on-clear="null"
                       :label="item.category"
                       :value="item.category"/>
          </el-select>
        </template>
      </el-input>
      <el-button type="plain" @click="load"><el-icon style="vertical-align: middle"><Search/></el-icon></el-button>
      <el-button type="plain" @click="reset" style="margin: 0"><el-icon style="vertical-align: middle"><RefreshRight/></el-icon></el-button>
    </el-card>

    <el-card>
      <!-- 操作按钮区域 -->
      <template #header>
        <el-button type="primary" plain :icon="CirclePlus" @click="handleAdd">新增广告</el-button>
        <el-button type="danger" plain :icon="Delete" @click="handleBatchDelete">批量删除</el-button>
      </template>

      <!-- 广告列表 -->
      <el-table :data="data.tableData" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="title" label="广告标题" show-overflow-tooltip/>
        <el-table-column label="广告图片" width="120">
          <template #default="scope">
            <img :src="scope.row.image"

                      style="width: 100px; height: 100px;"/>
          </template>
        </el-table-column>
        <el-table-column prop="content" label="详细内容" show-overflow-tooltip/>
        <el-table-column prop="category" label="分类"/>
        <el-table-column prop="keywords" label="关键词"/>
        <el-table-column prop="status" label="状态">
          <template #default="scope">
            <el-tag
                :key="scope.row.status"
                :type="getTypeByStatus(scope.row.status)"
                effect="light"
                round
            >
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="300">
          <template #default="scope">
            <el-button link type="primary" :icon="Edit" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button link type="danger" :icon="Delete" @click="delByTitle(scope.row.id)">删除</el-button>
            <el-button link type="success" :icon="Upload" @click="handleUpload(scope.row)" v-if="scope.row.status==='未投放'">投放</el-button>
            <el-button link type="info" :icon="DataAnalysis" @click="handleData(scope.row)" v-if="scope.row.status==='已投放第三方平台'">数据</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <template #footer>
        <div style="display: flex;justify-content: center">
          <el-pagination
              v-model:current-page="pagination.currentPage"
              v-model:page-size="pagination.pageSize"
              :page-sizes="[10, 20, 50, 100]"
              :size="pagination.size"
              :disabled="pagination.disabled"
              :background="pagination.background"
              :total="pagination.total"
              layout="total, sizes, prev, pager, next, jumper"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
          />
        </div>
      </template>
    </el-card>

    <!-- 新增/编辑广告弹窗 -->
    <el-dialog
        v-model="data.dialogVisible"
        :title="data.dialogType === 'add' ? '新增广告' : '编辑广告'"
        width="50%">
      <el-form :model="data.adForm" label-width="100px">
        <el-form-item label="广告标题">
          <el-input v-model="data.adForm.title" placeholder="请输入广告标题"/>
        </el-form-item>
        <el-form-item label="广告图片">
          <el-upload
              class="avatar-uploader"
              action="https://xp.hebiu.cn:9090/files/upload"
              :show-file-list="false"
              :on-success="handleUploadSuccess">
            <img v-if="data.adForm.image" :src="data.adForm.image" class="avatar"/>
            <el-icon v-else class="avatar-uploader-icon"><Plus/></el-icon>
          </el-upload>
        </el-form-item>
        <el-form-item label="详细内容">
          <el-input v-model="data.adForm.content" type="textarea" rows="4" placeholder="请输入广告详细内容"/>
        </el-form-item>
        <el-form-item label="广告分类">
          <el-select v-model="data.adForm.category" placeholder="请选择分类">
            <el-option v-for="item in data.categories"
                       :key="item.id"
                       :label="item.category"
                       :value="item.category"/>
          </el-select>
        </el-form-item>
        <el-form-item label="关键词">
          <el-input v-model="data.adForm.keywords" placeholder="请输入关键词，多个关键词用逗号分隔"/>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="data.dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="data.dialogType === 'add' ? handleSubmit() : handleUpdate()">确定</el-button>
        </span>
      </template>
    </el-dialog>

    <el-dialog v-model="data.uploadVisible" width="50%" title="投放广告">
      <el-form-item label="投放网站">
        <el-select v-model="data.webName" placeholder="请选择投放网站" multiple>
          <el-option v-for="item in data.webNames"
                     :key="item.webName"
                     :label="item.webName"
                     :value="item.webName"/>
        </el-select>
      </el-form-item>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="data.UploadVisible = false">取消</el-button>
          <el-button type="primary" @click="UploadToWeb">确定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import {ref, reactive, onMounted} from 'vue'
import {CirclePlus, DataAnalysis, Delete, Edit, Plus, Search, Upload} from '@element-plus/icons-vue'
import {ElMessage, ElMessageBox} from "element-plus";
import request from "@/utils/request.js";
import router from "@/router/index.js";
import Cookies from "js-cookie";

Cookies.set('ad_platform_user_behavior',1234),{
  path: '/',
  domain:'',
  sameSite:'Lax'
}

// 表格数据
const data = reactive( {
  selectedRows:[],
  categories:[],
  category:'',
  id:'',
  searchForm: {
    category: '',
    title: ''
  },
  tableData:[],
  adForm:{
    id:'',
    title: '',
    image: '',
    content: '',
    category: '',
    keywords: '',
    userId: JSON.parse(localStorage.getItem('user')).id,
    userName: JSON.parse(localStorage.getItem('user')).name
  },
  dialogVisible: false,
  dialogType: 'add',
  uploadVisible: false,
  webNames:[],
  webName:[],
})

//获取状态标签格式
const getTypeByStatus = (status) => {
  if (status === '未投放'){
    return 'info'
  }else if (status === '已提交平台'){
    return 'primary'
  }else if (status === '已投放第三方平台'){
    return 'success'
  }
}
// 重置搜索
const reset = () => {
  data.searchForm.category = ''
  data.searchForm.title = ''
  load()
}

// 新增广告
const handleAdd = (row) => {
  data.dialogType= 'add'
  data.dialogVisible= true
  data.adForm = {
    id:'',
    title: '',
    image: '',
    content: '',
    category: '',
    keywords: '',
    userId: JSON.parse(localStorage.getItem('user')).id,
    userName: JSON.parse(localStorage.getItem('user')).name
  }
}

// 编辑广告
const handleEdit = (row) => {
  data.dialogType= 'update'
  data.dialogVisible= true
  data.adForm = {
    id:row.id,
    title: row.title,
    image: row.image,
    content: row.content,
    category: row.category,
    keywords: row.keywords,
    userId: JSON.parse(localStorage.getItem('user')).id,
    userName: JSON.parse(localStorage.getItem('user')).name,
    status:row.status,
  }
}

//投放广告
const handleUpload = (row) => {
  data.uploadVisible = true
  data.adForm = {
    id:row.id,
    title: row.title,
    image: row.image,
    content: row.content,
    category: row.category,
    keywords: row.keywords,
    userId: JSON.parse(localStorage.getItem('user')).id,
    userName: JSON.parse(localStorage.getItem('user')).name
  }
  data.webName = []
}

//单个数据详情
const handleData = (row) => {
  window.open(`/DataDetails/${row.id}`, '_blank');
}
//单个删除
const delByTitle = (id) => {
  ElMessageBox.confirm('删除数据后无法恢复，您确定要删除吗？','删除确认',{type:'warning'}).then(() =>{
    request.delete('/advertisementList/deleteById/' +id).then(res =>{
      ElMessage.success('删除成功')
      load() //删除后重新加载最新的数据
    }).catch(() => {
      ElMessage.error('删除失败');
    });
  }).catch()
}

// 批量删除
const handleBatchDelete = () => {
  // TODO: 实现批量删除逻辑
  console.log(data.selectedRows)
  if(data.selectedRows.length === 0){
    ElMessage.warning('请选择数据')
    return
  }
  ElMessageBox.confirm('删除数据后无法恢复，您确定要删除吗？','删除确认',{type:'warning'}).then(() =>{
    request.delete('/advertisementList/deleteBatch', { data: data.selectedRows }).then(res =>{
      if(res.code === '200'){
        ElMessage.success('操作成功')
        load() //删除后重新加载最新的数据
      }else{
        ElMessage.error(res.msg)
      }
    })
  }).catch()
}

// 表格多选
const handleSelectionChange = (rows) => {
  data.selectedRows = rows.map(row => row.id)
}

// 图片上传成功回调
const handleUploadSuccess = (res) => {
  console.log(res.data.image)
  data.adForm.image = res.data
}

// 提交新增表单
const handleSubmit = () => {
  console.log(data.adForm)
  // TODO: 实现表单提交逻辑
  request.post('/advertisementList/add', data.adForm).then(res =>{
    if(res.code === '200'){
      data.dialogVisible=false
      ElMessage.success('操作成功')
      load() //新增后重新加载最新的数据
    }else{
      ElMessage.error(res.msg)
    }
  })
  data.dialogVisible= false
}

//提交编辑表单
const handleUpdate = () => {
  console.log(data.adForm)
  request.put('/advertisementList/update', data.adForm).then(res =>{
    if (res.code === '200'){
      data.dialogVisible = false
      ElMessage.success('编辑成功')
      load()
    }else {
      ElMessage.error(res.msg)
    }
  })
}

const UploadToWeb = () => {
  if (data.webName.length === 0) {
    ElMessage.warning("请选择至少一个投放网站");
    return;
  }

  data.adForm.status = "已提交平台";
  data.adForm.advertisementId = data.adForm.id;

  const uploadPromises = data.webName.map((site) => {
    if (site === "购物中心") {
      return request.post("/shopping/add", data.adForm);
    } else if (site === "新闻中心") {
      return request.post("/news/add", data.adForm);
    } else {
      return Promise.reject(`未知的网站：${site}`);
    }
  });

  Promise.all(uploadPromises)
      .then(() => {
        ElMessage.success("所有选定网站已成功投放");
        data.uploadVisible = false;
        request.put("/advertisementList/update", data.adForm).then(() => {
          load(); // 刷新表格数据
        });
      })
      .catch((error) => {
        console.error("投放失败:", error);
        ElMessage.error("部分网站投放失败，请检查日志");
      });
};

// 分页相关数据
const pagination = reactive({
  size: 'default',
  currentPage: 1,
  pageSize: 10,
  total: 0,
  background: false,
  disabled: false,
})

// 处理页码改变
const handleCurrentChange = (page) => {
  pagination.currentPage = page
  load()
}

// 处理每页条数改变
const handleSizeChange = (size) => {
  pagination.pageSize = size
  pagination.currentPage = 1
  load()
}

// 修改搜索方法
const load = () => {
  console.log(data.adForm.title)
  request.get('/advertisementList/selectPageById',{
    params: {
      userId: JSON.parse(localStorage.getItem('user')).id,
      pageNum:pagination.currentPage,
      pageSize:pagination.pageSize,
      title:data.searchForm.title,
      category: data.searchForm.category
    }
  }).then(res =>{
    data.tableData =res.data.list
    pagination.total = res.data.total
    console.log(pagination.total)
  })
}

const categoriesLoad = () => {
  request.get("/category/selectAll").then(res=>(
      data.categories=res.data
  ))
}

const webNamesLoad = () => {
  request.get("/user/selectWebName").then(res=>(
      data.webNames=res.data
  ))
}

onMounted(() => {
  load()
  categoriesLoad()
  webNamesLoad()
})
</script>

<style scoped>
.search-area {
  margin-bottom: 20px;
  padding: 20px;
  background-color: #fff;
  border-radius: 4px;
}

.operation-area {
  margin-bottom: 20px;
}

.avatar-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 178px;
  height: 178px;
}

.avatar-uploader:hover {
  border-color: #409EFF;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  text-align: center;
  line-height: 178px;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.image-preview .el-image-preview__wrapper {
  z-index: 9999;
  position: fixed;  /* 确保它在顶部 */
}

</style>