<script setup>
import { ref, onMounted, reactive } from 'vue';
import Cookies from 'js-cookie';
import { v4 as uuidv4 } from 'uuid';
import request from "@/utils/request"; // 假设你有自定义的请求工具

const categoryClick = ref(Cookies.get('categoryClick'));
const categoryClickTimestamp = ref(Cookies.get('categoryClickTimestamp'));

const data = reactive({
  web_user: '',
  user_rate: {}
});

data.web_user = uuidv4();

const selectUser = () => {
  const web_user = Cookies.get('web_user');
  console.log(web_user);
  request.get(`webUser/selectByUser/${web_user}`).then(res => {
    if (res.code === '500') {
      Cookies.set('web_user', data.web_user, {
        path: '/',
        domain: '.hebiu.cn',  // 可以设置为父页面的域名
        sameSite: 'None',
        secure: true
      });

      request.get(`webUser/add/${data.web_user}`).then(res => {});
    }
  });
};

selectUser();

Cookies.set('categoryClick', '', {
  path: '/',
  domain: '.hebiu.cn',
  sameSite: 'None',
  secure: true
});

Cookies.set('categoryClickTimestamp', Date.now(), {
  path: '/',
  domain: '.hebiu.cn',
  sameSite: 'None',
  secure: true
});

onMounted(() => {
  // 每100毫秒检查一次cookie的变化
  setInterval(() => {
    const newCategoryClick = Cookies.get('categoryClick');
    const newCategoryClickTimestamp = Cookies.get('categoryClickTimestamp');
    if ((newCategoryClick !== categoryClick.value || newCategoryClickTimestamp !== categoryClickTimestamp.value) &&
        newCategoryClick !== null && newCategoryClick !== undefined && newCategoryClick !== "") {

      categoryClick.value = newCategoryClick;
      categoryClickTimestamp.value = newCategoryClickTimestamp; // 使用 .value 来更新

      data.user_rate.user = Cookies.get('web_user');
      data.user_rate.category = categoryClick.value;

      // 发送请求
      request.post("userRate/add", data.user_rate).then(res => {
        // 处理返回结果
      });
    }

  }, 100);
});
console.log(categoryClick)
console.log(categoryClickTimestamp)
console.log(Cookies.get('web_user'))
</script>