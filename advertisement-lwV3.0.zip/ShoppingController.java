package com.example.controller;

import com.example.common.Result;
import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import com.example.service.AdvertisementService;
import com.example.service.ShoppingService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shopping")
public class ShoppingController {

    @Resource
    private ShoppingService shoppingService;


    @PostMapping("/add")
    public Result save(@RequestBody Shopping shopping) {
        try {
            shoppingService.add(shopping);
            return Result.success();
        } catch (Exception e) {
            return Result.error("500", "保存失败: " + e.getMessage());
        }
    }

    @GetMapping("/selectAll/{user}")
    public Result select(@PathVariable String user) {
        return Result.success(shoppingService.getAdvertisements(user));
    }

    @PutMapping("/updateClick/{advertisementId}")
    public Result updateClickByAdvertisementId(@PathVariable Integer advertisementId) {
        shoppingService.updateClickByAdvertisementId(advertisementId);
        return Result.success();
    }

    @GetMapping("/selectByAdvertisementId/{advertisementId}")
    public Result selectByAdvertisementId(@PathVariable Integer advertisementId) {
        return Result.success(shoppingService.selectMoneyByAdvertisementId(advertisementId));
    }

    @GetMapping("/selectByUserId/{userId}")
    public Result selectByUserId(@PathVariable Integer userId) {
        return Result.success(shoppingService.selectMoneyByUserId(userId));
    }
}