package com.example.controller;
import com.example.entity.UserRate;
import com.example.common.Result;
import com.example.service.UserRateService;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
@RestController
@RequestMapping("/userRate")
public class UserRateController {
    @Resource
    UserRateService userRateService;

    @PostMapping("/add")
    public Result add(@RequestBody UserRate userRate) {
        userRateService.add(userRate);
        return Result.success();
    }

}
