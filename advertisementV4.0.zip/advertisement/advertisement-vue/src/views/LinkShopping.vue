<template>
  <div style="display: flex;align-content: center;justify-content: center;width: 300px;height: 300px">
    <img :src="data.image" alt="" @click="goToLinkDetails"/>
  </div>
</template>

<script setup>
import {onMounted, reactive} from "vue";
import request from '@/utils/request.js'
import {useRoute} from "vue-router";
const data = (reactive({
  image:'',
  user:'',
}))
const route = useRoute();
const adId = route.params.id;

const load = () => {
  request.get(`/advertisementList/selectUrlById/${adId}`).then(res =>{
    data.image = res.data.image;
  })
}

const goToLinkDetails = () => {
  window.open(`/LinkDetails/${adId}`, '_blank')
  request.put(`shopping/updateClick/${adId}`).then(res =>{

  })
}

onMounted( () => {
  load()
})
</script>

<style scoped>

</style>