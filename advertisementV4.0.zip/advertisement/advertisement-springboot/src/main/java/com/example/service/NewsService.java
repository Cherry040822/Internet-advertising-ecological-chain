package com.example.service;

import com.example.entity.Advertisement;
import com.example.entity.News;
import com.example.mapper.NewsMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class NewsService {

    @Resource
    NewsMapper newsMapper;

    public void add(News news) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        news.setCreateTime(sdf.format(new Date()));
        news.setStatus("已提交平台");
        news.setUrl("http://localhost:8100/LinkNews/"+news.getAdvertisementId());
        newsMapper.insert(news);
    }

    public boolean selectByAdvertisementId(Integer advertisementId) {
        System.out.println("新闻："+newsMapper.selectByAdvertisementId(advertisementId));
        if(newsMapper.selectByAdvertisementId(advertisementId)){
            return true;
        }else {
            return false;
        }
    }

    public PageInfo<News> selectPage(News news,Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<News> list=newsMapper.selectAll(news);
        return PageInfo.of(list);
    }

    public void updateClickByAdvertisementId(Integer advertisementId) {
        newsMapper.updateClickByAdvertisementId(advertisementId);
    }

    public News selectMoneyByAdvertisementId(Integer advertisementId) {
        return newsMapper.selectMoneyByAdvertisementId(advertisementId);
    }

    public void updateStatus() {
        newsMapper.updateStatus();
    }
    public boolean selectByUserId(Integer userId) {
        if(newsMapper.selectByUserId(userId)){
            return true;
        }else {
            return false;
        }
    }
    public News selectMoneyByUserId(Integer userId) {
        return newsMapper.selectMoneyByUserId(userId);
    }

    public Integer selectAllClick() {
        return newsMapper.selectAllClick();
    }
}
