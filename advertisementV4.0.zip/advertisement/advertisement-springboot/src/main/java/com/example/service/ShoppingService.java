package com.example.service;

import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import com.example.mapper.AdvertisementMapper;
import com.example.mapper.ShoppingMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class ShoppingService {

    @Resource
    ShoppingMapper shoppingMapper;

    public void add(Shopping shopping) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        shopping.setCreateTime(sdf.format(new Date()));
        shopping.setStatus("已提交平台");
        shopping.setUrl("http://localhost:8100/LinkShopping/"+shopping.getAdvertisementId());
        shoppingMapper.insert(shopping);
    }

    public boolean selectByAdvertisementId(Integer advertisementId) {
        System.out.println(shoppingMapper.selectByAdvertisementId(advertisementId));
        if(shoppingMapper.selectByAdvertisementId(advertisementId)){
            return true;
        }else {
            return false;
        }
    }

    public PageInfo<Shopping> selectPage( Shopping shopping,
                                          Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<Shopping> list=shoppingMapper.selectAll(shopping);
        return PageInfo.of(list);
    }

    public void updateClickByAdvertisementId(Integer advertisementId) {
        shoppingMapper.updateClickByAdvertisementId(advertisementId);
    }

    public Shopping selectMoneyByAdvertisementId(Integer advertisementId) {
        return shoppingMapper.selectMoneyByAdvertisementId(advertisementId);
    }

    public void updateStatus() {
        shoppingMapper.updateStatus();
    }

    public boolean selectByuserId(Integer userId) {
        if(shoppingMapper.selectByUserId(userId)){
            return true;
        }else {
            return false;
        }
    }

    public Shopping selectMoneyByUserId(Integer userId) {
        return shoppingMapper.selectMoneyByUserId(userId);
    }

    public Integer selectAllClick() {
        return shoppingMapper.selectAllClick();
    }
}
