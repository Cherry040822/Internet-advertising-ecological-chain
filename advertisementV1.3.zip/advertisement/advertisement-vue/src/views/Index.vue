<template>
  <div>
    <div style="height: 60px;display: flex; align-items: center; border-bottom: 1px solid #ddd; background-color: #1d66a8 ">
      <div style="flex: 1;">
        <div style="padding-left: 20px; display: flex; align-items: center;">
          <img src="@/assets/header.png" alt="" style="width: 40px">
          <div style="font-weight: bold; font-size: 30px; margin-left: 5px; color: rgba(255,255,255,0.87);">广告投放与管理系统</div>
        </div>
      </div>
      <div style="width: fit-content; padding-right: 10px; display: flex; align-items: center;" >
        <span>
            <img :src="'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'" alt="" style="width: 40px; height: 40px; border-radius: 50%">
          </span>
        <span style="color: rgba(255,255,255,0.87);margin-left: 5px">{{data.user.name}}</span>
      </div>
    </div>

    <div style="display: flex">
      <div style="width: 200px; border-right: 1px solid #ddd;min-height: calc(100vh - 60px);background-color: #acc2dc;">
        <el-menu
            router
            style="border: none;"
            :default-active="$route.path"
            :default-openeds="['/home', '2']"

        >
          <el-menu-item index="/AdvertisementList"  v-if="data.user.role === 'USER'">
            <el-icon><ZoomIn /></el-icon>
            <span>广告投放</span>
          </el-menu-item>
          <el-menu-item index="/UserData"  v-if="data.user.role === 'USER'">
            <el-icon><DataAnalysis /></el-icon>
            <span>整体数据</span>
          </el-menu-item>
          <el-menu-item index="/AdvertisementManage" v-if="data.user.role === 'ADMIN'">
            <el-icon><ZoomIn /></el-icon>
            <span>广告信息</span>
          </el-menu-item>
          <el-menu-item index="/UserManage" v-if="data.user.role === 'ADMIN'">
            <el-icon><DataAnalysis /></el-icon>
            <span>用户信息</span>
          </el-menu-item>
          <el-menu-item index="/AdvertisingManage" v-if="data.user.role === 'ADMIN'">
            <el-icon><Bowl /></el-icon>
            <span>投放管理</span>
          </el-menu-item>
          <el-menu-item index="/admIncome" v-if="data.user.role === 'ADMIN'">
            <el-icon><DataAnalysis /></el-icon>
            <span>整体数据</span>
          </el-menu-item>
          <el-menu-item index="/AdvertisementLook" v-if="data.user.role === 'WEBMASTER'">
            <el-icon><ZoomIn /></el-icon>
            <span>广告信息</span>
          </el-menu-item>
          <el-menu-item index="/webIncome" v-if="data.user.role === 'WEBMASTER'">
            <el-icon><DataAnalysis /></el-icon>
            <span>整体数据</span>
          </el-menu-item>
          <el-menu-item index="/person">
            <el-icon><User /></el-icon>
            <span>个人资料</span>
          </el-menu-item>
          <el-menu-item index="login" @click="logout">
            <el-icon><SwitchButton /></el-icon>
            <span>退出系统</span>
          </el-menu-item>
        </el-menu>
      </div>

      <div style="flex: 1; height: 0; background-color: rgba(241,240,240,0.69)">
        <router-view @updateUser="updateUser" />
      </div>
    </div>

  </div>
</template>

<script setup>
import {onMounted, reactive} from "vue";
import {useRoute } from 'vue-router'
import {DataAnalysis, Dish, EditPen, List, SwitchButton, User, UserFilled, ZoomIn} from "@element-plus/icons-vue";
import router from "@/router/index.js";
import Cookies from "js-cookie"
import {ElMessage} from "element-plus";
import request from "@/utils/request.js";
const $route = useRoute()

const data = reactive({
  user: JSON.parse(localStorage.getItem('user') || '{}'),
  userMoney:0,
  webMoney: 0,
  admMoney:0,
  time: '',
  day: null,
  money: null,
  moneyTime: '',
})

const logout = () => {
  localStorage.removeItem('canteen-user')
  router.push('/')
}

const updateUser = () => {
  data.user = JSON.parse(localStorage.getItem("user"))
}
Cookies.set('adb',123),{
  path:'/',
  domain:'',
  sameSite:'Lax'
}

// 从后台加载数据
const load = () => {
  request.get("/config/selectAll").then(res => {
    console.log('接口返回的数据:', res); // 打印返回数据
    if (res && res.data) {
      data.userMoney = res.data.userMoney,
          data.webMoney = res.data.webMoney,
          data.admMoney = res.data.admMoney,
          data.time = res.data.time,
          data.day = res.data.day,
          data.money = res.data.money,
          data.moneyTime = res.data.moneyTime
      console.log('数据加载完成，启动定时任务');
      startScheduledUpdate();
      startUpdate();
    } else {
      console.error("返回的数据格式不正确");
    }
  }).catch(err => {
    console.error("请求失败", err);
  });
};

// 获取下次应该触发的时间
const getNextScheduledTime = (time, days) => {
  if (!time || days === undefined) return null;
console.log("nh")
  const currentDate = new Date();
  const targetTime = time.split(":");

  // 解析时间
  const targetHours = parseInt(targetTime[0]);
  const targetMinutes = parseInt(targetTime[1]);

  // 创建目标时间的 Date 对象
  const nextScheduledTime = new Date(currentDate);
  nextScheduledTime.setHours(targetHours);
  nextScheduledTime.setMinutes(targetMinutes);
  nextScheduledTime.setSeconds(0);  // 重置秒钟为0

  // 如果目标时间已经过了，且 days > 0，则将日期推到下一天
  if (currentDate > nextScheduledTime) {
    if (days > 0) {
      nextScheduledTime.setDate(currentDate.getDate() + days);  // 将日期加上天数
    } else {
      // 如果是 0 天，设置为第二天的目标时间
      nextScheduledTime.setDate(currentDate.getDate() + 1);  // 推迟到第二天
    }
  }
  console.log('当前时间:', currentDate);
  console.log('目标时间:', nextScheduledTime);

  return nextScheduledTime;
};

const startScheduledUpdate = () => {
  // 计算下次调用的时间
  console.log("abc")
  console.log(data.time, data.day)
  const nextCallTime = getNextScheduledTime(data.time, data.day);

  if (nextCallTime) {
    // 计算下次定时器触发的时间差（毫秒）
    const timeDiff = nextCallTime - new Date();
    console.log('下次触发时间差:', timeDiff);

    if (timeDiff > 0) {
      console.log(`下次任务将在 ${timeDiff} 毫秒后执行`);
      setTimeout(() => {
        console.log('定时任务触发');
        updateStatus();
        startScheduledUpdate();
      }, timeDiff);
    } else {
      console.log('任务时间已经过去，不再执行定时器');
    }
  }
};

const updateStatus = () => {
  // 创建三个请求的 Promise
  const updateAdvertisement = request.put('/advertisement/updateStatus');
  const updateNews = request.put('/news/updateStatus');
  const updateShopping = request.put('/shopping/updateStatus');

  // 使用 Promise.all 发送并等待所有请求完成
  Promise.all([updateAdvertisement, updateNews, updateShopping])
      .then((responses) => {
        // 响应数组，按顺序返回每个请求的响应
        const [advertisementRes, newsRes, shoppingRes] = responses;

        // 检查每个请求的响应
        if (advertisementRes.code === '200' && newsRes.code === '200' && shoppingRes.code === '200') {
          ElMessage.success('所有状态更新成功');
        } else {
          // 如果有任何请求失败，显示错误信息
          ElMessage.error('某些状态更新失败');
        }
      })
      .catch((err) => {
        // 捕获任何请求失败的错误
        console.error('请求失败', err);
        ElMessage.error('请求过程中发生错误');
      });
};
const getNextTime = (time) => {
  if (!time) return null;

  const currentDate = new Date();
  const targetTime = time.split(":");
  const targetHours = parseInt(targetTime[0]);
  const targetMinutes = parseInt(targetTime[1]);

  // 创建目标时间的 Date 对象
  const nextScheduledTime = new Date(currentDate);
  nextScheduledTime.setHours(targetHours);
  nextScheduledTime.setMinutes(targetMinutes);
  nextScheduledTime.setSeconds(0);  // 重置秒钟为0

  if (currentDate > nextScheduledTime) {
    nextScheduledTime.setDate(currentDate.getDate() + 1);  // 如果目标时间已经过了，推迟到第二天
  }
  console.log('当前时间:', currentDate);
  console.log('目标时间:', nextScheduledTime);
  return nextScheduledTime;
};

// 定时器逻辑
const startUpdate = () => {
  const nextCallTime = getNextTime(data.moneyTime);

  if (nextCallTime) {
    const timeDiff = nextCallTime - new Date();
    console.log('下次触发时间差:', timeDiff);
    if (timeDiff > 0) {
      setTimeout(() => {
        console.log(`下次任务将在 ${timeDiff} 毫秒后执行`);
        // 先调用 addRecords，然后执行 sumClick
        updateAddRecords().then(() => {
          updateSumClick();
        }).catch((error) => {
          console.error("addRecords 请求失败:", error);
        });
      }, timeDiff);
    }else {
      console.log('任务时间已经过去，不再执行定时器');
    }
  }
};

// 调用 addRecords 接口
const updateAddRecords = () => {
  return request.post("/statistics/addRecords")
      .then((res) => {
        if (res.code === '200') {
          console.log("成功")
          ElMessage.success('addRecords 执行成功');
        } else {
          console.log("失败")
          ElMessage.error('addRecords 执行失败');
        }
      });
};

// 调用 sumClick 接口
const updateSumClick = () => {
  return request.put("/statistics/sumClick")
      .then((res) => {
        if (res.code === '200') {
          console.log("成功")
          ElMessage.success('sumClick 执行成功');
        } else {
          console.log("失败")
          ElMessage.error('sumClick 执行失败');
        }
      });
};


// 初始化时启动定时任务
onMounted(() => {
  load()
});

</script>

<style scoped>
.el-menu-item.is-active {
  background-color: #e0e4ff !important;
}
.el-menu-item:hover {
  background-color: #e9eeff !important;
  color: #1450aa;
}
.el-sub-menu-item:hover {
  background-color: #e9eeff !important;
  color: #1450aa;
}
:deep(th)  {
  color: #333;
}

:deep(.el-menu) {
  background-color: transparent !important;
  border-right: none !important;
}

:deep(.el-menu-item),
:deep(.el-sub-menu__title) {
  color: #031c38 !important;  /* 浅色文字 */
}

:deep(.el-menu-item:hover),
:deep(.el-sub-menu__title:hover) {
  background-color: #263445 !important;
  color: #fff !important;
}

:deep(.el-menu-item.is-active) {
  background-color: #263445 !important;  /* 选中项的背景色 */
  color: #fff !important;
}

/* 子菜单弹出层样式 */
:deep(.el-menu--popup) {
  background-color: #304156 !important;
}

:deep(.el-menu--popup .el-menu-item) {
  color: #bfcbd9 !important;
}

:deep(.el-menu--popup .el-menu-item:hover) {
  background-color: #263445 !important;
  color: #fff !important;
}
.el-dropdown-link {
  cursor: pointer;
  display: flex;
  align-items: center;
  border:none !important;
}
/* 去掉el-dropdown-menu的边框 */
.el-dropdown-menu {
  border: none !important;
}

/* 去掉el-dropdown-item的边框和背景 */
.el-dropdown-menu .el-dropdown-item:hover {
  background-color: transparent !important;
  border: none !important;
}
</style>