package com.example.service;

import com.example.entity.Statistics;
import com.example.mapper.NewsMapper;
import com.example.mapper.ShoppingMapper;
import com.example.mapper.StatisticsMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StatisticsService {

    @Resource
    private StatisticsMapper statisticsMapper;
    @Resource
    private ShoppingMapper shoppingMapper;
    @Resource
    private NewsMapper newsMapper;

    public List<Statistics> dailySelectAll() {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取7天前的日期
        LocalDate sevenDaysAgo = today.minusDays(7);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.dailySelectAll();

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近七天的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate(), formatter);
                        // 判断记录日期是否在近七天之内
                        return !recordDate.isBefore(sevenDaysAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> monthlySelectAll() {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取12个月前的日期
        LocalDate twelveMonthsAgo = today.minusMonths(12);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.monthlySelectAll();

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近12个月的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01", formatter);
                        // 判断记录日期是否在近12个月之内
                        return !recordDate.isBefore(twelveMonthsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }


    public List<Statistics> annualSelectAll() {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取10年前的日期
        LocalDate tenYearsAgo = today.minusYears(10);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.annualSelectAll();

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近10年的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01" + "-01", formatter);
                        // 判断记录日期是否在近10年之内
                        return !recordDate.isBefore(tenYearsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }
    public void sumClick() {
        shoppingMapper.sumClick();
        newsMapper.sumClick();
    }

    public void addRecords() {

        // 查询要插入的数据
        List<Map<String, Object>> results1 = shoppingMapper.selectAdvertisementData();
        List<Map<String, Object>> results2 = newsMapper.selectAdvertisementData();

        Set<Map<String, Object>> advertisementSet = new HashSet<>();
        // 获取今天的日期并格式化为字符串
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(new Date());

        // 遍历结果并插入到 daily 表
        for (Map<String, Object> result : results1) {
            Integer userId = (Integer) result.get("user_id");
            Integer advertisementId = (Integer) result.get("advertisement_id");

            // 创建一个 Map 存储广告记录
            Map<String, Object> advertisementRecord = new HashMap<>();
            advertisementRecord.put("user_id", userId);
            advertisementRecord.put("advertisement_id", advertisementId);

            // 将广告记录添加到 Set 中，Set 会自动去重
            advertisementSet.add(advertisementRecord);


        }

        for (Map<String, Object> result : results2) {
            Integer userId = (Integer) result.get("user_id");
            Integer advertisementId = (Integer) result.get("advertisement_id");

            // 创建一个 Map 存储广告记录
            Map<String, Object> advertisementRecord = new HashMap<>();
            advertisementRecord.put("user_id", userId);
            advertisementRecord.put("advertisement_id", advertisementId);

            // 将广告记录添加到 Set 中，Set 会自动去重
            advertisementSet.add(advertisementRecord);
        }

        // 遍历集合，判断是否需要插入 daily 表
        for (Map<String, Object> record : advertisementSet) {
            Integer userId = (Integer) record.get("user_id");
            Integer advertisementId = (Integer) record.get("advertisement_id");

            // 调用 Mapper 插入数据
            statisticsMapper.insertDailyData(userId, advertisementId, date);

        }

        // 1. 按广告 ID 查询 shopping 表点击数
        List<Map<String, Object>> shoppingClicks = shoppingMapper.groupByAdvertisementClicks();

        // 2. 按广告 ID 查询 news 表点击数
        List<Map<String, Object>> newsClicks = newsMapper.groupByAdvertisementClicks();

        // 3. 将点击数合并到 daily 表
        for (Map<String, Object> record : advertisementSet) {
            Integer advertisementId = (Integer) record.get("advertisement_id");

            // 查询 shoppingClick
            Integer shoppingClick = shoppingClicks.stream()
                    .filter(click -> advertisementId.equals(click.get("advertisement_id")))
                    .map(click -> ((Number) click.get("click")).intValue())
                    .findFirst()
                    .orElse(0);

            // 查询 newsClick
            Integer newsClick = newsClicks.stream()
                    .filter(click -> advertisementId.equals(click.get("advertisement_id")))
                    .map(click -> ((Number) click.get("click")).intValue())
                    .findFirst()
                    .orElse(0);

            // 更新 daily 表的点击数
            statisticsMapper.updateDailyClicks(advertisementId, shoppingClick, newsClick, date);
        }


        // 查询当月 daily 表的数据并按广告 ID 分组计算总和
        List<Map<String, Object>> groupedMonthlyClicks = statisticsMapper.groupByAdvertisementForMonth(date);

        // 遍历结果并插入到 monthly 表
        for (Map<String, Object> record : groupedMonthlyClicks) {
            Integer userId = (Integer) record.get("user_id");
            Integer advertisementId = (Integer) record.get("advertisement_id");
            Integer shoppingClickSum = ((Number) record.get("shopping_click_sum")).intValue(); // 确保类型正确
            Integer newsClickSum = ((Number) record.get("news_click_sum")).intValue(); // 确保类型正确
            String currentMonth = (String)record.get("month");

            // 检查是否存在相同广告ID和日期的记录
            Integer count = statisticsMapper.countMonthlyRecord(advertisementId, currentMonth);
            if (count > 0) {
                // 如果记录存在，执行更新操作
                statisticsMapper.updateMonthlyData(currentMonth, userId, advertisementId, shoppingClickSum, newsClickSum);
            } else {
                // 如果记录不存在，执行插入操作
                statisticsMapper.insertMonthlyData(currentMonth, userId, advertisementId, shoppingClickSum, newsClickSum);
            }

        }


        // 查询当年 monthly 表的数据并按广告 ID 分组计算总和
        List<Map<String, Object>> groupedAnnualClicks = statisticsMapper.groupByAdvertisementForYear(date);

        // 遍历结果并插入到 annual 表
        for (Map<String, Object> record : groupedAnnualClicks) {
            Integer userId = (Integer) record.get("user_id");
            Integer advertisementId = (Integer) record.get("advertisement_id");
            Integer shoppingClickSum = ((Number) record.get("shopping_click_sum")).intValue(); // 确保类型正确
            Integer newsClickSum = ((Number) record.get("news_click_sum")).intValue(); // 确保类型正确
            String currentYear = (String)record.get("annual");
            System.out.println("年份"+currentYear);

            Integer count = statisticsMapper.countAnnualRecord(advertisementId, currentYear);
            if (count > 0) {
                // 如果记录存在，执行更新操作
                statisticsMapper.updateAnnualData(currentYear, userId, advertisementId, shoppingClickSum, newsClickSum);
            } else {
                // 如果记录不存在，执行插入操作
                statisticsMapper.insertAnnualData(currentYear, userId, advertisementId, shoppingClickSum, newsClickSum);
            }
        }
    }

    public List<Statistics> dailySelectByAdvertisementId(Integer advertisementId) {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取7天前的日期
        LocalDate sevenDaysAgo = today.minusDays(7);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.dailySelectByAdvertisementId(advertisementId);

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近七天的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate(), formatter);
                        // 判断记录日期是否在近七天之内
                        return !recordDate.isBefore(sevenDaysAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> monthlySelectByAdvertisementId(Integer advertisementId) {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取12个月前的日期
        LocalDate twelveMonthsAgo = today.minusMonths(12);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.monthlySelectByAdvertisementId(advertisementId);

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近12个月的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01", formatter);
                        // 判断记录日期是否在近12个月之内
                        return !recordDate.isBefore(twelveMonthsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> annualSelectByAdvertisementId(Integer advertisementId) {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取10年前的日期
        LocalDate tenYearsAgo = today.minusYears(10);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.annualSelectByAdvertisementId(advertisementId);

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近10年的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01" + "-01", formatter);
                        // 判断记录日期是否在近10年之内
                        return !recordDate.isBefore(tenYearsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> dailySelectByUserId(Integer userId) {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取7天前的日期
        LocalDate sevenDaysAgo = today.minusDays(7);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.dailySelectByUserId(userId);

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近七天的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate(), formatter);
                        // 判断记录日期是否在近七天之内
                        return !recordDate.isBefore(sevenDaysAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> monthlySelectByUserId(Integer userId) {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取12个月前的日期
        LocalDate twelveMonthsAgo = today.minusMonths(12);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.monthlySelectByUserId(userId);

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近12个月的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01", formatter);
                        // 判断记录日期是否在近12个月之内
                        return !recordDate.isBefore(twelveMonthsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> annualSelectByUserId(Integer userId) {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取10年前的日期
        LocalDate tenYearsAgo = today.minusYears(10);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.annualSelectByUserId(userId);

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近10年的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01" + "-01", formatter);
                        // 判断记录日期是否在近10年之内
                        return !recordDate.isBefore(tenYearsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }
}
