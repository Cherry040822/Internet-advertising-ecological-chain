package com.example.mapper;

import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import org.apache.ibatis.annotations.Delete;

import java.util.List;
import java.util.Map;

public interface ShoppingMapper {
    void insert(Shopping shopping);

    boolean selectByAdvertisementId(Integer advertisementId);

    List <Shopping> selectUrlByAdvertisementId();

    void updateClickByAdvertisementId(Integer advertisementId);

    Shopping selectMoneyByAdvertisementId(Integer advertisementId);

    @Delete("delete from  `advertisement_shopping` where advertisement_id = #{id}")
    void deleteByAdvertisementId(Integer id);

    void update(Advertisement advertisement);

    void updateStatus();

    boolean selectByUserId(Integer userId);

    Shopping selectMoneyByUserId(Integer userId);

    void sumClick();

    List<Map<String, Object>> selectAdvertisementData();

    List<Map<String, Object>> groupByAdvertisementClicks();
}
