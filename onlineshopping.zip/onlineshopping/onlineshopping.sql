/*
 Navicat Premium Data Transfer

 Source Server         : mydatabase
 Source Server Type    : MySQL
 Source Server Version : 80300 (8.3.0)
 Source Host           : localhost:3306
 Source Schema         : onlineshopping

 Target Server Type    : MySQL
 Target Server Version : 80300 (8.3.0)
 File Encoding         : 65001

 Date: 24/12/2024 00:19:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` int NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `image_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 120 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO `cart` VALUES (117, 3, 1, 88, '百褶裙', 'http://localhost:8080/files/download/图片3.png');
INSERT INTO `cart` VALUES (118, 2, 1, 120, '女士阔腿牛仔裤', 'http://localhost:8080/files/download/图片2.png');
INSERT INTO `cart` VALUES (119, 1, 1, 100, '女士衬衣', 'http://localhost:8080/files/download/图片1.png');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `price` int NOT NULL,
  `image_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ship_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `sales` int NULL DEFAULT NULL,
  `delivery` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`product_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, '女士衬衣', '精选柔软面料，透气舒适，简洁的设计和修身剪裁，展现女性优雅气质。适合各种场合，无论是日常穿搭还是商务穿着，都能让你尽显风采。', 100, 'http://localhost:8080/files/download/图片1.png', '女装', '广州', 1999, '免运费');
INSERT INTO `product` VALUES (2, '女士阔腿牛仔裤', '宽松设计，搭配舒适的弹性牛仔布，穿着自由自在，完美展现休闲与优雅。阔腿裤型不仅修饰腿部线条，还能为整体造型增添时尚感。', 120, 'http://localhost:8080/files/download/图片2.png', '女装', '广州', 888, '免运费');
INSERT INTO `product` VALUES (3, '百褶裙', '经典百褶设计，轻盈飘逸，增添了几分俏皮和女性的柔美。适合搭配T恤或衬衫，穿上它让你在人群中独具一格。', 88, 'http://localhost:8080/files/download/图片3.png', '女装', '广州', 999, '免运费');
INSERT INTO `product` VALUES (4, '冰箱', '高效节能，智能温控设计，满足家庭日常保鲜需求。大容量储存空间，轻松容纳各种食品，让您的厨房更加整洁有序。', 1000, 'http://localhost:8080/files/download/图片4.png', '家电', '上海', 166, '免运费');
INSERT INTO `product` VALUES (5, '洗碗机', '高效清洁功能，采用先进的水流喷射技术，轻松去除油渍与残留食物，节水环保，省时省力，让您告别洗碗烦恼。', 2000, 'http://localhost:8080/files/download/图片5.png', '家电', '上海', 199, '免运费');
INSERT INTO `product` VALUES (6, '洗衣机', '强力洗涤与温和护理并重，多种洗涤模式，能够满足不同衣物的清洗需求。节能高效，呵护衣物，保持色彩与质感如新。', 1499, 'http://localhost:8080/files/download/图片6.png', '家电', '苏州', 288, '免运费');
INSERT INTO `product` VALUES (7, '黑色沙发', '现代简约设计，优质布艺面料，深沉的黑色彰显低调奢华，适合各种家居风格。坐垫舒适，支撑力强，让您尽享休闲时光。', 2999, 'http://localhost:8080/files/download/图片7.png', '家居', '苏州', 366, '免运费');
INSERT INTO `product` VALUES (8, '原木桌', '纯天然原木材质，独特的木纹设计，带来自然与温暖感。简约而不简单，适合餐厅、书房或办公空间，增添自然的韵味。', 799, 'http://localhost:8080/files/download/图片8.png', '家居', '苏州', 899, '免运费');
INSERT INTO `product` VALUES (9, '躺椅', '舒适的躺椅设计，柔软的坐垫和靠背支撑，完美放松身体的每一寸肌肉。无论是午休还是下午茶时光，都是您理想的休闲选择。', 299, 'http://localhost:8080/files/download/图片9.png', '家居', '苏州', 799, '免运费');
INSERT INTO `product` VALUES (10, '男士黑色T恤', '基础款男士黑色T恤，柔软面料，简洁大方，适合各种场合。经典的黑色能够轻松搭配多种服饰，是衣橱必备单品。', 99, 'http://localhost:8080/files/download/图片10.png', '男装', '广州', 1099, '免运费');
INSERT INTO `product` VALUES (11, '男士风衣', '时尚与实用兼具的男士风衣，采用高品质面料，防风保暖，剪裁合身，简约而不失格调，是秋冬季节必不可少的外套。', 199, 'http://localhost:8080/files/download/图片11.png', '男装', '金华', 388, '免运费');
INSERT INTO `product` VALUES (12, '女装皮草外套', '高档皮草外套，手感柔软，穿着温暖而舒适，完美提升冬季穿搭的奢华感。精致的做工与高端的材质，尽显女性优雅风度。', 379, 'http://localhost:8080/files/download/图片12.png', '女装', '金华', 488, '免运费');
INSERT INTO `product` VALUES (13, '电动牙刷', '采用先进震动技术，有效去除牙垢，改善口腔健康。多档力度调节，贴心设计，带来更舒适的清洁体验，给您强效的清洁力与口腔护理。', 369, 'http://localhost:8080/files/download/图片13.png', '家居', '杭州', 999, '免运费');
INSERT INTO `product` VALUES (14, '手机苹果 iPhone 16 Pro', '配备最新的处理器与创新功能，带来超快的性能和流畅的操作体验。配备卓越的摄像头系统，捕捉每一刻精彩，展现科技魅力。', 8289, 'http://localhost:8080/files/download/图片14.png', '电子产品', '杭州', 599, '免运费');
INSERT INTO `product` VALUES (15, '电脑', '强大的性能配置，流畅的操作体验，完美适应工作与娱乐的多种需求。无论是办公处理还是游戏娱乐，都能提供卓越表现。', 6399, 'http://localhost:8080/files/download/图片15.png', '电子产品', '杭州', 788, '免运费');
INSERT INTO `product` VALUES (16, '蓝牙耳机', '采用先进的蓝牙技术，连接稳定，音质清晰，无论是通话还是听音乐，都能提供清脆的声音。设计简约，佩戴舒适，适合日常使用。', 299, 'http://localhost:8080/files/download/图片16.png', '电子产品', '嘉兴', 566, '免运费');
INSERT INTO `product` VALUES (17, '蓝牙音箱', '强劲的音质输出，清晰的高低音效果，适合各种场合。无线蓝牙连接，便捷操作，音响设计时尚，成为室内外聚会的完美伴侣。', 399, 'http://localhost:8080/files/download/图片17.png', '电子产品', '义乌', 466, '免运费');
INSERT INTO `product` VALUES (18, '手表', '精致设计的时尚手表，搭配经典或现代风格，增添气质与个性。无论是日常佩戴还是特殊场合，都是您的点睛之笔。', 899, 'http://localhost:8080/files/download/图片18.png', '电子产品', '杭州', 899, '免运费');
INSERT INTO `product` VALUES (19, '无线收音机', '便捷的无线设计，支持多频段接收，音质清晰稳定。无论是在家里还是旅行中，都能轻松听到您喜欢的电台和节目。', 59, 'http://localhost:8080/files/download/图片19.png', '电子产品', '杭州', 499, '免运费');
INSERT INTO `product` VALUES (20, '智能手环', '多功能智能手环，能够实时监测心率、步数、睡眠等数据。结合运动、健康与智能提醒功能，帮助您随时了解身体状况。', 289, 'http://localhost:8080/files/download/图片20.png', '电子产品', '宁波', 399, '免运费');
INSERT INTO `product` VALUES (21, '无线机械键盘', '高响应的无线机械键盘，具有极佳的打字体验和舒适感。适合长时间使用，精确的按键反馈，适用于工作、学习与游戏。', 589, 'http://localhost:8080/files/download/图片21.png', '电子产品', '广州', 599, '免运费');
INSERT INTO `product` VALUES (22, '落地灯', '简约时尚的落地灯，适合各类家庭风格。灯光柔和，能够为居室带来温馨氛围，且具有调节功能，满足不同光线需求。', 99, 'http://localhost:8080/files/download/图片22.png', '家居生活', '广州', 499, '免运费');
INSERT INTO `product` VALUES (23, '白色地毯', '优质面料的白色地毯，手感柔软，增添居室的温暖与舒适感。简洁的白色设计，易于搭配，适合多种风格的家居装饰。', 169, 'http://localhost:8080/files/download/图片23.png', '家居生活', '广州', 899, '免运费');
INSERT INTO `product` VALUES (24, '熊猫马克杯', '可爱的熊猫图案设计，卡通风格，增添生活中的乐趣。大容量设计，适合饮用咖啡、茶水或牛奶，是送礼的理想选择。', 56, 'http://localhost:8080/files/download/图片24.png', '家居生活', '义乌', 566, '免运费');
INSERT INTO `product` VALUES (25, '纯色衣架', '简约纯色衣架，稳固耐用，能够有效保护衣物形状。适合衣柜内整理不同类型的衣物，帮助您保持整洁。', 28, 'http://localhost:8080/files/download/图片25.png', '家居生活', '义务', 878, '免运费');
INSERT INTO `product` VALUES (26, '加厚垃圾桶', '高质量加厚设计，坚固耐用，防水防漏，能够承载更多垃圾。适合家庭、办公室等多个场景使用，保持空间清洁与整齐。', 19, 'http://localhost:8080/files/download/图片26.png', '家居生活', '金华', 1002, '免运费');
INSERT INTO `product` VALUES (27, '拖把', '设计人性化的拖把，清洁效率高，轻松清除地面污渍。适合不同类型的地板，配合水桶使用，轻松完成清洁工作。', 59, 'http://localhost:8080/files/download/图片27.png', '家居生活', '金华', 1009, '免运费');
INSERT INTO `product` VALUES (28, '扫把', '高效清洁工具，扫把刷毛密集，能够轻松清扫地面上的灰尘与垃圾。适合家庭和办公室使用，简便易操作。', 25, 'http://localhost:8080/files/download/图片28.png', '家居生活', '广州', 609, '免运费');
INSERT INTO `product` VALUES (29, '餐具', '精美餐具套装，适合各种餐饮场合。精致的设计与优质材料，增加用餐的享受，是家庭聚餐或送礼的理想选择。', 88, 'http://localhost:8080/files/download/图片29.png', '家居生活', '广州', 546, '免运费');
INSERT INTO `product` VALUES (30, '餐桌钟', '时尚而实用的餐桌钟，经典的设计能够完美融入家居环境。精准的时刻显示，方便查看时间，提升餐桌氛围。', 133, 'http://localhost:8080/files/download/图片30.png', '家居生活', '苏州', 523, '免运费');
INSERT INTO `product` VALUES (31, '烘干机', '高效的衣物烘干机，能够迅速去除湿气，保证衣物干燥柔软。节能环保设计，适合各种面料的衣物，保持衣物清新。', 1099, 'http://localhost:8080/files/download/图片31.png', '家电', '杭州', 489, '免运费');
INSERT INTO `product` VALUES (32, '洗衣液', '温和且高效的洗衣液，去污能力强，同时保护衣物纤维不受损害。适合不同类型的衣物，带来清新的香气。', 59, 'http://localhost:8080/files/download/图片32.png', '家居生活', '嘉兴', 789, '免运费');
INSERT INTO `product` VALUES (33, '家用消毒液', '高效杀菌消毒，能够有效去除家庭常见的细菌和病毒。适用于厨房、卫生间、家具等区域，保障家人健康。', 89, 'http://localhost:8080/files/download/图片33.png', '家居生活', '嘉兴', 486, '免运费');
INSERT INTO `product` VALUES (34, '沐浴露', '温和滋润的沐浴露，丰富泡沫，清洁肌肤同时保持肌肤的水润。清新的香气让沐浴时光更加愉悦。', 38, 'http://localhost:8080/files/download/图片34.png', '家居生活', '上海', 856, '免运费');
INSERT INTO `product` VALUES (35, '洗发水', '滋养发丝的洗发水，深层清洁的同时，保持头发柔顺光泽。适合各种发质，长时间使用能够改善发质。', 89, 'http://localhost:8080/files/download/图片35.png', '家居生活', '上海', 876, '免运费');
INSERT INTO `product` VALUES (36, '发膜', '深层滋养发丝的发膜，修复干枯毛躁，令头发柔软有光泽。适合受损发质，提供全面护理，恢复头发的自然美。', 88, 'http://localhost:8080/files/download/图片36.png', '家居生活', '上海', 798, '免运费');
INSERT INTO `product` VALUES (37, '牙膏', '高效清洁牙齿，防止牙龈出血和口臭，保护牙齿健康。含有氟化物成分，有效去除牙渍，保持口腔清新。', 29, 'http://localhost:8080/files/download/图片37.png', '家居生活', '宁波', 888, '免运费');

SET FOREIGN_KEY_CHECKS = 1;
