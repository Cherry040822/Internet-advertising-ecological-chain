package com.example.service;

import com.example.entity.News;
import com.example.mapper.NewsMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsService {

    @Resource
    private NewsMapper newsMapper;

    // 获取所有新闻
    public List<News> getAllNews() {
        return newsMapper.getAllNews();
    }

    // 获取所有新闻标签
    public List<String> getAllTags() {
        return newsMapper.getAllTags();
    }

    // 根据ID获取新闻
    public News getNewsById(Integer id) {
        return newsMapper.getNewsById(id);
    }

    // 根据标签获取新闻列表
    public List<News> getNewsByTag(String tag) {
        return newsMapper.getNewsByTag(tag);
    }
    // 根据关键词搜索新闻
    public List<News> searchNews(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getAllNews();
        }
        return newsMapper.searchNews(query);
    }
    // 获取随机新闻用于轮播图
    public List<News> getRandomNewsForCarousel(int count) {
        return newsMapper.getRandomNewsForCarousel(count);
    }
}
