<template>

  <div v-if="newsList.length" class="news-list-container">
    <!-- Logo 和标题 -->
    <div style="height: auto; background-color: #516996; padding: 20px;">
      <div style="display: flex; align-items: center; margin-bottom: 10px;">
        <img src="@/assets/新闻.png" alt="News Website Logo" style="width: 40px;">
        <span style="font-size: 20px; font-weight: bold;color: #d1e3f6; font-style: italic;margin-left: 10px;">分类新闻</span>
      </div>
    </div>


    <div v-if="newsList.length" class="news-list">
      <p>共搜索到{{ newsList.length }} 条<strong>{{ route.params.tag }}</strong> 新闻。</p>

      <!-- 新闻列表区域 -->
      <div class="news-section">
        <div v-for="news in newsList" :key="news.id" class="news-item">
          <a style="text-decoration: none;" :href="`/news/${news.id}`" target="_blank" @click.prevent="openNewsDetail(news)">
            <div class="news-content">
              <img src="@/assets/title1-1.jpg" alt="News Icon" class="news-icon">
              <div class="news-info">
                <h3 class="news-title">{{ news.title }}</h3>
                <div class="news-meta">
                  <span>{{ news.author }}</span>
                  <span>{{ formatDate(news.publicationTime) }}</span>
                </div>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>

  </div>
  <div v-else class="no-news-message">
    暂无相关新闻。
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';

const route = useRoute();
const newsList = ref([]);



async function openNewsDetail(news) {
  const detailWindow = window.open('', encodeURIComponent(news.title));
  if (detailWindow) {
    detailWindow.location.href = `/news/${news.id}`;
  }
}
onMounted(() => {
  fetchNewsByTag();
});

async function fetchNewsByTag() {
  try {
    const response = await axios.get(`/news/tag/${route.params.tag}`);
    newsList.value = response.data.data;
  } catch (error) {
    console.error('Error fetching news by tag:', error);
  }
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}
</script>

<style scoped>
.news-list p {
  text-align: center;
  font-size: 18px;
  color: #666;
  margin-bottom: 20px;
}
.news-list-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9fb;
}

.news-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.news-section {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 5px;
}




.no-news-message {
  text-align: center;
  font-size: 18px;
  color: #666;
}

.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.news-content {
  display: flex;
  align-items: flex-start;
}

.news-icon {
  width: 50px; /* 根据需要调整大小 */
  height: 50px;
  object-fit: contain;
  margin-right: 10px; /* 图片与文本之间的间距 */
}

.news-info {
  display: flex;
  flex-direction: column;
}


.news-title {
  margin: 0 0 5px 0;
  font-size: 18px;
  color: #333;
  transition: color 0.3s ease;
}

/*当鼠标悬停在新闻标题上时改变字体颜色 */
.news-title:hover {
  color: #1e6bb7;
}


.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
}
</style>