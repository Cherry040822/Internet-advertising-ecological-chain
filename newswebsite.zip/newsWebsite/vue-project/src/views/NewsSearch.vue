<template>
  <div class="news-search-container">
    <!-- Logo 和标题 -->
    <div style="position: relative;height: auto; background-color: #e5683b; padding: 20px;">
      <div style="display: flex; align-items: center; margin-bottom: 10px;">
        <img src="@/assets/newswebsiteLogo.png" alt="News Website Logo" style="width: 40px;">
        <span style="font-size: 20px; font-weight: bold;color: black; font-style: italic;margin-left: 10px;">新闻搜索</span>
      </div>
      <!-- 搜索框 -->
      <div class="search-section" style="position: absolute; padding-right: 30px; bottom: 10px; right: 20px;">
        <el-input v-model="searchQuery" style="width: 240px" placeholder="搜索新闻" clearable @keyup.enter="fetchSearchedNews"
        >
          <template #prefix>
            <el-icon class="el-input__icon"><search /></el-icon>
          </template>
        </el-input>
        <el-button type="primary" :icon="Search" circle @click="fetchSearchedNews"/>
      </div>
    </div>

    <div v-if="newsList.length" class="news-list">
      <p>共找到 {{ totalResults }} 条相关新闻。</p>
      <div v-for="news in newsList" :key="news.id" class="news-item">
        <router-link :to="{ name: 'NewsDetail', params: { id: news.id } }">
          <h3 class="news-title">{{ news.title }}</h3>
        </router-link>
        <div class="news-meta">
          <span>{{ news.author }}</span>
          <span>{{ formatDate(news.publicationTime) }}</span>
        </div>
      </div>
    </div>
    <div v-else class="no-news-message">
      暂无相关新闻。
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';
import { Search } from "@element-plus/icons-vue";

const route = useRoute();
const router = useRouter();
const newsList = ref([]);
const totalResults = ref(0);
const searchQuery = ref('');

// 初始化时从URL获取查询参数并执行搜索
onMounted(() => {
  const query = route.query.query || '';
  if (query) {
    searchQuery.value = query;
    fetchSearchedNews();
  }
});

async function fetchSearchedNews() {
  try {
    // 更新URL中的查询参数但不触发重新加载
    const currentQuery = { ...route.query };
    if (searchQuery.value) {
      currentQuery.query = searchQuery.value;
    } else {
      delete currentQuery.query;
    }
    router.replace({ query: currentQuery });

    const response = await axios.get(`/news/search?query=${searchQuery.value}`);
    newsList.value = response.data.data;
    totalResults.value = newsList.value.length;
  } catch (error) {
    console.error('Error fetching searched news:', error);
  }
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}
</script>

<style scoped>
.news-search-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9fb;
}

.search-section {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.search-section input {
  width: 80%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.search-section button {
  padding: 10px 20px;
  margin-left: 10px;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;
}

.search-section button:hover {
  background-color: #0056b3;
}

.news-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.news-title {
  margin: 0 0 10px 0;
  font-size: 18px;
  color: #333;
}

.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
}

.no-news-message {
  text-align: center;
  font-size: 18px;
  color: #666;
}
</style>