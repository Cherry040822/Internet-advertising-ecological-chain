<template>
  <div class="news-container">

    <div style="position: relative;height: auto; background-color: #e5683b; padding: 20px;">
      <!-- Logo 和标题 -->
      <div style="display: flex; align-items: center; margin-bottom: 10px;">
        <img src="@/assets/newswebsiteLogo.png" alt="News Website Logo" style="width: 40px;">
        <span style="font-size: 20px; font-weight: bold;color: black; font-style: italic;margin-left: 10px;">新闻中心</span>
      </div>

      <!-- 标签部分 -->
      <div class="tags-section" style="display: flex; flex-wrap: wrap;">
          <el-button type="warning" v-for="tag in tags" :key="tag" @click="openTagPage(tag)" >
            {{ tag }}
          </el-button>
      </div>
      <!-- 搜索框 -->
      <div class="search-section" style="position: absolute; padding-right: 30px; bottom: 10px; right: 20px;">
        <el-input v-model="searchQuery" style="width: 240px" placeholder="搜索新闻" clearable @keyup.enter="openSearchPage"
        >
          <template #prefix>
            <el-icon class="el-input__icon"><search /></el-icon>
          </template>
        </el-input>
        <el-button type="primary" :icon="Search" circle @click="openSearchPage"/>
      </div>
    </div>
    <!-- 头部结束 -->

    <!-- 轮播图 -->
    <div class="block text-center">
      <el-carousel height="200px" motion-blur>
        <el-carousel-item v-for="(item, index) in carouselNews" :key="index">
          <div style="position: relative; width: 100%; height: 100%;">
            <!-- 使用相对路径 -->
            <img :src="'/images/' + item.imageUrl" alt="news image" style="width: 100%; height: 100%; object-fit: cover;">
            <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.5); color: white; padding: 10px;">
              <a :href="`/news/${item.id}`" target="_blank" @click.prevent="openNewsDetail(item)">
                <h3>{{ item.title }}</h3>
              </a>
            </div>
          </div>
        </el-carousel-item>
      </el-carousel>
    </div>


    <!-- 新闻列表区域 -->
    <div class="news-section">
      <div v-for="news in newsList" :key="news.id" class="news-item">
        <a :href="`/news/${news.id}`" target="_blank" @click.prevent="openNewsDetail(news)">
          <h3 class="news-title">{{ news.title }}</h3>
        </a>
        <div class="news-meta">
          <span>{{ news.author }}</span>
          <span>{{ formatDate(news.publicationTime) }}</span>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import {Search} from "@element-plus/icons-vue";

const tags = ref([])
const newsList = ref([])
const carouselNews = ref([]) // 新增属性保存轮播图新闻
const searchQuery = ref('')


async function openNewsDetail(news) {
  const detailWindow = window.open('', encodeURIComponent(news.title));
  if (detailWindow) {
    detailWindow.location.href = `/news/${news.id}`;
  }
}

const fetchData = async () => {
  try {
    const [tagsRes, newsRes] = await Promise.all([
      axios.get('/news/tags'),
      axios.get('/news/list')
    ])
    tags.value = tagsRes.data.data
    newsList.value = newsRes.data.data
  } catch (error) {
    console.error('数据获取失败:', error)
  }
}

const formatDate = (dateStr) => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  return date.toLocaleDateString('zh-CN')
}

onMounted(() => {
  fetchData()
})
function openTagPage(tag) {
  window.open(`/news/tag/${encodeURIComponent(tag)}`, '_blank');
}

function openSearchPage() {
  if (searchQuery.value) {
    window.open(`/news/search?query=${encodeURIComponent(searchQuery.value)}`, '_blank');
  }
}

// 新增函数来获取轮播图新闻
const fetchCarouselNews = async () => {
  try {
    const response = await axios.get('/news/carousel');
    carouselNews.value = response.data.data;
  } catch (error) {
    console.error('获取轮播图新闻失败:', error)
  }
}

onMounted(() => {
  fetchData();
  fetchCarouselNews(); // 页面加载时也获取轮播图新闻
})
</script>

<style scoped>
.news-container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9fb;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}


.tags-section {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 30px;
  padding: 20px 0;
  border-bottom: 1px solid #cc9644;
}

.tag {
  padding: 6px 16px;
  background-color: #f5f5f5;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s;
}

.tag:hover {
  background-color: #e0e0e0;
}

.news-section {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.news-title {
  margin: 0 0 10px 0;
  font-size: 18px;
  color: #333;
}

.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
}

.demonstration {
  color: var(--el-text-color-secondary);
}
</style>
<!--<style scoped>-->
<!--.news-container {-->
<!--  max-width: 1000px;-->
<!--  margin: 0 auto;-->
<!--  padding: 20px;-->
<!--  background-color: #f9f9fb; /* 更柔和的背景色 */-->
<!--  min-height: 100vh;-->
<!--  display: flex;-->
<!--  flex-direction: column;-->
<!--}-->

<!--/* 标签部分样式 */-->
<!--.tags-section {-->
<!--  display: flex;-->
<!--  justify-content: center;-->
<!--  flex-wrap: wrap;-->
<!--  gap: 12px;-->
<!--  margin-bottom: 30px;-->
<!--  padding: 20px 0;-->
<!--  border-bottom: 1px solid #e5e5ea;-->
<!--  background-color: #ffffff; /* 白色背景与上方区分 */-->
<!--}-->

<!--.tag {-->
<!--  padding: 6px 16px;-->
<!--  background-color: #f5f5f5;-->
<!--  border-radius: 20px;-->
<!--  cursor: pointer;-->
<!--  transition: all 0.3s;-->
<!--}-->

<!--.tag:hover {-->
<!--  background-color: #e0e0e0;-->
<!--}-->

<!--/* 搜索框部分样式 */-->
<!--.search-section {-->
<!--  position: absolute;-->
<!--  padding-right: 30px;-->
<!--  bottom: 10px;-->
<!--  right: 20px;-->
<!--}-->

<!--/* 轮播图部分样式 */-->
<!--.block.text-center {-->
<!--  margin-top: 20px;-->
<!--  margin-bottom: 20px;-->
<!--}-->

<!--.el-carousel__item h3 {-->
<!--  color: #fff;-->
<!--  opacity: 0.75;-->
<!--  line-height: 200px;-->
<!--  margin: 0;-->
<!--  text-align: center;-->
<!--}-->

<!--.el-carousel__item:nth-child(2n) {-->
<!--  background-color: #99a9bf;-->
<!--}-->

<!--.el-carousel__item:nth-child(2n+1) {-->
<!--  background-color: #d3dce6;-->
<!--}-->

<!--/* 新闻列表区域样式 */-->
<!--.news-section {-->
<!--  display: flex;-->
<!--  flex-direction: column;-->
<!--  gap: 20px;-->
<!--  background-color: #ffffff; /* 纯白背景，增加与外部背景的对比 */-->
<!--  padding: 20px;-->
<!--  border-radius: 8px;-->
<!--  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);-->
<!--  flex-grow: 1;-->
<!--}-->

<!--.news-item {-->
<!--  padding: 20px;-->
<!--  border-radius: 8px;-->
<!--  background-color: #ffffff; /* 统一的白色背景 */-->
<!--  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05); /* 较弱的阴影，提供深度 */-->
<!--  transition: all 0.3s;-->
<!--  position: relative;-->
<!--  overflow: hidden;-->
<!--}-->

<!--.news-item:hover {-->
<!--  transform: translateY(-2px);-->
<!--  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);-->
<!--}-->

<!--.news-title {-->
<!--  margin: 0 0 10px 0;-->
<!--  font-size: 18px;-->
<!--  color: #333;-->
<!--  font-weight: bold;-->
<!--}-->

<!--.news-meta {-->
<!--  display: flex;-->
<!--  gap: 20px;-->
<!--  color: #666;-->
<!--  font-size: 14px;-->
<!--  margin-top: auto;-->
<!--}-->

<!--.news-meta span::before {-->
<!--  content: '';-->
<!--  display: inline-block;-->
<!--  width: 8px;-->
<!--  height: 8px;-->
<!--  background-color: currentColor;-->
<!--  border-radius: 50%;-->
<!--  margin-right: 8px;-->
<!--}-->

<!--.demonstration {-->
<!--  color: var(&#45;&#45;el-text-color-secondary);-->
<!--}-->
<!--</style>-->