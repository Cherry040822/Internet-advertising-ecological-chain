<template>
  <!-- 主体部分 -->
  <div class="header-container">
    <div class="header-content" style="display: flex; align-items: center; margin-bottom: 10px;">
      <img src="@/assets/newswebsiteLogo.png" alt="News Website Logo" style="width: 40px;">
      <span style="font-size: 20px; font-weight: bold; color: black; font-style: italic; margin-left: 10px;">新闻详情</span>
    </div>
  </div>

  <div v-if="news" class="news-detail-container">
    <div class="news-detail">
      <h1>{{ news.title }}</h1>
      <p><strong>作者:</strong> {{ news.author }}</p>
      <p><strong>发布时间:</strong> {{ formatDate(news.publicationTime) }}</p>
      <img v-if="news.imageUrl" :src="news.imageUrl" alt="News Image" />
      <div class="news-content" v-html="news.content"></div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';

const route = useRoute();
const news = ref(null);

onMounted(() => {
  fetchNewsDetail();
});

async function fetchNewsDetail() {
  try {
    const response = await axios.get(`/news/${route.params.id}`);
    news.value = response.data.data;
  } catch (error) {
    console.error('Error fetching news detail:', error);
  }
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}
</script>

<style scoped>
/* 确保主体部分和详情部分有一样的最大宽度，并且居中 */
.header-container,
.news-detail-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  background-color: #f9f9fb;
}

.header-content,
.news-detail {
  max-width: 800px;
  width: 100%;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  text-align: center;
  padding: 40px;
}

.header-content {
  background-color: #e5683b;
  margin-bottom: 20px;
}

/* 增大详情页 content 部分的字体 */
.news-content {
  font-size: 18px; /* 根据需要调整字体大小 */
  line-height: 1.6; /* 改善行间距，使阅读更舒适 */
}

@media (min-width: 768px) {
  .news-detail {
    margin-top: 0px;
  }
}
</style>