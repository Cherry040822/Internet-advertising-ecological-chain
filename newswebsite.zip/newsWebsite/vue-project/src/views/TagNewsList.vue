<template>

  <div v-if="newsList.length" class="news-list-container">
    <!-- Logo 和标题 -->
    <div style="height: auto; background-color:#e5683b; padding: 20px;">
      <div style="display: flex; align-items: center; margin-bottom: 10px;">
        <img src="@/assets/newswebsiteLogo.png" alt="News Website Logo" style="width: 40px;">
        <span style="font-size: 20px; font-weight: bold;color: black; font-style: italic;margin-left: 10px;">分类新闻</span>
      </div>
    </div>

    <div class="news-list">
      <div v-for="news in newsList" :key="news.id" class="news-item">
        <router-link :to="{ name: 'NewsDetail', params: { id: news.id } }">
          <h3 class="news-title">{{ news.title }}</h3>
        </router-link>
        <div class="news-meta">
          <span>{{ news.author }}</span>
          <span>{{ formatDate(news.publicationTime) }}</span>
        </div>
      </div>
    </div>
  </div>
  <div v-else class="no-news-message">
    暂无相关新闻。
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';

const route = useRoute();
const newsList = ref([]);

onMounted(() => {
  fetchNewsByTag();
});

async function fetchNewsByTag() {
  try {
    const response = await axios.get(`/news/tag/${route.params.tag}`);
    newsList.value = response.data.data;
  } catch (error) {
    console.error('Error fetching news by tag:', error);
  }
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}
</script>

<style scoped>
.news-list-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9fb;
}

.news-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.news-title {
  margin: 0 0 10px 0;
  font-size: 18px;
  color: #333;
}

.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
}

.no-news-message {
  text-align: center;
  font-size: 18px;
  color: #666;
}
</style>