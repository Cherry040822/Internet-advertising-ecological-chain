package com.example.mapper;

import com.example.entity.News;

public interface NewsMapper {
    void insert(News news);

//    List<Advertisement> selectById(Advertisement advertisement, Integer userId);
//
//    @Delete("delete from  `advertisement` where title = #{title}")
//    void deleteByTitle(String title);
//
//    void update(Advertisement advertisement);
}
