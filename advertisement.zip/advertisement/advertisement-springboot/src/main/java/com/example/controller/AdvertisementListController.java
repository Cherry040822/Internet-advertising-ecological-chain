package com.example.controller;

import com.example.entity.Advertisement;
import com.example.service.AdvertisementService;
import com.example.common.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/advertisementList")
public class AdvertisementListController {

    @Resource
    private AdvertisementService advertisementService;

//    @GetMapping("/search")
//    public Result search(
//            @RequestParam(required = false) String title,
//            @RequestParam(required = false) String category) {
//        try {
//            List<Advertisement> data = advertisementService.findByCondition(title, category);
//            return Result.success(data);
//        } catch (Exception e) {
//            return Result.error("500","查询失败: " + e.getMessage());
//        }
//    }

    @PostMapping("/add")
    public Result save(@RequestBody Advertisement advertisement) {
        try {
            advertisementService.add(advertisement);
            return Result.success();
        } catch (Exception e) {
            return Result.error("500","保存失败: " + e.getMessage());
        }
    }

    @GetMapping("/selectPageById")
    public Result selectPage(Advertisement advertisement,
                             @RequestParam Integer userId,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "3") Integer pageSize) {
        PageInfo<Advertisement> pageinfo=advertisementService.selectPageById(advertisement,userId,pageNum,pageSize);
        return Result.success(pageinfo);
    }

    @PutMapping("/update")
    public Result update(@RequestBody Advertisement advertisement) {
        advertisementService.update(advertisement);
        return Result.success();
    }

    @DeleteMapping("deleteByTitle/{title}")
    public Result delete(@PathVariable String title) {
        advertisementService.deleteByTitle(title);
        return Result.success();
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<String> titles) {
        advertisementService.deleteBatch(titles);
        return Result.success();
    }
}