package com.example.mapper;

import com.example.entity.Advertisement;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

public interface AdvertisementListMapper {
    void insert(Advertisement advertisement);

    List<Advertisement> selectById(Advertisement advertisement, Integer userId);

    @Delete("delete from  `advertisement` where title = #{title}")
    void deleteByTitle(String title);

    void update(Advertisement advertisement);
}
