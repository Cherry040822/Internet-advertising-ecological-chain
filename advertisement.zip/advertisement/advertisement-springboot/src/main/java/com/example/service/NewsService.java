package com.example.service;

import com.example.entity.News;
import com.example.mapper.NewsMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class NewsService {

    @Resource
    NewsMapper newsMapper;

    public void add(News news) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        news.setCreateTime(sdf.format(new Date()));
        news.setStatus("已提交平台");
        newsMapper.insert(news);
    }

//    public PageInfo<Advertisement> selectPageById(Advertisement advertisement, Integer userId, Integer pageNum, Integer pageSize) {
//        PageHelper.startPage(pageNum,pageSize);
//        List<Advertisement> list=advertisementListMapper.selectById(advertisement, userId);
//        return PageInfo.of(list);
//    }
//
//    public void deleteBatch(List<String> titles) {
//        for (String title :titles){
//            this.deleteByTitle(title);
//        }
//    }
//
//    public void deleteByTitle(String title) {
//        advertisementListMapper.deleteByTitle(title);
//    }
//
//    public void update(Advertisement advertisement) {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        advertisement.setCreateTime(sdf.format(new Date()));
//        advertisementListMapper.update(advertisement);
//    }
}
