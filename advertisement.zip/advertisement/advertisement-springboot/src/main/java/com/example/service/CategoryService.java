package com.example.service;

import com.example.entity.Category;
import com.example.mapper.CategoryMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    @Resource
    private CategoryMapper categoryMapper;

    public List<Category> selectAll(Category category) {
        return categoryMapper.selectAll(category);
    }
}
