package com.example.service;

import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import com.example.mapper.AdvertisementListMapper;
import com.example.mapper.ShoppingMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class ShoppingService {

    @Resource
    ShoppingMapper shoppingMapper;

    public void add(Shopping shopping) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        shopping.setCreateTime(sdf.format(new Date()));
        shopping.setStatus("已提交平台");
        shoppingMapper.insert(shopping);
    }

//    public PageInfo<Advertisement> selectPageById(Advertisement advertisement, Integer userId, Integer pageNum, Integer pageSize) {
//        PageHelper.startPage(pageNum,pageSize);
//        List<Advertisement> list=advertisementListMapper.selectById(advertisement, userId);
//        return PageInfo.of(list);
//    }
//
//    public void deleteBatch(List<String> titles) {
//        for (String title :titles){
//            this.deleteByTitle(title);
//        }
//    }
//
//    public void deleteByTitle(String title) {
//        advertisementListMapper.deleteByTitle(title);
//    }
//
//    public void update(Advertisement advertisement) {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        advertisement.setCreateTime(sdf.format(new Date()));
//        advertisementListMapper.update(advertisement);
//    }
}
