<template>
  <div style="display: flex;align-content: center;justify-content: center;width: 300px;height: 300px">
    <img :src="data.image" alt="" @click="goToLinkDetails"/>
  </div>
</template>

<script setup>
import {onMounted, reactive} from "vue";
import request from '@/utils/request.js'
import {useRoute} from "vue-router";
import Cookies from "js-cookie";
import { v4 as uuidv4 } from 'uuid'

const data = (reactive({
  image:'',
  user:''
}))
const route = useRoute();
const adId = route.params.id;

const load = () => {
  request.get(`/advertisementList/selectUrlById/${adId}`).then(res =>{
    data.image = res.data.image;
  })
}

const goToLinkDetails = () => {
  window.open(`/LinkDetails/${adId}`, '_blank')
  request.put(`/news/updateClick/${adId}`).then(res => {

  })
}
data.user=uuidv4()
const selectUser = ()=>{
  const user=Cookies.get('user')
  console.log(user)
  request.get(`webUser/selectByUser/${user}`).then(res=>{
    if(res.code === '500'){
      Cookies.set('ad_user', data.user, {
        path: '/',
        domain: 'localhost',
        sameSite: 'Lax'
      });
      request.get(`webUser/add/${data.user}`).then(res=>{})
    }
  })
}
selectUser()
onMounted( () => {
  load()
})
</script>

<style scoped>

</style>