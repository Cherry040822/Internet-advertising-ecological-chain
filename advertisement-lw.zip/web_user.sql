/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : advertisement

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 27/12/2024 23:24:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for web_user
-- ----------------------------
DROP TABLE IF EXISTS `web_user`;
CREATE TABLE `web_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of web_user
-- ----------------------------
INSERT INTO `web_user` VALUES (1, '123');
INSERT INTO `web_user` VALUES (2, '123445');
INSERT INTO `web_user` VALUES (3, 'e39ff03f-3d21-4385-a922-002361ee2fcf');
INSERT INTO `web_user` VALUES (4, '506a03a6-2570-4b41-a8df-a366ee2cdfed');
INSERT INTO `web_user` VALUES (5, 'bbf2690c-ed20-4c34-a5ed-cf792207eebf');
INSERT INTO `web_user` VALUES (6, 'f094ddeb-c27e-406e-a102-044194de3f03');
INSERT INTO `web_user` VALUES (7, '74440d46-81b8-4905-a2ac-644a121acd22');
INSERT INTO `web_user` VALUES (8, 'acac17bf-f3c9-4b77-a77a-6b735dcff176');
INSERT INTO `web_user` VALUES (9, '454c1d60-3a4f-4058-8f39-776c12c89c05');

SET FOREIGN_KEY_CHECKS = 1;
