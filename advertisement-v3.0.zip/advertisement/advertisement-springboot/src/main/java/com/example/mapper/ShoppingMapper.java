package com.example.mapper;

import com.example.entity.Advertisement;
import com.example.entity.Shopping;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface ShoppingMapper {
    void insert(Shopping shopping);

    boolean selectByAdvertisementId(Integer advertisementId);

    List <Shopping> selectUrlByAdvertisementId();

    void updateClickByAdvertisementId(Integer advertisementId);

    Shopping selectMoneyByAdvertisementId(Integer advertisementId);

    @Delete("delete from  `advertisement_shopping` where advertisement_id = #{id}")
    void deleteByAdvertisementId(Integer id);

    void update(Advertisement advertisement);

    void sumClick();

    List<Map<String, Object>> selectAdvertisementData();

    List<Map<String, Object>> groupByAdvertisementClicks();

    boolean selectByUserId(Integer userId);

    Shopping selectMoneyByUserId(Integer userId);

//    List<Advertisement> selectById(Advertisement advertisement, Integer userId);
//
//    @Delete("delete from  `advertisement` where title = #{title}")
//    void deleteByTitle(String title);
//
//    void update(Advertisement advertisement);
}
