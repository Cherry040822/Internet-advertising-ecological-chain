package com.example.service;

import com.example.entity.Advertisement;
import com.example.mapper.AdvertisementListMapper;
import com.example.mapper.NewsMapper;
import com.example.mapper.ShoppingMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class AdvertisementService {

    @Resource
    AdvertisementListMapper advertisementListMapper;
    @Autowired
    private ShoppingMapper shoppingMapper;
    @Autowired
    private NewsMapper newsMapper;

    public void add(Advertisement advertisement) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        advertisement.setCreateTime(sdf.format(new Date()));
        advertisement.setStatus("未投放");
        advertisementListMapper.insert(advertisement);
    }

    public PageInfo<Advertisement> selectPageById(Advertisement advertisement, Integer userId, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<Advertisement> list=advertisementListMapper.selectById(advertisement, userId);
        return PageInfo.of(list);
    }

    public void deleteBatch(List<Integer> ids) {
        for (Integer id :ids){
            this.deleteById(id);
        }
    }

    public void deleteById(Integer id) {

        advertisementListMapper.deleteById(id);
        shoppingMapper.deleteByAdvertisementId(id);
        newsMapper.deleteByAdvertisementId(id);
    }

    public void update(Advertisement advertisement) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        advertisement.setCreateTime(sdf.format(new Date()));
        advertisementListMapper.update(advertisement);
        shoppingMapper.update(advertisement);
        newsMapper.update(advertisement);
    }

    public Advertisement selectUrlById(Integer id) {
        return advertisementListMapper.selectUrlById(id);
    }
}
