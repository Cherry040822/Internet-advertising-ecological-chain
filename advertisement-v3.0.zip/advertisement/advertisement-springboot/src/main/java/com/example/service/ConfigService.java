package com.example.service;

import com.example.entity.Config;
import com.example.mapper.ConfigMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConfigService {

    @Resource
    private ConfigMapper configMapper;

    public List<Config> selectAll() {
        return configMapper.selectAll();
    }
}
