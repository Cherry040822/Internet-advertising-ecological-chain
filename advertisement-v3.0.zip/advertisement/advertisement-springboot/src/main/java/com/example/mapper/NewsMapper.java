package com.example.mapper;

import com.example.entity.Advertisement;
import com.example.entity.News;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface NewsMapper {
    void insert(News news);

    boolean selectByAdvertisementId(Integer advertisementId);

    List<News> selectUrlByAdvertisementId();

    void updateClickByAdvertisementId(Integer advertisementId);

    News selectMoneyByAdvertisementId(Integer advertisementId);

    @Delete("delete from  `advertisement_news` where advertisement_id = #{id}")
    void deleteByAdvertisementId(Integer id);

    void update(Advertisement advertisement);

    void sumClick();

    List<Map<String, Object>> selectAdvertisementData();

    List<Map<String, Object>> groupByAdvertisementClicks();

    boolean selectByUserId(Integer userId);

    News selectMoneyByUserId(Integer userId);

//    List<Advertisement> selectById(Advertisement advertisement, Integer userId);
//
//    @Delete("delete from  `advertisement` where title = #{title}")
//    void deleteByTitle(String title);
//
//    void update(Advertisement advertisement);
}
