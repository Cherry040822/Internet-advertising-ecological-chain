package com.example.controller;

import com.example.entity.Advertisement;
import com.example.entity.Platform;
import com.example.entity.Shopping;
import com.example.service.AdvertisementService;
import com.example.common.Result;
import com.example.service.NewsService;
import com.example.service.ShoppingService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.Resource;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/advertisementList")
public class AdvertisementListController {

    @Resource
    private AdvertisementService advertisementService;
    @Resource
    private ShoppingService shoppingService;
    @Resource
    private NewsService newsService;

//    @GetMapping("/search")
//    public Result search(
//            @RequestParam(required = false) String title,
//            @RequestParam(required = false) String category) {
//        try {
//            List<Advertisement> data = advertisementService.findByCondition(title, category);
//            return Result.success(data);
//        } catch (Exception e) {
//            return Result.error("500","查询失败: " + e.getMessage());
//        }
//    }

    @PostMapping("/add")
    public Result save(@RequestBody Advertisement advertisement) {
        try {
            advertisementService.add(advertisement);
            return Result.success();
        } catch (Exception e) {
            return Result.error("500","保存失败: " + e.getMessage());
        }
    }

    @GetMapping("/selectPageById")
    public Result selectPage(Advertisement advertisement,
                             @RequestParam Integer userId,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "3") Integer pageSize) {
        PageInfo<Advertisement> pageinfo=advertisementService.selectPageById(advertisement,userId,pageNum,pageSize);
        return Result.success(pageinfo);
    }

    @GetMapping("selectUrlById/{id}")
    public Result selectUrlById(@PathVariable Integer id) {
        return Result.success(advertisementService.selectUrlById(id));
    }

    @PutMapping("/update")
    public Result update(@RequestBody Advertisement advertisement) {
        advertisementService.update(advertisement);
        return Result.success();
    }

    @DeleteMapping("deleteById/{id}")
    public Result delete(@PathVariable Integer id) {
        advertisementService.deleteById(id);
        return Result.success();
    }

    @DeleteMapping("/deleteBatch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        advertisementService.deleteBatch(ids);
        return Result.success();
    }

    @GetMapping("/selectWebName/{advertisementId}")
    public Result selectWebName(@PathVariable Integer advertisementId) {
        List<Platform> platforms = new ArrayList<>();
        if (shoppingService.selectByAdvertisementId(advertisementId)){
            Platform platform = new Platform();
            platform.setWebName("购物中心");
            platform.setWebUrl("http://8.153.75.78");
            platforms.add(platform);
        }
        if (newsService.selectByAdvertisementId(advertisementId)){
            Platform platform = new Platform();
            platform.setWebName("新闻中心");
            platform.setWebUrl("http://139.196.169.158");
            platforms.add(platform);
        }
        return Result.success(platforms);
    }

    @GetMapping("/selectWebNameByUserId/{userId}")
    public Result selectWebNameByUserId(@PathVariable Integer userId) {
        List<Platform> platforms = new ArrayList<>();
        if (shoppingService.selectByuserId(userId)){
            Platform platform = new Platform();
            platform.setWebName("购物中心");
            platform.setWebUrl("http://8.153.75.78");
            platforms.add(platform);
        }
        if (newsService.selectByUserId(userId)){
            Platform platform = new Platform();
            platform.setWebName("新闻中心");
            platform.setWebUrl("http://139.196.169.158");
            platforms.add(platform);
        }
        return Result.success(platforms);
    }
}