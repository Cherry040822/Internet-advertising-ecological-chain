import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/Index',
      name: 'Index',
      component: () => import('@/views/Index.vue'),
      meta: { title: '广告投放与管理' },
      children: [
        { path: '/AdvertisementList', name: 'AdvertisementList', meta: { title: '广告投放' }, component: () => import('@/views/AdvertisementList.vue')},
        { path: '/Person', name: 'Person', meta: { title: '个人资料' }, component: () => import('@/views/Person.vue')},
        { path: '/UserData', name: 'UserData', meta: { title: '整体数据' }, component: () => import('@/views/UserData.vue')},
        ]
    },
    { path: '/', name: 'Login', meta:{ title:'登录' }, component: () => import('@/views/Login.vue')},
    { path: '/Register', name: 'Register', meta:{ title:'注册' }, component: () => import('@/views/Register.vue')},
    { path: '/DataDetails/:id', name: 'DataDetails', meta: { title: '数据详情' }, component: () => import('@/views/DataDetails.vue'),props:true},
    { path: '/LinkShopping/:id', name: 'LinkShopping', meta: { title: '购物广告内嵌' }, component: () => import('@/views/LinkShopping.vue')},
    { path: '/LinkNews/:id', name: 'LinkNews', meta: { title: '新闻广告内嵌' }, component: () => import('@/views/LinkNews.vue')},
    { path: '/LinkDetails/:id', name: 'LinkDetails', meta: { title: '广告详情' }, component: () => import('@/views/LinkDetails.vue'),props:true},
  ],
})

router.beforeEach((to,from,next) => {
  document.title = to.meta.title
  next()
})
export default router
