/*
 Navicat Premium Data Transfer

 Source Server         : usst
 Source Server Type    : MySQL
 Source Server Version : 80300 (8.3.0)
 Source Host           : localhost:3306
 Source Schema         : advertisement

 Target Server Type    : MySQL
 Target Server Version : 80300 (8.3.0)
 File Encoding         : 65001

 Date: 24/12/2024 04:36:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for advertisement
-- ----------------------------
DROP TABLE IF EXISTS `advertisement`;
CREATE TABLE `advertisement`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of advertisement
-- ----------------------------
INSERT INTO `advertisement` VALUES (35, '乌萨奇', '乌萨奇最可爱', 'http://localhost:9090/files/download/1734980283072_屏幕截图 2024-12-19 145128.png', '动漫', '动漫', '2024-12-24 02:58:32', '已投放第三方平台', 1, 'user001');
INSERT INTO `advertisement` VALUES (36, '红烧肉', '红烧肉是一道江浙菜', 'http://localhost:9090/files/download/1734980545165_屏幕截图 2024-12-13 221949.png', '食物', '美食', '2024-12-24 03:09:46', '已提交平台', 1, 'user001');
INSERT INTO `advertisement` VALUES (37, '国产科幻电影', '国产科幻电影质量越来越高', 'http://localhost:9090/files/download/1734980701211_屏幕截图 2024-12-22 160600.png', '科技', '科幻电影', '2024-12-24 03:05:38', '未投放', 1, 'user001');

-- ----------------------------
-- Table structure for advertisement_news
-- ----------------------------
DROP TABLE IF EXISTS `advertisement_news`;
CREATE TABLE `advertisement_news`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  `click` int NULL DEFAULT 0,
  `sum_click` int NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of advertisement_news
-- ----------------------------
INSERT INTO `advertisement_news` VALUES (31, '乌萨奇', '乌萨奇最可爱', 'http://localhost:9090/files/download/1734980283072_屏幕截图 2024-12-19 145128.png', '动漫', '动漫', '2024-12-24 02:58:32', '已提交平台', 1, 'user001', 35, 3, 3, 'http://localhost:3001/LinkNews/35');
INSERT INTO `advertisement_news` VALUES (32, '红烧肉', '红烧肉是一道江浙菜', 'http://localhost:9090/files/download/1734980545165_屏幕截图 2024-12-13 221949.png', '食物', '美食', '2024-12-24 03:09:46', '已提交平台', 1, 'user001', 36, 0, 0, 'http://localhost:3001/LinkNews/36');

-- ----------------------------
-- Table structure for advertisement_shopping
-- ----------------------------
DROP TABLE IF EXISTS `advertisement_shopping`;
CREATE TABLE `advertisement_shopping`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  `click` int NULL DEFAULT 0,
  `sum_click` int NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of advertisement_shopping
-- ----------------------------
INSERT INTO `advertisement_shopping` VALUES (40, '乌萨奇', '乌萨奇最可爱', 'http://localhost:9090/files/download/1734980283072_屏幕截图 2024-12-19 145128.png', '动漫', '动漫', '2024-12-24 02:58:32', '已提交平台', 1, 'user001', 35, 1, 1, 'http://localhost:3001/LinkShopping/35');
INSERT INTO `advertisement_shopping` VALUES (41, '红烧肉', '红烧肉是一道江浙菜', 'http://localhost:9090/files/download/1734980545165_屏幕截图 2024-12-13 221949.png', '食物', '美食', '2024-12-24 03:09:46', '已提交平台', 1, 'user001', 36, 0, 0, 'http://localhost:3001/LinkShopping/36');

-- ----------------------------
-- Table structure for annual
-- ----------------------------
DROP TABLE IF EXISTS `annual`;
CREATE TABLE `annual`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `click` int NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `money` int NULL DEFAULT NULL COMMENT '总收益，不计算三方分账',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of annual
-- ----------------------------

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, '女装');
INSERT INTO `category` VALUES (2, '科技');
INSERT INTO `category` VALUES (3, '动漫');
INSERT INTO `category` VALUES (4, '食物');

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_money` int NULL DEFAULT NULL,
  `web_money` int NULL DEFAULT NULL,
  `adm_money` int NULL DEFAULT NULL,
  `time` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `day` int NULL DEFAULT NULL COMMENT '投放间隔天数',
  `money` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES (1, 40, 30, 30, NULL, NULL, 100);

-- ----------------------------
-- Table structure for daily
-- ----------------------------
DROP TABLE IF EXISTS `daily`;
CREATE TABLE `daily`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `click` int NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `money` int NULL DEFAULT NULL COMMENT '总收益，不计算三方分账',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of daily
-- ----------------------------

-- ----------------------------
-- Table structure for monthly
-- ----------------------------
DROP TABLE IF EXISTS `monthly`;
CREATE TABLE `monthly`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `click` int NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `money` int NULL DEFAULT NULL COMMENT '总收益，不计算三方分账',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of monthly
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `web_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `web_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'user001', '123456', 'USER', NULL, NULL);
INSERT INTO `user` VALUES (2, 'admin001', '12345', 'ADMIN', NULL, NULL);
INSERT INTO `user` VALUES (3, 'user002', '123456', 'USER', NULL, NULL);
INSERT INTO `user` VALUES (14, 'webMaster001', '123456', 'WEBMASTER', '购物中心', 'http://8.153.105.33');
INSERT INTO `user` VALUES (15, 'webMaster002', '123456', 'WEBMASTER', '新闻中心', 'http://www.baidu.com');

SET FOREIGN_KEY_CHECKS = 1;
