<template>
  <div class="data-container">
    <el-row>
      <el-col :span="12">
        <el-card>
          <template #header>
            <div class="section-title">已投放平台</div>
          </template>
          <div style="height: 100px;display: flex;align-content: center;">
            <el-radio-group v-model="data.webName" @change="handlePlatformChange">
              <div v-for="platform in data.webNames" :key="platform.webName">
                <el-radio :label="platform.webName">
                  <span class="platform-text">{{ platform.webName }} -</span>
                  <a :href="platform.webUrl" target="_blank" class="platform-url">{{ platform.webUrl }}</a>
                </el-radio>
              </div>
            </el-radio-group>
          </div>
          <template #footer>
            <div class="section-title">当前数据来自：{{ data.selectedPlatform }}</div>
          </template>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card>
          <el-row class="total-stats">
            <el-col :span="8">
              <el-statistic
                  title="总点击量"
                  :value="data.sumClick"
                  :titleStyle
                  class="stat-item"
              />
            </el-col>
            <el-col :span="8">
              <el-statistic
                  title="总收益"
                  :value="data.totalEarnings"
                  :prefix="'¥'"
                  class="stat-item"
              />
            </el-col>
            <el-col :span="8">
              <el-statistic
                  title="个人所得"
                  :value="data.personalProfits"
                  :prefix="'¥'"
                  class="stat-item"
              />
            </el-col>
          </el-row>
          <el-row>
            <div ref="totalPieChart" class="pie-chart"></div>
          </el-row>
        </el-card>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="8">
        <el-card>
          <!-- 周数据统计图 -->
          <div ref="weekChart" class="chart"></div>
        </el-card>
      </el-col>

      <el-col :span="8">
        <el-card>
          <!-- 月数据统计图 -->
          <div ref="monthChart" class="chart"></div>
        </el-card>
      </el-col>

      <el-col :span="8">
        <el-card>
          <!-- 年数据统计图 -->
          <div ref="yearChart" class="chart"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import request from "@/utils/request.js";
import { onMounted, reactive, ref } from "vue";
import { useRoute } from "vue-router";
import { useTransition } from "@vueuse/core";
import * as echarts from 'echarts'; // 导入 ECharts

const data = reactive({
  webNames: [],
  webName: "", // 用于存储当前选择的平台名称
  selectedPlatform: "",  // 用于显示已选择的平台
  config: {
    userMoney:0,
    money:0
  },
  sumClick:0 ,
  totalEarnings: 0,  // 总收益
  personalProfits: 0, // 个人所得
  weeklyData: {
    dates: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    clicks: [120, 132, 101, 134, 90, 230, 210],
    revenue: [1500, 1600, 1400, 1550, 1800, 2000, 1900],
    income: [600, 650, 580, 620, 750, 800, 760],
  },
  monthlyData: {
    dates: Array.from({ length: 30 }, (_, i) => `${i + 1}日`),
    clicks: Array.from({ length: 30 }, () => Math.floor(Math.random() * 200 + 100)),
    revenue: Array.from({ length: 30 }, () => Math.floor(Math.random() * 1000 + 1000)),
    income: Array.from({ length: 30 }, () => Math.floor(Math.random() * 400 + 400)),
  },
  yearlyData: {
    dates: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    clicks: [3200, 3500, 3700, 3900, 4200, 4500, 4800, 5100, 5400, 5700, 6000, 6300],
    revenue: [45000, 48000, 51000, 54000, 57000, 60000, 63000, 66000, 69000, 72000, 75000, 78000],
    income: [18000, 19200, 20400, 21600, 22800, 24000, 25200, 26400, 27600, 28800, 30000, 31200],
  },
});
const route = useRoute();
const adId = route.params.id;
// Load platforms
const webNamesLoad = () => {
  const route = useRoute();
  const adId = route.params.id;
  request.get(`/advertisementList/selectWebName/${adId}`).then(res => {
    data.webNames = res.data;
    // 设置默认选中的平台为第一个
    if (data.webNames.length > 0) {
      data.webName = data.webNames[0].webName;  // 默认选择第一个平台
      data.selectedPlatform = data.webName;    // 显示默认选择的平台
    }
    statisticsLoad();
    drawPieChart();
  });
};
console.log("已选择："+data.selectedPlatform);
const statisticsLoad = () => {
  request.get('/config/selectAll').then(res =>{
    data.config.money = res.data[0].money;
    data.config.userMoney = res.data[0].userMoney;
    console.log(res.data[0])
  })
  if(data.selectedPlatform === "购物中心"){
    request.get(`/shopping/selectByAdvertisementId/${adId}`).then(res => {
      data.sumClick = res.data.sumClick;
      data.totalEarnings = data.sumClick * data.config.money;
      data.personalProfits = data.totalEarnings * data.config.userMoney/100;
      drawPieChart();
    })
  }else if(data.selectedPlatform === "新闻中心"){
    request.get(`news/selectByAdvertisementId/${adId}`).then(res => {
      data.sumClick = res.data.sumClick;
      data.totalEarnings = data.sumClick * data.config.money;
      data.personalProfits = data.totalEarnings * data.config.userMoney/100;
      drawPieChart();
    })
  }

}

const handlePlatformChange = () => {
  // 更新 selectedPlatform 变量为当前选择的 webName
  data.selectedPlatform = data.webName
  console.log(data.selectedPlatform)
  statisticsLoad();
  drawPieChart();
};

// 过渡动画
const source1 = ref(0);
const totalHits = useTransition(source1, { duration: 1500 });
source1.value = data.sumClick;

const source2 = ref(0);
const totalEarnings = useTransition(source2, { duration: 1500 });
source2.value = data.totalEarnings;

const source3 = ref(0);
const personalProfits = useTransition(source3, { duration: 1500 });
source3.value = data.personalProfits;

const drawPieChart = () => {
  const chart = echarts.init(document.querySelector('.pie-chart')); // 获取饼图容器
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {d}%',
    },
    legend: {
      orient: 'vertical',  // 垂直排列图例
      left: '10%',  // 设置图例的水平位置
      bottom: '10%',  // 设置图例的垂直位置为底部
      itemHeight: 10,  // 调整图例项的高度
      itemWidth: 10,   // 调整图例项的宽度
      textStyle: {
        color: '#2b2b2c',  // 设置图例文字颜色
        fontSize: 18,   // 设置图例文字大小
      },
    },
    series: [
      {
        name: '收益分布',
        type: 'pie',
        radius: ['35px','85px'],
        avoidLabelOverlap: false,
        label: {
          show: false,
          position: 'left',
        },
        emphasis: {
          label: {
            show: false,
            fontSize: '20',
            fontWeight: 'bold',
          },
        },
        data: [
          {
            value: data.personalProfits,
            name: '个人所得',
            itemStyle: {
              color: '#2e85cc', // 个人所得的颜色
            },
          },
          {
            value: data.totalEarnings - data.personalProfits,
            name: '其他',
            itemStyle: {
              color: '#103ea1', // 总收益剩余部分的颜色
            },
          },
        ],
      },
    ],
  };

  chart.setOption(option); // 设置图表配置
};
const weekChart = ref(null);
const monthChart = ref(null);
const yearChart = ref(null);
// 绘制周统计图
const drawWeekChart = () => {
  const chart = echarts.init(weekChart.value);
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross' },
    },
    legend: { data: ['点击量', '总收益', '个人所得'] },
    xAxis: { type: 'category', data: data.weeklyData.dates },
    yAxis: [
      { type: 'value', name: '点击量' },
      { type: 'value', name: '收益', position: 'right' },
    ],
    series: [
      { name: '点击量', type: 'bar', data: data.weeklyData.clicks },
      { name: '总收益', type: 'line', data: data.weeklyData.revenue },
      { name: '个人所得', type: 'line', data: data.weeklyData.income },
    ],
  };
  chart.setOption(option);
};

// 绘制月统计图
const drawMonthChart = () => {
  const chart = echarts.init(monthChart.value);
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross' },
    },
    legend: { data: ['点击量', '总收益', '个人所得'] },
    xAxis: { type: 'category', data: data.monthlyData.dates },
    yAxis: [
      { type: 'value', name: '点击量' },
      { type: 'value', name: '收益', position: 'right' },
    ],
    series: [
      { name: '点击量', type: 'bar', data: data.monthlyData.clicks },
      { name: '总收益', type: 'line', data: data.monthlyData.revenue },
      { name: '个人所得', type: 'line', data: data.monthlyData.income },
    ],
  };
  chart.setOption(option);
};

// 绘制年统计图
const drawYearChart = () => {
  const chart = echarts.init(yearChart.value);
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross' },
    },
    legend: { data: ['点击量', '总收益', '个人所得'] },
    xAxis: { type: 'category', data: data.yearlyData.dates },
    yAxis: [
      { type: 'value', name: '点击量' },
      { type: 'value', name: '收益', position: 'right' },
    ],
    series: [
      { name: '点击量', type: 'bar', data: data.yearlyData.clicks },
      { name: '总收益', type: 'line', data: data.yearlyData.revenue },
      { name: '个人所得', type: 'line', data: data.yearlyData.income },
    ],
  };
  chart.setOption(option);
};
onMounted(() => {
  webNamesLoad();
  statisticsLoad();
  drawPieChart(); // 初始化饼图
  drawWeekChart();
  drawMonthChart();
  drawYearChart();
});
</script>

<style scoped>
.data-container {
  height: 100vh;
  overflow: hidden;
  background: url("@/assets/dataDetailsBg.png");
  background-size: cover;
}

.el-card {
  background-color: rgba(255, 255, 255, 0.7); /* 保持透明背景 */
  box-shadow: 0 0 8px rgb(245, 245, 245); /* 增加阴影效果 */
  margin: 20px;
}

.section-title {
  font-size: 22px; /* 增大字体 */
  font-weight: bolder;
  color: #34495e; /* 深色 */
  padding-bottom: 10px;
  display: flex;
  justify-content: flex-start;
  text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); /* 添加文字阴影 */
  letter-spacing: 2px; /* 增加字间距 */
  background: linear-gradient(90deg, #04173f, #4a93c2); /* 渐变色 */
  -webkit-background-clip: text; /* 让文字呈现渐变色 */
  color: transparent; /* 文字颜色透明，展示渐变 */
}

.platform-text {
  font-size: 20px; /* 设置平台文字大小 */
  color: #34495e; /* 深灰色 */
  font-family: 'Arial', sans-serif; /* 字体样式 */
  font-weight: bold; /* 适当加粗 */
  letter-spacing: 2px; /* 调整字间距 */
  background: linear-gradient(90deg, #04173f, #4a93c2);
  -webkit-background-clip: text; /* 让文字呈现渐变色 */
  color: transparent; /* 文字颜色透明，展示渐变 */
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3); /* 给链接添加阴影 */
}

.platform-url {
  font-size: 20px; /* 设置链接文字大小 */
  color: #2980b9; /* 深蓝色 */
  margin-left: 5px;
  font-weight: bold;
  text-decoration: underline; /* 添加下划线 */
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3); /* 给链接添加阴影 */
}

:deep(.el-statistic__head) {
  font-size: 18px;
  margin-bottom: 10px;
  font-weight: bold;
}

:deep(.el-statistic__content) {
  font-size: 20px;
  color: #333;
  font-weight: bold;
}

:deep(.el-statistic__prefix) {
  font-size: 20px;
  color: #333;
  font-weight: bold;
}

.stat-item {
  text-align: center;
}

.pie-chart {
  height: 180px;
  width: 100%;
  margin-top: 20px;
}
.chart {
  height: 300px;
}
</style>

