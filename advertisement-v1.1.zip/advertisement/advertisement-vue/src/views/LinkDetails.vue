<template>
  <el-row>
    <el-col span="12">
        <img :src="data.image" alt=""/>
    </el-col>
    <el-col span="12">
      <el-card>
        {{data.content}}
      </el-card>
    </el-col>
  </el-row>

</template>

<script setup>
import {onMounted, reactive} from "vue";
import request from '@/utils/request.js'
import {useRoute} from "vue-router";

const data = (reactive({
  image:'',
  content:'',
}))
const route = useRoute();
const adId = route.params.id;

const load = () => {
  request.get(`/advertisementList/selectUrlById/${adId}`).then(res =>{
    data.image = res.data.image;
    data.content = res.data.content;
  })
}
onMounted(() =>{
  load()
})
</script>

<style scoped>

</style>