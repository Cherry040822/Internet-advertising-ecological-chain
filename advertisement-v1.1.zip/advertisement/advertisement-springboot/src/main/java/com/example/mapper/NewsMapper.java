package com.example.mapper;

import com.example.entity.News;

import java.util.List;

public interface NewsMapper {
    void insert(News news);

    boolean selectByAdvertisementId(Integer advertisementId);

    List<News> selectUrlByAdvertisementId();

    void updateClickByAdvertisementId(Integer advertisementId);

    News selectMoneyByAdvertisementId(Integer advertisementId);

//    List<Advertisement> selectById(Advertisement advertisement, Integer userId);
//
//    @Delete("delete from  `advertisement` where title = #{title}")
//    void deleteByTitle(String title);
//
//    void update(Advertisement advertisement);
}
