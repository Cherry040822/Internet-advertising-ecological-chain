<template>
  <div class="product-page">
    <!-- 广告区域 -->
    <div class="ad-section">

    </div>
                                             <!-- 分类菜单栏 -->
    <!-- 分类菜单栏调整 -->
    <div class="menu-bar">
      <el-select
          v-model="selectedCategory"
          placeholder="选择分类"
          @change="selectByCategory"
          class="category-select">
        <el-option
            v-for="category in data.categories"
            :key="category"
            :label="category"
            :value="category">
        </el-option>
      </el-select>
      <el-button @click="loadproducts" type="warning">显示所有宝贝</el-button>
    </div>


    <!-- 顶部搜索栏调整 -->
    <div class="search-bar">
      <div class="title-section">
        <el-icon class="shop-icon"><Shop /></el-icon>
        <div class="title-content">
          <span class="shop-title">购物中心</span>
          <span class="shop-subtitle">优质好物 · 品质保证 · 售后无忧</span>
        </div>
      </div>
      <div class="search-section">
        <el-input
            v-model="data.searchText"
            placeholder="搜索宝贝名"
            clearable
            class="search-input">
        </el-input>
        <el-button
            type="warning"
            @click="selectByname"
            class="search-button"
        >
          <el-icon><Search /></el-icon>
          搜索
        </el-button>
        <el-button
            @click="showCart = true"
            type="warning"
            class="cart-button"
        >
          <el-icon><ShoppingCart /></el-icon>
          购物车
        </el-button>
        </div>
    </div>

    <!-- 轮播图部分修改 -->
    <el-carousel trigger="click" :interval="5000" height="400px" class="carousel-container" style="margin-bottom: 20px;">
      <el-carousel-item v-for="(image, index) in carouselImages" :key="index">
        <img :src="image" alt="广告图片" class="carousel-image" />
      </el-carousel-item>
    </el-carousel>
                                               <!-- 商品列表 -->
    <!-- 商品列表部分保持原有的margin -->
    <div style="display: flex">



      <div>
        <el-row :gutter="20" class="product-list" style="margin-left: 200px;margin-right: 100px">
          <el-col :span="6" v-for="product in data.items" :key="product.productId" style="margin-bottom: 20px">
            <el-card shadow="hover" class="product-card">
              <div class="product-content">
                <img :src="product.imageUrl" alt="商品图片" class="product-image"/>
                <div class="product-info">
                  <h3 class="product-name">{{ product.name }}</h3>
                  <p class="product-price">火热价：￥{{ product.price }}</p>
                </div>
              </div>
              <!-- 商品卡片按钮部分调整 -->
              <div class="product-actions">
                <el-button class="action-button" size="large" @click="viewDetails(product.productId)">
                  <el-icon><View /></el-icon> 查看详情
                </el-button>
                <el-button class="action-button" type="warning" size="large" @click="insertcart(product)">
                  <el-icon><ShoppingCart /></el-icon> 加入购物车
                </el-button>
              </div>
            </el-card>
          </el-col>
        </el-row>
        <div class="card" v-if="data.total">
          <el-pagination
              @current-change="loadproducts"
              layout="prev, pager, next"
              :page-size="data.pageSize"
              v-model:current-page="data.pageNum"
              :total="data.total"
              background="true"
          />
        </div>
      </div>
      <div>
        <div v-for="item in data.advertisement.slice(0, 5)" :key="item.id">
          <iframe :src="item.url" width="150px" height="150px" scrolling="no"></iframe>
        </div>
      </div>

    </div>


    <!--弹窗内容-->
    <!-- 购物车弹窗 -->
    <el-dialog v-model="showCart" title="购物车" width="30%">
      <!-- 嵌入购物车页面的内容 -->
      <div class="cartItems">
        <el-card
            v-for="(item, index) in data.cartItems"
            :key="item.id"
            style="max-width: 1300px; margin-bottom: 5px; background-color: rgb(255,255,255); border: 1px solid orange; "
        >
          <template #header>{{ item.name }}</template>
          <div>单价：{{ item.price }}</div>
          <!-- 加购按钮和数量框 -->
          <div class="card-footer" style="margin-top: 10px; display: flex; align-items: center; justify-content: space-between;">
            <!-- 显示“+”和“-”按钮以及数量 -->
            <div style="display: flex; align-items: center;">
              <!-- 减少数量的按钮 -->
              <el-button @click="decrease(item)" size="small" style="padding: 0 10px;">
                -
              </el-button>

              <!-- 数量显示框 -->
              <span style="width: 40px; text-align: center; font-size: 16px; margin: 0 10px;">
      {{ item.quantity }}
    </span>

              <!-- 增加数量的按钮 -->
              <el-button @click="increase(item)" size="small" style="padding: 0 10px;">
                +
              </el-button>
            </div>

            <!-- 加入购物车按钮 -->
            <el-button
                type="danger"
                @click="removeFromCart(item)"
                style="margin-left: 10px; padding: 5px 20px; height: 32px;"
            >
              删除
            </el-button>
          </div>
        </el-card>
        <div style="font-size: large; display: flex; justify-content: center; align-items: center;">
          <el-button type="warning" @click="turntocheckout">下单</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>


<script setup>
import {reactive, ref} from "vue";
import request from "@/utils/request.js";
import {ElMessage} from "element-plus";
import router from "@/router/index.js";
import res from "@/utils/res.js"
const data=reactive({
  items:[],
  cartItems:[],
  seacherText:'',
  categories:[],
  pageNum:1,
  total: 0,
  pageSize:8,
  advertisement:[],
})


const carouselImages =[
  `https://img0.baidu.com/it/u=183554806,1567192393&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500`,
    `https://pic.616pic.com/bg_w1180/00/06/88/FJrE3xiMyg.jpg`,
    `https://img0.baidu.com/it/u=655608,2973212332&fm=253&fmt=auto&app=138&f=JPEG?w=1280&h=400`,
    `https://image.meiye.art/pic_1697892190364?imageMogr2/thumbnail/640x/interlace/1`,
]
// 获取商品列表
const loadproducts =()=>{
  request.get("/product/selectall",{
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
    }
  }).then(res=>{
    if (res.code === '200') {
      data.items = res.data.list;
      data.total = res.data.total;
    } else {
      ElMessage.error(res.msg)
    }
  })
}
loadproducts()
const insertcart = (product) => {
  request.post("/cart/insert", product)
      .then((res) => {
        console.log("后端返回：", res); // 调试用，查看后端返回内容
        if (res.code === "200") {
          // 成功加入购物车的提示
          ElMessage.success(res.data || "成功加入购物车！");
          loadcart(); // 更新购物车
        } else {
          // 判断错误信息是否为 "该商品已经加入购物车！"
          if (res.msg === "该商品已经加入购物车！") {
            ElMessage.info("该商品已经加入购物车！");
          } else {
            ElMessage.error(res.msg || "加入购物车失败！");
          }
        }
      })
      .catch((error) => {
        // 捕获后端返回的 HTTP 错误，例如 400/500 状态码
        const errorMsg = error.response?.data?.msg || "加入购物车失败";
        if (error.response?.data?.msg === "该商品已经加入购物车！") {
          ElMessage.info("该商品已经加入购物车！");
        } else {
          ElMessage.error(errorMsg);
        }
      });
};


const loadcart=()=>{
  request.get("/cart/selectAll").then(res=>{
    if (res.code === "200") {
      data.cartItems = res.data;
    } else {
      ElMessage.error(res.msg);
    }
  })
}
loadcart()

const showCart = ref(false); // 控制购物车弹窗的显示

const increase = (item) => {
  item.quantity += 1;
  request.post("/cart/increasequantity",item).then((res)=>{
    loadcart()
  })
  console.log('Increasing quantity:', item);  // 调试日志

};

const decrease = (item) => {
  if (item.quantity > 0) {
    item.quantity -= 1;
    request.post("/cart/decreasequantity",item).then((res)=>{
     loadcart()
    })
  }
};


const removeFromCart = (item) => {
  const productId = item.productId; // 从 item 中获取 dishId

  // 调用后端接口删除
  request.delete(`/cart/delete/${productId}`)

      .then((response) => {
        // 删除成功后从本地数据中删除该菜品
        loadcart()
        console.log("菜品删除成功:", response);
      })
      .catch((error) => {
        console.error("删除菜品失败:", error);
      });
};

const selectByname = () => {
  console.log("触发了搜索");

  // 判断输入是否为空
  if (!data.searchText.trim()) {
    console.log("搜索框为空");
    loadproducts()
    return;
  }

  console.log("搜索的宝贝名称:", data.searchText);

  // 发起 GET 请求，传递查询参数
  request.get('/product/selectByname', {
    params: { name: data.searchText }
  }).then((res) => {
    console.log("返回的宝贝数据:", res);

    // 判断返回数据类型，如果是对象，封装成数组
    if (res.data) {
      if (Array.isArray(res.data)) {
        data.items = res.data; // 如果返回的是数组，直接赋值
      } else {
        data.items = [res.data]; // 如果返回的是单个对象，封装成数组
      }
    } else {
      data.items = []; // 返回空时，清空商品列表
    }
  }).catch((error) => {
    console.error("请求宝贝数据失败:", error);
    data.items = []; // 请求失败时清空数据
  });
};

const selectByCategory =(category)=>{
  request.get("product/selectByCategory",{
    params: { category } // 将 category 作为查询参数传递
  }).then(res=>{
    if (res.code === "200") {
      data.items = res.data;
    } else {
      ElMessage.error("搜索加载失败");
    }
  })
}
// 加载分类名
const loadCategories = () => {
  request.get("/product/categories").then(res => {
    if (res.code === "200") {
      data.categories = res.data; // 例如: ["电子产品", "服装", "家居"]
    } else {
      ElMessage.error("分类加载失败");
    }
  });
};
loadCategories();

const loadAdvertisement = () =>{
  res.get("/shopping/selectAll").then(res=>(
      data.advertisement=res.data
  ))
}
loadAdvertisement()
const viewDetails = (productId) => {
  // 跳转到详情页面，传递商品ID作为路由参数
  router.push({ path: '/ProductDetail', query: { id: productId } });
};
const turntocheckout =()=>{
  router.push({path:'/checkout'})
}

</script>

<style scope>
/* 分类选择框样式 */
.menu-bar {
  margin-bottom: 20px;
  display: flex;
  gap: 10px;
  padding: 15px;
  border: 1px solid #ffd04b;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 6px rgba(255, 208, 75, 0.1);
}

.category-select {
  width: 200px;
}

/* 标题部分样式 */
.title-section {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 10px 20px;
  background: linear-gradient(45deg, #ff9900, #ffd04b);
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(255, 153, 0, 0.2);
  min-width: 300px; /* 确保标题区域有足够宽度 */
}

.shop-icon {
  font-size: 32px;
  color: #fff;
}

.title-content {
  display: flex;
  flex-direction: column;
}

.shop-title {
  font-size: 28px;
  color: #ffffff; /* 改为白色，增加与背景的对比度 */
  font-weight: bold;
  margin-bottom: 4px;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2); /* 添加文字阴影增加可读性 */
}

.shop-subtitle {
  font-size: 14px;
  color: #fff;
  opacity: 0.9;
}

/* 商品卡片按钮样式 */
.product-actions {
  display: flex;
  justify-content: space-between;
  padding: 10px 20px; /* 增加左右内边距 */
  gap: 12px;
}

.action-button {
  flex: 1;
  height: 40px;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  max-width: calc(50% - 6px); /* 确保按钮宽度相等且有适当间距 */
}

.action-button .el-icon {
  margin-right: 6px;
  font-size: 16px;
}
/* 搜索栏样式调整 */
.search-bar {
  display: flex;
  align-items: center;
  margin: 20px 0;
  padding: 0 10px;
  gap: 30px; /* 增加标题区域与搜索框之间的间距 */
}

.shop-title {
  font-size: 28px;
  color: #ff9900;
  font-family: 'Times New Roman', sans-serif;
  margin-right: 20px;
}

.search-section {
  display: flex;
  align-items: center;
  flex: 1;
  gap: 10px;
}

.search-input {
  width: 70%;
}

.search-button, .cart-button {
  display: flex;
  align-items: center;
  gap: 5px;
}
.product-card {
  border: 1px solid orange; /* 设置边框颜色为橙色 */

}

.product-card:hover {
  border-color: darkorange; /* 悬浮时边框变成深橙色 */
}
.product-image{
  width: 100px;
  height: 100px;
  object-fit: cover;
  margin-left: 10px;
}
/* 自定义分页样式 */
.card {
  margin-top: 100px;
  display: flex;
  justify-content: center; /* 将分页组件居中 */
  padding: 10px 0; /* 添加上下内边距 */
  border-radius: 8px; /* 圆角 */
}

.el-carousel {
  margin-bottom: 10px;
}
.product-page {
  background: linear-gradient(135deg, #fff5e6 0%, #fff9f9 100%);
  min-height: 100vh;
}
/* 轮播图样式 */
.carousel-container {
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.carousel-image {
  width: 100%;
  height: 400px;
  object-fit: cover;
}

/* 商品卡片样式 */
.product-card {
  border: 1px solid #ffd04b;
  transition: all 0.3s ease;
  height: 100%;
  background-color: #fff;
}

.product-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(255, 208, 75, 0.2);
}

.product-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 15px;
}

.product-image {
  width: 160px;
  height: 160px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 15px;
}

.product-info {
  text-align: center;
  width: 100%;
}

.product-name {
  font-size: 16px;
  color: #303133;
  margin: 10px 0;
  height: 44px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.product-price {
  color: #ff6b6b;
  font-size: 18px;
  font-weight: bold;
  margin: 8px 0;
}

.product-actions {
  display: flex;
  justify-content: space-around;
  padding: 10px;
  gap: 8px;
}

/* 按钮样式 */
.el-button {
  display: flex;
  align-items: center;
  gap: 5px;
}

.el-button [class^="el-icon"] {
  margin-right: 4px;
}

/* 购物车弹窗样式 */
.cartItems .el-card {
  margin-bottom: 15px;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.cartItems .el-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 208, 75, 0.2);
}

</style>