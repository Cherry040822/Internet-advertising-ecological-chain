<template>
  <div class="product-detail">
    <el-button @click="returnTopage">返回首页</el-button>
    <!-- 商品图片 -->
    <div class="image-section">
      <img :src="data.product.imageUrl" alt="商品图片" class="product-image" />
    </div>

    <!-- 商品信息 -->
    <div class="info-section">
      <h1 class="product-name">{{ data.product.name }}</h1>
      <p class="product-description">描述：{{ data.product.description }}</p>
      <p class="product-description">发货地：{{ data.product.shipAddress }}</p>
      <p class="product-description">快递：{{ data.product.delivery }}</p>
      <p class="product-description">销量：{{ data.product.sales }}</p>
      <p class="product-price">价格: ￥{{ data.product.price }}</p>

      <!-- 加入购物车按钮 -->
      <el-button
          type="warning"
          size="large"
          @click="addToCart(data.product)">
        加入购物车
      </el-button>
    </div>
  </div>
</template>

<script setup>
import { reactive } from "vue";
import request from "@/utils/request.js";
import { ElMessage } from "element-plus";
import {useRoute} from "vue-router";
import router from "@/router/index.js";
const data =reactive({
  product:{}

})
const route = useRoute();
const productId = route.query.id; // 从路由参数中获取商品 ID
const loadProductDetails = () => {
  if (!productId) {
    console.error("商品 ID 未传递");
    return;
  }
  request.get(`/product/selectById/${productId}`).then((res) => {
    if (res.code === "200") {
      console.log("返回的商品数据：", res.data); // 打印后端返回数据
      data.product = res.data; // 直接赋值
    } else {
      console.error("加载商品详情失败:", res.msg);
    }
  }).catch((error) => {
    console.error("请求失败:", error);
  });
};

loadProductDetails()
// 加入购物车方法
const addToCart = (product) => {
  request.post("/cart/insert", product)
      .then((res) => {
        console.log("后端返回：", res); // 调试用，查看后端返回内容
        if (res.code === "200") {
          // 成功加入购物车的提示
          ElMessage.success(res.data || "成功加入购物车！");
          loadcart(); // 更新购物车
        } else {
          // 判断错误信息是否为 "该商品已经加入购物车！"
          if (res.msg === "该商品已经加入购物车！") {
            ElMessage.info("该商品已经加入购物车！");
          } else {
            ElMessage.error(res.msg || "加入购物车失败！");
          }
        }
      })
      .catch((error) => {
        // 捕获后端返回的 HTTP 错误，例如 400/500 状态码
        const errorMsg = error.response?.data?.msg || "加入购物车失败";
        if (error.response?.data?.msg === "该商品已经加入购物车！") {
          ElMessage.info("该商品已经加入购物车！");
        }
      });
};
const returnTopage =()=>{
  router.push({ path: "/" });
}
</script>

<style scoped>
.product-detail {
  display: flex;
  gap: 20px;
  margin: 20px;
}

.image-section {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}

.product-image {
  max-width: 100%;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width:600px;
  height: 500px;
}

.info-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 10px;
}

.product-name {
  font-size: 24px;
  font-weight: bold;
}

.product-description {
  font-size: 16px;
  color: #666;
}

.product-price {
  font-size: 20px;
  color: #ff5722;
  font-weight: bold;
}

.el-button {
  margin-top: 20px;
}

</style>
