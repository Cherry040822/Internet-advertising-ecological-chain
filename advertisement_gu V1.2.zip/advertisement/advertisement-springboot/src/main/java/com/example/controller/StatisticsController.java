package com.example.controller;

import com.example.common.Result;
import com.example.service.StatisticsService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/statistics")
public class StatisticsController {

    @Resource
    private StatisticsService statisticsService;

    @GetMapping("/daily/selectAll")
    public Result dailySelectAll() {
        return Result.success(statisticsService.dailySelectAll());
    }

    @GetMapping("/monthly/selectAll")
    public Result monthlySelectAll() {
        return Result.success(statisticsService.monthlySelectAll());
    }

    @GetMapping("/annual/selectAll")
    public Result annualSelectAll() {
        return Result.success(statisticsService.annualSelectAll());
    }
}
