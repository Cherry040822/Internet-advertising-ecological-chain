package com.example.service;

import com.example.entity.Statistics;
import com.example.mapper.StatisticsMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StatisticsService {

    @Resource
    private StatisticsMapper statisticsMapper;

    public List<Statistics> dailySelectAll() {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取7天前的日期
        LocalDate sevenDaysAgo = today.minusDays(7);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.dailySelectAll();

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近七天的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate(), formatter);
                        // 判断记录日期是否在近七天之内
                        return !recordDate.isBefore(sevenDaysAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }

    public List<Statistics> monthlySelectAll() {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取12个月前的日期
        LocalDate twelveMonthsAgo = today.minusMonths(12);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.monthlySelectAll();

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近12个月的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01", formatter);
                        // 判断记录日期是否在近12个月之内
                        return !recordDate.isBefore(twelveMonthsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }


    public List<Statistics> annualSelectAll() {
        // 获取当前日期
        LocalDate today = LocalDate.now();

        // 获取10年前的日期
        LocalDate tenYearsAgo = today.minusYears(10);

        // 查询所有记录
        List<Statistics> allRecords = statisticsMapper.annualSelectAll();

        // 定义日期格式化器，用于将字符串转换为 LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 筛选近10年的记录
        return allRecords.stream()
                .filter(record -> {
                    try {
                        // 将日期字符串转换为 LocalDate
                        LocalDate recordDate = LocalDate.parse(record.getDate() + "-01" + "-01", formatter);
                        // 判断记录日期是否在近10年之内
                        return !recordDate.isBefore(tenYearsAgo);
                    } catch (Exception e) {
                        // 如果日期格式错误，可以选择记录或者抛出异常
                        return false;
                    }
                })
                .collect(Collectors.toList());
    }
}
