package com.example.controller;

import com.example.common.Result;
import com.example.entity.News;
import com.example.service.NewsService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/news")
public class NewsController {

    @Resource
    private NewsService newsService;

    @PostMapping("/add")
    public Result save(@RequestBody News news) {
        try {
            newsService.add(news);
            return Result.success();
        } catch (Exception e) {
            return Result.error("500","保存失败: " + e.getMessage());
        }
    }
    @GetMapping("/selectAll")
    public Result selectById() {
        return Result.success(newsService.selectUrlByAdvertisementId());
    }

    @PutMapping("/updateClick/{advertisementId}")
    public Result updateClickByAdvertisementId(@PathVariable Integer advertisementId) {
        newsService.updateClickByAdvertisementId(advertisementId);
        return Result.success();
    }

    @GetMapping("/selectByAdvertisementId/{advertisementId}")
    public Result selectByAdvertisementId(@PathVariable Integer advertisementId) {
        return Result.success(newsService.selectMoneyByAdvertisementId(advertisementId));
    }

    @PutMapping("/updateStatus")
    public Result updateStatus() {
        newsService.updateStatus();
        return Result.success();
    }

}