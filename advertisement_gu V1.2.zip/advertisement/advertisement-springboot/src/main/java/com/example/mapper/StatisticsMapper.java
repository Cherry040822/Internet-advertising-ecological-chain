package com.example.mapper;

import com.example.entity.Statistics;

import java.util.List;

public interface StatisticsMapper {
    List<Statistics> dailySelectAll();

    List<Statistics> monthlySelectAll();

    List<Statistics> annualSelectAll();
}
