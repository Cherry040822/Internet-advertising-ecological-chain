package com.example.service;

import com.example.entity.News;
import com.example.mapper.NewsMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class NewsService {

    @Resource
    NewsMapper newsMapper;

    public void add(News news) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        news.setCreateTime(sdf.format(new Date()));
        news.setStatus("已提交平台");
        news.setUrl("http://localhost:8100/LinkNews/"+news.getAdvertisementId());
        newsMapper.insert(news);
    }

    public boolean selectByAdvertisementId(Integer advertisementId) {
        System.out.println("新闻："+newsMapper.selectByAdvertisementId(advertisementId));
        if(newsMapper.selectByAdvertisementId(advertisementId)){
            return true;
        }else {
            return false;
        }
    }

    public List<News> selectUrlByAdvertisementId() {
        return newsMapper.selectUrlByAdvertisementId();
    }

    public void updateClickByAdvertisementId(Integer advertisementId) {
        newsMapper.updateClickByAdvertisementId(advertisementId);
    }

    public News selectMoneyByAdvertisementId(Integer advertisementId) {
        return newsMapper.selectMoneyByAdvertisementId(advertisementId);
    }

    public void updateStatus() {
        newsMapper.updateStatus();
    }
}
