package com.example.entity;

public class Statistics {
    private int id;
    private int shoppingClick;
    private int newsClick;
    private String date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getShoppingClick() {
        return shoppingClick;
    }

    public void setShoppingClick(int shoppingClick) {
        this.shoppingClick = shoppingClick;
    }

    public int getNewsClick() {
        return newsClick;
    }

    public void setNewsClick(int newsClick) {
        this.newsClick = newsClick;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
