package com.example.controller;

public class AdController {
}
