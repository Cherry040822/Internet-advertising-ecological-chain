package com.example.controller;

import com.example.common.Result;
import com.example.entity.News;
import com.example.service.NewsService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/news")
public class NewsController {
    @Resource
    private NewsService newsService;

    // 获取所有新闻
    @GetMapping("/list")
    public Result getAllNews() {
        List<News> newsList = newsService.getAllNews();
        return Result.success(newsList);
    }

    // 获取所有新闻标签
    @GetMapping("/tags")
    public Result getAllTags() {
        List<String> tags = newsService.getAllTags();
        return Result.success(tags);
    }

    // 获取单个新闻详情
    @GetMapping("/{id}")
    public Result getNewsDetail(@PathVariable Integer id) {
        News news = newsService.getNewsById(id);
        return Result.success(news);

    }

    // 获取特定标签的新闻列表，按发布时间降序排序
    @GetMapping("/tag/{tag}")
    public Result getNewsByTag(@PathVariable String tag) {
        List<News> newsList = newsService.getNewsByTag(tag);
        return Result.success(newsList);
    }

    // 根据标题、内容或标签搜索新闻，按发布时间降序排序
    @GetMapping("/search")
    public Result searchNews(@RequestParam(value = "query", required = false) String query) {
        List<News> newsList = newsService.searchNews(query);
        return Result.success(newsList);
    }

    @GetMapping("/carousel")
    public Result getRandomNewsForCarousel() {
        List<News> newsList = newsService.getRandomNewsForCarousel(5);
        return Result.success(newsList);
    }


}
