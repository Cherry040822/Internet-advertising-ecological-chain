package com.example.mapper;
import com.example.entity.News;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface NewsMapper {
    // 获取所有新闻列表，按发布时间降序排序
//    @Select("SELECT * FROM news ORDER BY publication_time DESC")
    List<News> getAllNews();

    // 获取所有新闻的分类标签（假设标签存储在 news 表的 `tags` 字段）
//    @Select("SELECT DISTINCT tags FROM news")
    List<String> getAllTags();

    // 根据新闻ID获取新闻详情
//    @Select("SELECT * FROM news WHERE id = #{id}")
    News getNewsById(Integer id);

//tag分类获得新闻
    List<News> getNewsByTag(String tag);

    List<News> searchNews(@Param("query") String query);

    //@Select("SELECT * FROM news WHERE image_url IS NOT NULL AND image_url != '' ORDER BY RAND() LIMIT #{count}")
    List<News> getRandomNewsForCarousel(@Param("count") int count);
}

