<template>
  <div style="display: flex">
    <div class="news-container">

      <div style="position: relative;height: auto; background-color: #516996; padding: 20px;">
        <!-- Logo 和标题 -->
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
          <img src="@/assets/新闻.png" alt="News Website Logo" style="width: 40px;">
          <span style="font-size: 20px; font-weight: bold;color: #d1e3f6; font-style: italic;margin-left: 10px;">新闻中心</span>
        </div>
      </div>

      <!-- 标签部分 -->
      <div class="tags-section" style="display: flex; flex-wrap: wrap;gap:5px;margin: 0">
        <el-button class="tag-button" v-for="tag in tags" :key="tag" @click="openTagPage(tag)" >
          {{ tag }}
        </el-button>


        <!--搜索框部分-->
        <div class="search-section">
          <el-input v-model="searchQuery" style="width: 240px" placeholder="搜索新闻" clearable @keyup.enter="openSearchPage"
          >
            <template #prefix>
              <el-icon class="el-input__icon"><search /></el-icon>
            </template>
          </el-input>
          <el-button style="margin-left: 5px" type="primary" :icon="Search" circle @click="openSearchPage"/>
        </div>

      </div>

      <!-- 头部结束 -->

      <!-- 轮播图 -->
      <div class="carousel-container">
        <el-carousel height="200px" motion-blur>
          <el-carousel-item v-for="(item, index) in carouselNews" :key="index">
            <div style="position: relative; width: 100%; height: 100%;">
              <!-- 使用绝对路径 -->
              <img :src="item.imageUrl" alt="news image" style="width: 100%; height: 100%; object-fit: cover;">
              <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.5); color: white; padding: 10px;">
                <a :href="`/news/${item.id}`" target="_blank" @click.prevent="openNewsDetail(item)">
                  <h3>{{ item.title }}</h3>
                </a>
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </div>



      <!-- 新闻列表区域 -->
      <div class="news-section">
        <div v-for="news in newsList" :key="news.id" class="news-item">
          <a style="text-decoration: none;" :href="`/news/${news.id}`" target="_blank" @click.prevent="openNewsDetail(news)">
            <div class="news-content">
              <img src="@/assets/title1-1.jpg" alt="News Icon" class="news-icon">
              <div class="news-info">
                <h3 class="news-title">{{ news.title }}</h3>
                <div class="news-meta">
                  <span>{{ news.author }}</span>
                  <span>{{ formatDate(news.publicationTime) }}</span>
                </div>
              </div>
            </div>
          </a>
        </div>
      </div>

    </div>

    <div>
      <div v-for="item in data.advertisement.slice(0, 5)" :key="item.id">
        <iframe :src="item.url" width="150px" height="150px" scrolling="no"></iframe>
      </div>
    </div>
  </div>


</template>

<script setup>
import { ref, onMounted, reactive } from 'vue'
import axios from 'axios'
import {Search} from "@element-plus/icons-vue";
import request from "@/utils/request.js";


const tags = ref([])
const newsList = ref([])
const carouselNews = ref([]) // 新增属性保存轮播图新闻
const searchQuery = ref('')
const data = reactive({
  advertisement:[],
})

async function openNewsDetail(news) {
  const detailWindow = window.open('', encodeURIComponent(news.title));
  if (detailWindow) {
    detailWindow.location.href = `/news/${news.id}`;
  }
}

const fetchData = async () => {
  try {
    const [tagsRes, newsRes] = await Promise.all([
      axios.get('/news/tags'),
      axios.get('/news/list')
    ])
    tags.value = tagsRes.data.data
    newsList.value = newsRes.data.data
  } catch (error) {
    console.error('数据获取失败:', error)
  }
}

const formatDate = (dateStr) => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  return date.toLocaleDateString('zh-CN')
}

onMounted(() => {
  fetchData()
})
function openTagPage(tag) {
  window.open(`/news/tag/${encodeURIComponent(tag)}`, '_blank');
}

function openSearchPage() {
  if (searchQuery.value) {
    window.open(`/news/search?query=${encodeURIComponent(searchQuery.value)}`, '_blank');
  }
}

// 新增函数来获取轮播图新闻
const fetchCarouselNews = async () => {
  try {
    const response = await axios.get('/news/carousel');
    // 确保返回的数据结构正确，每个新闻对象包含 imageUrl 和 title 属性
    carouselNews.value = response.data.data.map(item => ({
      id: item.id,
      title: item.title,
      imageUrl: item.imageUrl // 假设imageUrl是完整路径
    }));
  } catch (error) {
    console.error('获取轮播图新闻失败:', error)
  }
}

onMounted(() => {
  fetchData();
  fetchCarouselNews(); // 页面加载时也获取轮播图新闻
})

const loadAdvertisement = () =>{
  request.get("/news/selectAll").then(res=>(
      data.advertisement=res.data
  ))
}
loadAdvertisement()
</script>

<style scoped>
.news-container {
  max-width: 1000px;
  margin-left: 200px;
  margin-right: 100px;
  padding: 20px;
  background-color: #f9f9fb;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}


.tags-section {
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 30px;
  padding: 20px 0;
  border-bottom: 1px solid #98c7d5;
}

.tag-button {
  padding: 4px 12px; /* 减少内边距 */
  background-color: #59a6e7;
  color: #f3f1f1;
  transition: all 0.3s;
}

.tag-button:hover {
  background-color: #4b94d1;
}

.news-section {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}


.news-title {
  margin: 0 0 5px 0;
  font-size: 18px;
  color: #333;
  transition: color 0.3s ease;
}

/*当鼠标悬停在新闻标题上时改变字体颜色 */
.news-title:hover {
  color: #1e6bb7;
}


.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
}

.search-section {
  display: flex;
  margin-left: 700px;
  margin-top: 10px;
}
.carousel-container {
  margin-top: 10px;
  background-color: #f9f9fb;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.el-carousel__item h3 {
  color: #fff;
  opacity: 0.75;
  line-height: 1.2;
  margin: 0;

}


/* 添加新的样式规则 */
.news-item {
  padding: 20px;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
}

.news-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.news-content {
  display: flex;
  align-items: flex-start;
}

.news-icon {
  width: 50px; /* 根据需要调整大小 */
  height: 50px;
  object-fit: contain;
  margin-right: 10px; /* 图片与文本之间的间距 */
}

.news-info {
  display: flex;
  flex-direction: column;
}

.news-title {
  margin: 0 0 5px 0;
  font-size: 18px;
  color: #333;
}

.news-meta {
  display: flex;
  gap: 20px;
  color: #666;
  font-size: 14px;
  text-decoration: none;
}
</style>
