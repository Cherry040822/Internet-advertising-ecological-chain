import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {path: '/',
      name: 'NewsList',
      meta:{title:'新闻中心'},
      component: () => import('../views/NewsList.vue'),
    },
    {
      path: '/news/:id',
      name: 'NewsDetail',
      meta:{title:'新闻详情'},
      component: () => import('../views/NewsDetail.vue'),
      props: true // 将URL参数作为props传递给组件
    },
    {
      path: '/news/tag/:tag',
      name: 'TagNewsList',
      meta:{title:'新闻标签分类'},
      component: () => import('../views/TagNewsList.vue'),
      props: true // 将URL参数作为props传递给组件
    },
    {
      path: '/news/search',
      name: 'NewsSearch',
      meta:{title:'新闻搜索'},
      component: () => import('../views/NewsSearch.vue'),
      props: route => ({ query: route.query.query }) // 将URL查询参数作为props传递给组件
    }
  ]
})
router.beforeEach((to,from,next)=>{
  document.title=to.meta.title
  next()
})
export default router
