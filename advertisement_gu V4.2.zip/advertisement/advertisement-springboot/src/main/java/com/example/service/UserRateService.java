package com.example.service;

import com.example.entity.UserRate;
import com.example.mapper.UserRateMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

@Service
public class UserRateService {
    @Resource
    UserRateMapper userRateMapper;
    public void add(UserRate userRate) {
        String user = userRate.getUser();
        String category = userRate.getCategory();

        UserRate dbuserRate =userRateMapper.selectByUserAndCategory(user,category);
        if(dbuserRate != null){
            Integer grade = dbuserRate.getGrade()+1;
            userRate.setGrade(grade);
            userRateMapper.updateByUserAddCategory(userRate);
        }else {
            userRate.setGrade(1);
            userRateMapper.insert(userRate);
        }
    }
}
