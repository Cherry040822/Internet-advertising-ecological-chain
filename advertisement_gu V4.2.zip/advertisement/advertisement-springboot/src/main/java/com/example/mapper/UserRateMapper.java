package com.example.mapper;

import com.example.entity.UserRate;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface UserRateMapper {
    @Select("SELECT * FROM `user_rate` WHERE `user` = #{user} AND `category` = #{category}")
    UserRate selectByUserAndCategory(String user, String category);

    void updateByUserAddCategory(UserRate userRate);

    void insert(UserRate userRate);

    @Select("SELECT category, grade FROM user_rate WHERE user = #{user}")
    List<Map<String, Object>> findCategoriesByUser(@Param("user") String user);
}
