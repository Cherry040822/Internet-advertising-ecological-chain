<template>
  <div style="padding: 100px;margin: 0 auto;" class="main">
    <div class="card1" >
      <el-form :model="data.user" label-width="100px" style="padding-right: 50px">
        <el-form-item label="用户名">
          <el-input disabled v-model="data.user.name" autocomplete="off" />
        </el-form-item>
        <el-form-item label="用户角色">
          <el-input disabled v-model="data.user.role" autocomplete="off" />
        </el-form-item>
        <el-form-item label="密码" >
          <el-input v-model="data.user.password" show-password autocomplete="off" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="save">保存</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup>
import {reactive} from "vue"
import request from "@/utils/request";
import {ElMessage, ElMessageBox} from "element-plus";

const data = reactive({
  user: JSON.parse(localStorage.getItem('user') || '{}'),
})


const emit = defineEmits(["updateUser"])
// 把当前修改的用户信息存储到后台数据库
const save = () => {
  request.put('/user/update', data.user).then(res => {
    if (res.code === '200') {
      ElMessage.success('更新成功')
    } else {
      ElMessage.error(res.msg)
    }
  })
  //把更新后的用户信息存储到缓存
  localStorage.setItem('canteen-user', JSON.stringify(data.user))
  emit('updateUser')
}
</script>

<style scoped>
.avatar-uploader .avatar {
  width: 120px;
  height: 120px;
  display: block;
}
</style>

<style>
.avatar-uploader .el-upload {
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.avatar-uploader .el-upload:hover {
  border-color: var(--el-color-primary);
}

.el-icon.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 120px;
  height: 120px;
  text-align: center;
}
.main {
  height: 500px;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  background: url("@/assets/adBg.jpg");
  background-size: cover;
}
.card1{
  width: 350px;
  padding: 50px 30px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0,.1);
  background-color: rgba(255, 255, 255, 0.8);
  margin:100px;
}
:deep(.el-form-item--label-right){
  color:#ffffff;
}
</style>