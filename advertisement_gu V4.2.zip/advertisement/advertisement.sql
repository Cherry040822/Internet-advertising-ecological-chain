/*
 Navicat Premium Data Transfer

 Source Server         : usst
 Source Server Type    : MySQL
 Source Server Version : 80300 (8.3.0)
 Source Host           : xp.hebiu.cn:3306
 Source Schema         : advertisement

 Target Server Type    : MySQL
 Target Server Version : 80300 (8.3.0)
 File Encoding         : 65001

 Date: 27/12/2024 17:58:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for advertisement
-- ----------------------------
DROP TABLE IF EXISTS `advertisement`;
CREATE TABLE `advertisement`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of advertisement
-- ----------------------------
INSERT INTO `advertisement` VALUES (35, '乌萨奇', '乌萨奇最可爱', 'http://xp.hebiu.cn:9090/files/download/1734980283072_屏幕截图 2024-12-19 145128.png', '动漫', '动漫', '2024-12-24 02:58:32', '已投放第三方平台', 1, 'user001');
INSERT INTO `advertisement` VALUES (36, '红烧肉', '红烧肉是一道江浙菜', 'http://xp.hebiu.cn:9090/files/download/1734980545165_屏幕截图 2024-12-13 221949.png', '食物', '美食', '2024-12-26 19:13:32', '已投放第三方平台', 1, 'user001');
INSERT INTO `advertisement` VALUES (37, '国产科幻电影', '国产科幻电影质量越来越高', 'http://xp.hebiu.cn:9090/files/download/1734980701211_屏幕截图 2024-12-22 160600.png', '科技', '科幻电影', '2024-12-26 19:41:32', '已提交平台', 1, 'user001');
INSERT INTO `advertisement` VALUES (44, '333', '333', '', '女装', '333', '2024-12-26 21:04:19', '已提交平台', 2, 'user002');

-- ----------------------------
-- Table structure for advertisement_news
-- ----------------------------
DROP TABLE IF EXISTS `advertisement_news`;
CREATE TABLE `advertisement_news`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  `click` int NULL DEFAULT 0,
  `sum_click` int NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of advertisement_news
-- ----------------------------
INSERT INTO `advertisement_news` VALUES (31, '乌萨奇', '乌萨奇最可爱', 'http://xp.hebiu.cn:9090/files/download/1734980283072_屏幕截图 2024-12-19 145128.png', '动漫', '动漫', '2024-12-24 02:58:32', '已投放第三方平台', 1, 'user001', 35, 0, 206, 'http://xp.hebiu.cn:80/LinkNews/35');
INSERT INTO `advertisement_news` VALUES (32, '红烧肉', '红烧肉是一道江浙菜', 'http://xp.hebiu.cn:9090/files/download/1734980545165_屏幕截图 2024-12-13 221949.png', '食物', '美食', '2024-12-26 19:13:32', '已投放第三方平台', 1, 'user001', 36, 0, 320, 'http://xp.hebiu.cn:80/LinkNews/36');
INSERT INTO `advertisement_news` VALUES (38, '国产科幻电影', '国产科幻电影质量越来越高', 'http://xp.hebiu.cn:9090/files/download/1734980701211_屏幕截图 2024-12-22 160600.png', '科技', '科幻电影', '2024-12-26 19:41:32', '已提交平台', 1, 'user001', 37, 0, 376, 'http://xp.hebiu.cn:80/LinkNews/37');
INSERT INTO `advertisement_news` VALUES (39, '333', '333', '', '女装', '333', '2024-12-26 21:04:19', '已提交平台', 2, 'user002', 44, 0, 580, 'http://xp.hebiu.cn:80/LinkNews/44');

-- ----------------------------
-- Table structure for advertisement_shopping
-- ----------------------------
DROP TABLE IF EXISTS `advertisement_shopping`;
CREATE TABLE `advertisement_shopping`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `create_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  `click` int NULL DEFAULT 0,
  `sum_click` int NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of advertisement_shopping
-- ----------------------------
INSERT INTO `advertisement_shopping` VALUES (40, '乌萨奇', '乌萨奇最可爱', 'http://xp.hebiu.cn:9090/files/download/1734980283072_屏幕截图 2024-12-19 145128.png', '动漫', '动漫', '2024-12-24 02:58:32', '已提交平台', 1, 'user001', 35, 0, 400, 'http://xp.hebiu.cn:80/LinkShopping/35');
INSERT INTO `advertisement_shopping` VALUES (41, '红烧肉', '红烧肉是一道江浙菜', 'http://xp.hebiu.cn:9090/files/download/1734980545165_屏幕截图 2024-12-13 221949.png', '食物', '美食', '2024-12-26 19:13:32', '已投放第三方平台', 1, 'user001', 36, 0, 430, 'http://xp.hebiu.cn:80/LinkShopping/36');
INSERT INTO `advertisement_shopping` VALUES (47, '国产科幻电影', '国产科幻电影质量越来越高', 'http://xp.hebiu.cn:9090/files/download/1734980701211_屏幕截图 2024-12-22 160600.png', '科技', '科幻电影', '2024-12-26 19:41:32', '已提交平台', 1, 'user001', 37, 0, 203, 'http://xp.hebiu.cn:80/LinkShopping/37');
INSERT INTO `advertisement_shopping` VALUES (48, '333', '333', '', '女装', '333', '2024-12-26 21:04:19', '已提交平台', 2, 'user002', 44, 0, 385, 'http://xp.hebiu.cn:80/LinkShopping/44');

-- ----------------------------
-- Table structure for annual
-- ----------------------------
DROP TABLE IF EXISTS `annual`;
CREATE TABLE `annual`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `shopping_click` int NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `news_click` int NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 61 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of annual
-- ----------------------------
INSERT INTO `annual` VALUES (57, 375, '2024', 580, 2, 44);
INSERT INTO `annual` VALUES (58, 300, '2024', 200, 1, 35);
INSERT INTO `annual` VALUES (59, 400, '2024', 300, 1, 36);
INSERT INTO `annual` VALUES (60, 200, '2024', 276, 1, 37);

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, '女装');
INSERT INTO `category` VALUES (2, '科技');
INSERT INTO `category` VALUES (3, '动漫');
INSERT INTO `category` VALUES (4, '食物');

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_money` int NULL DEFAULT NULL,
  `web_money` int NULL DEFAULT NULL,
  `adm_money` int NULL DEFAULT NULL,
  `time` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL COMMENT '投放的时间',
  `day` int NULL DEFAULT NULL COMMENT '投放间隔天数',
  `money` int NULL DEFAULT NULL,
  `money_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES (1, 40, 30, 30, NULL, NULL, 10, NULL);

-- ----------------------------
-- Table structure for daily
-- ----------------------------
DROP TABLE IF EXISTS `daily`;
CREATE TABLE `daily`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `shopping_click` int NULL DEFAULT 0,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `news_click` int NULL DEFAULT 0,
  `user_id` int NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 187 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of daily
-- ----------------------------
INSERT INTO `daily` VALUES (183, 375, '2024-12-27', 580, 2, 44);
INSERT INTO `daily` VALUES (184, 300, '2024-12-27', 200, 1, 35);
INSERT INTO `daily` VALUES (185, 400, '2024-12-27', 300, 1, 36);
INSERT INTO `daily` VALUES (186, 200, '2024-12-27', 276, 1, 37);

-- ----------------------------
-- Table structure for monthly
-- ----------------------------
DROP TABLE IF EXISTS `monthly`;
CREATE TABLE `monthly`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `shopping_click` int NULL DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `news_click` int NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `advertisement_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_month_ad`(`date` ASC, `advertisement_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 73 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of monthly
-- ----------------------------
INSERT INTO `monthly` VALUES (69, 375, '2024-12', 580, 2, 44);
INSERT INTO `monthly` VALUES (70, 300, '2024-12', 200, 1, 35);
INSERT INTO `monthly` VALUES (71, 400, '2024-12', 300, 1, 36);
INSERT INTO `monthly` VALUES (72, 200, '2024-12', 276, 1, 37);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `web_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  `web_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'user001', '123456', 'USER', NULL, NULL);
INSERT INTO `user` VALUES (2, 'admin001', '12345', 'ADMIN', NULL, NULL);
INSERT INTO `user` VALUES (3, 'user002', '123456', 'USER', NULL, NULL);
INSERT INTO `user` VALUES (14, 'webMaster001', '123456', 'WEBMASTER', '购物中心', 'http://8.153.75.78');
INSERT INTO `user` VALUES (15, 'webMaster002', '123456', 'WEBMASTER', '新闻中心', 'http://www.baidu.com');

SET FOREIGN_KEY_CHECKS = 1;
